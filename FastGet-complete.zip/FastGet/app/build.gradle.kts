plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.fastget.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.fastget.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 4
        versionName = "2.2.0"

    }

    buildTypes {
        debug {
            // Debug stays readable; ABI splits below limit which architectures are packaged.
            isMinifyEnabled = false
            isShrinkResources = false
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
        // yt-dlp / ffmpeg ship as native executables that must be extracted at install time.
        // Legacy packaging stores .so uncompressed (required for execute permission on API 29+).
        jniLibs { useLegacyPackaging = true }
    }

    // Light APK for modern phones (64-bit) and GitHub releases.
    // arm64-v8a only ≈ half the size of dual-ABI. Re-add "armeabi-v7a" if you still need old 32-bit devices.
    splits {
        abi {
            isEnable = true
            reset()
            include("arm64-v8a")
            isUniversalApk = false
        }
    }

    // AAB: Play / sideload tools deliver only the device ABI.
    bundle {
        abi {
            enableSplit = true
        }
        language {
            enableSplit = true
        }
        density {
            enableSplit = true
        }
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.06.00")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    // Full icon set is large, but the UI uses Rounded.* icons from extended.
    // Do not remove without rewriting every Icons.Rounded reference.
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.2")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.2")
    implementation("androidx.core:core-ktx:1.13.1")

    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Video / music engine (yt-dlp + embedded Python + FFmpeg).
    // Per-ABI native cost (arm64): ~15 MB Python/QJS + ~35 MB FFmpeg ≈ 50 MB.
    // These cannot be removed without breaking search, MP3 extract, merge, thumbnails.
    implementation("io.github.junkfood02.youtubedl-android:library:0.18.1")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1")
    // aria2c is optional and NOT used by this app — intentionally omitted.

    implementation("io.coil-kt:coil-compose:2.6.0")
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("androidx.fragment:fragment-ktx:1.8.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // BitTorrent (libtorrent). App packages arm64-v8a only.
    implementation("org.libtorrent4j:libtorrent4j-android-arm64:2.1.0-39")

    debugImplementation("androidx.compose.ui:ui-tooling")
}

package com.fastget.app.core

import android.content.Context
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf

/**
 * Settings backed by SharedPreferences, observable from Compose.
 *
 * Mutable settings use public `var` properties whose setters also persist to
 * SharedPreferences. From Kotlin, assign the property directly (e.g. `prefs.threads = 8`).
 *
 * `themeId` is read-only; mutation goes through `setTheme(...)` to match existing call sites.
 */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("fastget", Context.MODE_PRIVATE)

    private val themeIdState = mutableStateOf(sp.getString("theme", "midnight") ?: "midnight")
    val themeId: String get() = themeIdState.value

    fun setTheme(v: String) {
        themeIdState.value = v
        sp.edit().putString("theme", v).apply()
    }

    private val threadsState = mutableIntStateOf(sp.getInt("threads", 8))
    var threads: Int
        get() = threadsState.intValue
        set(v) {
            threadsState.intValue = v
            sp.edit().putInt("threads", v).apply()
        }

    private val maxParallelState = mutableIntStateOf(sp.getInt("parallel", 3))
    var maxParallel: Int
        get() = maxParallelState.intValue
        set(v) {
            maxParallelState.intValue = v
            sp.edit().putInt("parallel", v).apply()
        }

    /** KB/s, 0 = unlimited. Applied to downloads started after the change. */
    private val speedLimitKbState = mutableLongStateOf(sp.getLong("limit_kb", 0L))
    var speedLimitKb: Long
        get() = speedLimitKbState.longValue
        set(v) {
            speedLimitKbState.longValue = v
            sp.edit().putLong("limit_kb", v).apply()
        }

    private val wifiOnlyState = mutableStateOf(sp.getBoolean("wifi_only", false))
    var wifiOnly: Boolean
        get() = wifiOnlyState.value
        set(v) {
            wifiOnlyState.value = v
            sp.edit().putBoolean("wifi_only", v).apply()
        }

    private val clipboardWatchState = mutableStateOf(sp.getBoolean("clipboard", true))
    var clipboardWatch: Boolean
        get() = clipboardWatchState.value
        set(v) {
            clipboardWatchState.value = v
            sp.edit().putBoolean("clipboard", v).apply()
        }

    private val publishToDownloadsState = mutableStateOf(sp.getBoolean("publish", true))
    var publishToDownloads: Boolean
        get() = publishToDownloadsState.value
        set(v) {
            publishToDownloadsState.value = v
            sp.edit().putBoolean("publish", v).apply()
        }

    private val appLockState = mutableStateOf(sp.getBoolean("app_lock", false))
    var appLock: Boolean
        get() = appLockState.value
        set(v) {
            appLockState.value = v
            sp.edit().putBoolean("app_lock", v).apply()
        }

    private val secureScreenState = mutableStateOf(sp.getBoolean("secure_screen", false))
    var secureScreen: Boolean
        get() = secureScreenState.value
        set(v) {
            secureScreenState.value = v
            sp.edit().putBoolean("secure_screen", v).apply()
        }

    /** Plain http links are refused unless this is on. */
    private val allowHttpState = mutableStateOf(sp.getBoolean("allow_http", false))
    var allowHttp: Boolean
        get() = allowHttpState.value
        set(v) {
            allowHttpState.value = v
            sp.edit().putBoolean("allow_http", v).apply()
        }

    private val videoTermsAcceptedState = mutableStateOf(sp.getBoolean("video_terms", false))
    var videoTermsAccepted: Boolean
        get() = videoTermsAcceptedState.value
        private set(v) {
            videoTermsAcceptedState.value = v
            sp.edit().putBoolean("video_terms", v).apply()
        }

    /**
     * App language: "fa" or "en". Empty means not chosen yet (first-run prompt).
     * Actual locale switching will be applied in a later step.
     */
    private val languageState = mutableStateOf(sp.getString("language", "") ?: "")
    var language: String
        get() = languageState.value
        set(v) {
            languageState.value = v
            sp.edit().putString("language", v).apply()
        }

    /**
     * Custom download folder absolute path. Empty = use app default
     * (Android/data/.../Download or internal downloads).
     * Full folder picker (SAF) will be wired in a later step.
     */
    private val customDownloadDirState = mutableStateOf(sp.getString("custom_dl_dir", "") ?: "")
    var customDownloadDir: String
        get() = customDownloadDirState.value
        set(v) {
            customDownloadDirState.value = v
            sp.edit().putString("custom_dl_dir", v).apply()
        }

    /** SAF tree URI from system folder picker (content://...). */
    private val customDownloadTreeUriState = mutableStateOf(sp.getString("custom_dl_tree", "") ?: "")
    var customDownloadTreeUri: String
        get() = customDownloadTreeUriState.value
        set(v) {
            customDownloadTreeUriState.value = v
            sp.edit().putString("custom_dl_tree", v).apply()
        }

    /**
     * Legacy single list (kept for browser shortcuts). Prefer the four category lists below.
     */
    private val customSitesState = mutableStateOf(
        sp.getString("custom_sites", "youtube.com\nsoundcloud.com\ninstagram.com") ?: ""
    )
    var customSites: String
        get() = customSitesState.value
        set(v) {
            customSitesState.value = v
            sp.edit().putString("custom_sites", v).apply()
        }

    fun customSitesList(): List<String> =
        customSites.lines().map { it.trim() }.filter { it.isNotEmpty() }.distinct()

    // ---- Stage 1: four separate site lists (one host per line) ----

    private val sitesVideoState = mutableStateOf(
        sp.getString("sites_video", "youtube.com\naparat.com\nvimeo.com") ?: ""
    )
    var sitesVideo: String
        get() = sitesVideoState.value
        set(v) {
            sitesVideoState.value = v
            sp.edit().putString("sites_video", v).apply()
        }

    private val sitesPornState = mutableStateOf(
        sp.getString("sites_porn", "pornhub.com\nxvideos.com") ?: ""
    )
    var sitesPorn: String
        get() = sitesPornState.value
        set(v) {
            sitesPornState.value = v
            sp.edit().putString("sites_porn", v).apply()
        }

    private val sitesAudioState = mutableStateOf(
        sp.getString("sites_audio", "soundcloud.com") ?: ""
    )
    var sitesAudio: String
        get() = sitesAudioState.value
        set(v) {
            sitesAudioState.value = v
            sp.edit().putString("sites_audio", v).apply()
        }

    private val sitesTorrentState = mutableStateOf(
        sp.getString("sites_torrent", "1337x.to\nnyaa.si") ?: ""
    )
    var sitesTorrent: String
        get() = sitesTorrentState.value
        set(v) {
            sitesTorrentState.value = v
            sp.edit().putString("sites_torrent", v).apply()
        }

    fun sitesFor(category: SiteCategory): List<String> {
        val raw = when (category) {
            SiteCategory.VIDEO -> sitesVideo
            SiteCategory.PORN -> sitesPorn
            SiteCategory.AUDIO -> sitesAudio
            SiteCategory.TORRENT -> sitesTorrent
        }
        return raw.lines().map { it.trim().lowercase().removePrefix("https://").removePrefix("http://").removePrefix("www.") }
            .filter { it.isNotEmpty() }.distinct()
    }

    fun siteEntries(category: SiteCategory): List<SiteEntry> {
        val ageGateHosts = setOf("pornhub.com", "xvideos.com", "xhamster.com", "xnxx.com")
        return sitesFor(category).map { host ->
            SiteEntry(
                host = host,
                category = category,
                needsAgeGate = host in ageGateHosts || category == SiteCategory.PORN
            )
        }
    }

    /** When true, GoogleEngine runs in parallel with site engines. */
    private val googleSearchEnabledState = mutableStateOf(sp.getBoolean("google_search", true))
    var googleSearchEnabled: Boolean
        get() = googleSearchEnabledState.value
        set(v) {
            googleSearchEnabledState.value = v
            sp.edit().putBoolean("google_search", v).apply()
        }

    /** When true, new downloads only start between scheduleStartHour and scheduleEndHour. */
    private val scheduleEnabledState = mutableStateOf(sp.getBoolean("schedule_on", false))
    var scheduleEnabled: Boolean
        get() = scheduleEnabledState.value
        set(v) {
            scheduleEnabledState.value = v
            sp.edit().putBoolean("schedule_on", v).apply()
        }

    private val scheduleStartHourState = mutableIntStateOf(sp.getInt("schedule_start", 0))
    var scheduleStartHour: Int
        get() = scheduleStartHourState.intValue
        set(v) {
            scheduleStartHourState.intValue = v.coerceIn(0, 23)
            sp.edit().putInt("schedule_start", scheduleStartHourState.intValue).apply()
        }

    private val scheduleEndHourState = mutableIntStateOf(sp.getInt("schedule_end", 23))
    var scheduleEndHour: Int
        get() = scheduleEndHourState.intValue
        set(v) {
            scheduleEndHourState.intValue = v.coerceIn(0, 23)
            sp.edit().putInt("schedule_end", scheduleEndHourState.intValue).apply()
        }

    /** True if downloads are allowed to start right now according to the schedule. */
    fun isWithinSchedule(): Boolean {
        if (!scheduleEnabled) return true
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val start = scheduleStartHour
        val end = scheduleEndHour
        return if (start <= end) hour in start until end
        else hour >= start || hour < end // overnight window, e.g. 22–6
    }

    val lastEngineUpdate: Long get() = sp.getLong("engine_update", 0L)

    fun acceptVideoTerms() {
        videoTermsAccepted = true
    }

    fun markEngineUpdated() {
        sp.edit().putLong("engine_update", System.currentTimeMillis()).apply()
    }
}

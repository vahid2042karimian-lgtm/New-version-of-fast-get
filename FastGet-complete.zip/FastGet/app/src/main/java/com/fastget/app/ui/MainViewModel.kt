package com.fastget.app.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.fastget.app.FastGetApp
import com.fastget.app.core.MediaType
import com.fastget.app.core.SearchCoordinator
import com.fastget.app.core.SearchItem
import com.fastget.app.core.SearchSource
import com.fastget.app.core.Security
import com.fastget.app.core.VideoEngine
import com.fastget.app.core.VideoMeta
import com.fastget.app.data.DownloadEntity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

enum class Screen { HOME, SETTINGS, VIDEO, VAULT, LANGUAGE, BROWSER }

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val fg = app as FastGetApp

    val manager get() = fg.manager
    val prefs get() = fg.prefs

    val downloads: StateFlow<List<DownloadEntity>> =
        fg.db.dao().observeAll()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val live get() = fg.manager.live

    var screen by mutableStateOf(Screen.HOME)
    /** 0 = all, 1 = in progress, 2 = completed, 3 = failed */
    var tab by mutableIntStateOf(0)
    var category by mutableStateOf<String?>(null)

    var showAdd by mutableStateOf(false)
    var prefill by mutableStateOf("")
    /** Optional start URL when opening the in-app browser. */
    var browserStartUrl by mutableStateOf("https://www.google.com")

    /** Last clipboard link we already offered, so we do not nag. */
    var lastClip = ""

    // ---- security ----
    var locked by mutableStateOf(prefs.appLock && Security.available(app))
    var vaultUnlocked by mutableStateOf(false)
    var backgroundedAt = 0L

    // ---- video & music search (Stage 1 multi-engine) ----
    var vQuery by mutableStateOf("")
    /** Type selector next to the search box: VIDEO / AUDIO / TORRENT / ALL */
    var vMediaType by mutableStateOf(MediaType.VIDEO)
    /** Legacy: 0 = music (tap = MP3), 1 = video (tap = choose quality). Kept for download action. */
    var vMode by mutableIntStateOf(1)
    var vSource by mutableStateOf(SearchSource.YOUTUBE)
    var vResults by mutableStateOf<List<SearchItem>>(emptyList())
    var vLoading by mutableStateOf(false)
    var vLoadingMore by mutableStateOf(false)
    var vError by mutableStateOf<String?>(null)
    /** Epoch millis of last completed search (shown in UI). */
    var lastSearchAt by mutableStateOf(0L)
    var vSheetItem by mutableStateOf<SearchItem?>(null)
    var vSheetMeta by mutableStateOf<VideoMeta?>(null)
    /** false = list (پشت‌سرهم), true = grid (تایل) */
    var vGridLayout by mutableStateOf(false)
    /** Selected result URLs for multi-select download. */
    var vSelected by mutableStateOf<Set<String>>(emptySet())
    var vHasMore by mutableStateOf(false)
    private var vPage = 0
    private var vJob: Job? = null
    private val pageSize = 15

    fun runSearch() {
        val q = vQuery.trim()
        if (q.isEmpty()) return
        vJob?.cancel()
        vJob = viewModelScope.launch {
            vLoading = true
            vError = null
            vResults = emptyList()
            vSelected = emptySet()
            vPage = 0
            vHasMore = false
            try {
                if (q.startsWith("http://") || q.startsWith("https://")) {
                    if (q.startsWith("http://") && !prefs.allowHttp) {
                        vError = "لینک http ناامن است. در تنظیمات می‌توانید اجازه بدهید."
                        return@launch
                    }
                    val meta = VideoEngine.inspect(q)
                    vSheetMeta = meta
                    vSheetItem = SearchItem(
                        id = "",
                        title = meta.title,
                        url = q,
                        uploader = meta.uploader,
                        durationSec = meta.durationSec,
                        thumbnail = meta.thumbnail,
                        mediaType = vMediaType.takeIf { it != MediaType.ALL } ?: MediaType.VIDEO,
                        sourceSite = meta.site
                    )
                } else if (q.startsWith("magnet:")) {
                    vResults = listOf(
                        SearchItem(
                            id = "magnet",
                            title = q.take(60),
                            url = q,
                            mediaType = MediaType.TORRENT,
                            sourceSite = "magnet",
                            isDirect = true
                        )
                    )
                    lastSearchAt = System.currentTimeMillis()
                } else {
                    val batch = SearchCoordinator.search(q, vMediaType, prefs, count = pageSize)
                    vResults = batch
                    vPage = 1
                    vHasMore = batch.size >= pageSize
                    lastSearchAt = System.currentTimeMillis()
                    if (vResults.isEmpty()) {
                        vError = com.fastget.app.core.I18n.t("نتیجه‌ای پیدا نشد", "No results")
                    }
                }
            } catch (ce: CancellationException) {
                throw ce
            } catch (t: Throwable) {
                vError = VideoEngine.friendlyError(t)
            } finally {
                vLoading = false
            }
        }
    }

    fun loadMore() {
        val q = vQuery.trim()
        if (q.isEmpty() || vLoadingMore || !vHasMore || vLoading) return
        if (q.startsWith("http") || q.startsWith("magnet:")) return
        vJob = viewModelScope.launch {
            vLoadingMore = true
            try {
                val bigger = pageSize * (vPage + 1)
                val batch = SearchCoordinator.search(q, vMediaType, prefs, count = bigger)
                val existing = vResults.map { it.url }.toSet()
                val added = batch.filter { it.url !in existing }
                if (added.isEmpty()) {
                    vHasMore = false
                } else {
                    vResults = vResults + added
                    vPage += 1
                    vHasMore = batch.size >= bigger
                }
            } catch (_: CancellationException) {
                // ignore
            } catch (t: Throwable) {
                vError = VideoEngine.friendlyError(t)
            } finally {
                vLoadingMore = false
            }
        }
    }

    fun toggleSelect(item: SearchItem) {
        val key = item.url
        vSelected = if (key in vSelected) vSelected - key else vSelected + key
    }

    fun clearSelection() {
        vSelected = emptySet()
    }

    fun enqueueSelected() {
        val items = vResults.filter { it.url in vSelected }
        for (item in items) {
            when (item.mediaType) {
                MediaType.AUDIO ->
                    manager.enqueueVideo(item.url, item.title, item.thumbnail, "a:mp3", false)
                MediaType.TORRENT ->
                    manager.enqueueTorrent(item.url, item.title, autoStart = false)
                else ->
                    manager.enqueueVideo(item.url, item.title, item.thumbnail, "v:best", false)
            }
        }
        vSelected = emptySet()
    }

    fun openQualitySheet(item: SearchItem) {
        vSheetMeta = null
        vSheetItem = item
    }

    fun openAdd(text: String = "") {
        prefill = text
        showAdd = true
    }
}

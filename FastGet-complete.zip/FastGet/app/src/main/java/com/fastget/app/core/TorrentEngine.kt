package com.fastget.app.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

/**
 * Searches torrent indexers listed in Settings (sites_torrent).
 * Best-effort HTML scrape; returns magnet or detail-page links.
 */
object TorrentEngine {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private val magnetPattern = Pattern.compile(
        """(magnet:\?xt=urn:btih:[a-zA-Z0-9]+)[^"'\s<]*""",
        Pattern.CASE_INSENSITIVE
    )
    private val hrefPattern = Pattern.compile(
        """href=["']([^"']+)["']""",
        Pattern.CASE_INSENSITIVE
    )

    suspend fun search(query: String, hosts: List<String>, count: Int = 15): List<SearchItem> =
        withContext(Dispatchers.IO) {
            val q = query.trim().take(80)
            if (q.isEmpty() || hosts.isEmpty()) return@withContext emptyList()

            coroutineScope {
                hosts.take(4).map { host ->
                    async { searchOneHost(host, q, count) }
                }.awaitAll().flatten()
                    .distinctBy { it.url }
                    .take(count)
            }
        }

    private fun searchOneHost(host: String, query: String, limit: Int): List<SearchItem> {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val candidates = when {
            host.contains("1337x") -> listOf(
                "https://$host/search/$encoded/1/",
                "https://www.$host/search/$encoded/1/"
            )
            host.contains("nyaa") -> listOf(
                "https://$host/?f=0&c=0_0&q=$encoded",
                "https://$host/?q=$encoded"
            )
            host.contains("yts") || host.contains("yify") -> listOf(
                "https://$host/browse-movies/$encoded",
                "https://$host/api/v2/list_movies.json?query_term=$encoded"
            )
            host.contains("torrentgalaxy") -> listOf(
                "https://$host/torrents.php?search=$encoded"
            )
            else -> listOf(
                "https://$host/search/$encoded/1/",
                "https://$host/search?q=$encoded",
                "https://$host/?q=$encoded",
                "https://$host/search/$encoded"
            )
        }
        for (url in candidates) {
            val html = fetch(url) ?: continue
            val items = parsePage(html, host, limit)
            if (items.isNotEmpty()) return items
        }
        return emptyList()
    }

    private fun fetch(url: String): String? {
        return try {
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36")
                .get()
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return null
                resp.body?.string()
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun parsePage(html: String, host: String, limit: Int): List<SearchItem> {
        val out = mutableListOf<SearchItem>()
        // Magnets first
        val mm = magnetPattern.matcher(html)
        var i = 0
        while (mm.find() && out.size < limit) {
            val magnet = mm.group(1) ?: continue
            val title = "Torrent from $host #${++i}"
            out.add(
                SearchItem(
                    id = "t$i-${magnet.hashCode()}",
                    title = title,
                    url = magnet,
                    uploader = host,
                    mediaType = MediaType.TORRENT,
                    sourceSite = host,
                    isDirect = true
                )
            )
        }
        // Fallback: detail links that look like torrent pages
        if (out.size < 3) {
            val hm = hrefPattern.matcher(html)
            while (hm.find() && out.size < limit) {
                var href = hm.group(1) ?: continue
                if (href.startsWith("/")) href = "https://$host$href"
                if (!href.startsWith("http")) continue
                val lower = href.lowercase()
                if (lower.contains("/torrent") || lower.contains("/download") || lower.contains("magnet")) {
                    out.add(
                        SearchItem(
                            id = "tp-${href.hashCode()}",
                            title = href.substringAfterLast('/').take(60).ifBlank { host },
                            url = href,
                            uploader = host,
                            mediaType = MediaType.TORRENT,
                            sourceSite = host,
                            isDirect = href.startsWith("magnet:")
                        )
                    )
                }
            }
        }
        return out.distinctBy { it.url }
    }
}

package com.fastget.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

object Status {
    const val QUEUED = "QUEUED"
    const val DOWNLOADING = "DOWNLOADING"
    const val PAUSED = "PAUSED"
    const val COMPLETED = "COMPLETED"
    const val FAILED = "FAILED"
}

object Kind {
    const val FILE = "FILE"
    /** Handled by the yt-dlp engine (YouTube and other video/audio sites). */
    const val VIDEO = "VIDEO"
    /** Magnet or .torrent — handled by libtorrent4j. */
    const val TORRENT = "TORRENT"
}

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val url: String,
    val fileName: String,
    val category: String,
    val localPath: String = "",
    val totalBytes: Long = -1,
    val downloadedBytes: Long = 0,
    val status: String = Status.QUEUED,
    /** "start:end:done;start:end:done;..." — per-segment resume state. */
    val segments: String = "",
    val acceptRanges: Boolean = false,
    val etag: String? = null,
    val lastModified: String? = null,
    val error: String? = null,
    /** content:// Uri when the finished file was moved to the public Downloads folder. */
    val publicUri: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val finishedAt: Long = 0,
    val kind: String = Kind.FILE,
    /** "a:mp3", "a:m4a", "v:1080", "v:best" ... (VIDEO kind only). */
    val formatSpec: String = "",
    /** Private items live in app-internal storage and only show in the locked vault. */
    val isPrivate: Boolean = false,
    val thumbnail: String? = null,
    /**
     * Queue priority. Higher number = starts sooner.
     * Default 0. User can raise/lower from the card menu.
     */
    val priority: Int = 0
)

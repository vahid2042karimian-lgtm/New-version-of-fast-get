package com.fastget.app.core

/**
 * Shared models for the multi-engine search system (Stage 1).
 * All engines return the same SearchItem shape so UI stays simple.
 */

/** What the user asked for in the type selector next to the search box. */
enum class MediaType(val labelFa: String, val labelEn: String) {
    VIDEO("ویدیو", "Video"),
    AUDIO("صدا", "Audio"),
    TORRENT("تورنت", "Torrent"),
    ALL("همه", "All")
}

/** Category of a site stored in Settings. */
enum class SiteCategory(val key: String, val labelFa: String) {
    VIDEO("video", "سایت‌های ویدیویی"),
    PORN("porn", "سایت‌های پورن"),
    AUDIO("audio", "سایت‌های صوتی"),
    TORRENT("torrent", "سایت‌های تورنت")
}

/**
 * One site entry the user can add in Settings.
 * @param host bare domain, e.g. "pornhub.com" or "youtube.com"
 * @param needsAgeGate true if the site shows an 18+ interstitial that must be bypassed
 * @param searchPath optional path template; empty = use yt-dlp extractor when available
 */
data class SiteEntry(
    val host: String,
    val category: SiteCategory,
    val needsAgeGate: Boolean = false,
    val searchPath: String = ""
)

/**
 * Unified search result used by Video / Audio / Torrent / Google engines.
 */
data class SearchItem(
    val id: String,
    val title: String,
    val url: String,
    val uploader: String = "",
    val durationSec: Long = 0L,
    val thumbnail: String? = null,
    /** VIDEO / AUDIO / TORRENT */
    val mediaType: MediaType = MediaType.VIDEO,
    /** Short site label, e.g. "youtube", "pornhub", "google" — not shown as full list in UI */
    val sourceSite: String = "",
    val sizeBytes: Long = 0L,
    val seeds: Int = 0,
    val quality: String = "",
    val isDirect: Boolean = false
)

data class VideoMeta(
    val title: String,
    val uploader: String,
    val durationSec: Long,
    val thumbnail: String?,
    val heights: List<Int>,
    val site: String
)

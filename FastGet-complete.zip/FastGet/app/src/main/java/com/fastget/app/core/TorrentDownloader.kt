package com.fastget.app.core

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import org.libtorrent4j.AlertListener
import org.libtorrent4j.SessionManager
import org.libtorrent4j.TorrentHandle
import org.libtorrent4j.TorrentInfo
import org.libtorrent4j.alerts.AddTorrentAlert
import org.libtorrent4j.alerts.Alert
import org.libtorrent4j.alerts.AlertType
import org.libtorrent4j.alerts.TorrentFinishedAlert
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * Shared libtorrent4j session for magnet and .torrent downloads.
 */
object TorrentDownloader {

    @Volatile private var session: SessionManager? = null
    private val cancelFlags = ConcurrentHashMap<Long, AtomicBoolean>()
    private val finishedHashes = ConcurrentHashMap.newKeySet<String>()

    @Synchronized
    fun ensureStarted(ctx: Context) {
        if (session != null) return
        val sm = SessionManager()
        sm.addListener(object : AlertListener {
            override fun types(): IntArray? = null
            override fun alert(alert: Alert<*>) {
                when (alert.type()) {
                    AlertType.ADD_TORRENT -> {
                        try {
                            (alert as? AddTorrentAlert)?.handle()?.resume()
                        } catch (_: Throwable) { }
                    }
                    AlertType.TORRENT_FINISHED -> {
                        try {
                            val h = (alert as? TorrentFinishedAlert)?.handle()
                            val hash = h?.infoHash()?.toString()
                            if (hash != null) finishedHashes.add(hash)
                        } catch (_: Throwable) { }
                    }
                    else -> Unit
                }
            }
        })
        sm.start()
        session = sm
    }

    /**
     * Download magnet / .torrent URL into [saveDir].
     * [onProgress]: downloadedBytes, totalBytes, speedBytesPerSec
     */
    suspend fun download(
        id: Long,
        magnetOrUrl: String,
        saveDir: File,
        onProgress: (Long, Long, Long) -> Unit
    ) = withContext(Dispatchers.IO) {
        val sm = session ?: throw IllegalStateException("موتور تورنت آماده نیست")
        saveDir.mkdirs()
        val cancel = AtomicBoolean(false)
        cancelFlags[id] = cancel

        try {
            val uri = magnetOrUrl.trim()
            val ti: TorrentInfo = when {
                uri.startsWith("magnet:", ignoreCase = true) -> {
                    val meta = sm.fetchMagnet(uri, 120, saveDir)
                        ?: throw java.io.IOException("متادیتای مگنت دریافت نشد")
                    TorrentInfo.bdecode(meta)
                }
                (uri.startsWith("http://") || uri.startsWith("https://")) &&
                    uri.contains(".torrent", ignoreCase = true) -> {
                    val bytes = httpGetBytes(uri)
                    TorrentInfo.bdecode(bytes)
                }
                File(uri.removePrefix("file://")).isFile -> {
                    TorrentInfo(File(uri.removePrefix("file://")))
                }
                else -> {
                    val magnet = if (uri.length in 32..64 && uri.all { it.isLetterOrDigit() }) {
                        "magnet:?xt=urn:btih:$uri"
                    } else uri
                    val meta = sm.fetchMagnet(magnet, 120, saveDir)
                        ?: throw java.io.IOException("متادیتای تورنت دریافت نشد")
                    TorrentInfo.bdecode(meta)
                }
            }

            val hashStr = ti.infoHash().toString()
            finishedHashes.remove(hashStr)
            sm.download(ti, saveDir)

            var lastBytes = 0L
            var lastTs = System.currentTimeMillis()
            val total = ti.totalSize().coerceAtLeast(0)

            while (true) {
                if (cancel.get() || !currentCoroutineContext().isActive) {
                    try {
                        val h = sm.find(ti.infoHash())
                        if (h != null && h.isValid) {
                            h.pause()
                            sm.remove(h)
                        }
                    } catch (_: Throwable) { }
                    throw java.util.concurrent.CancellationException("torrent cancelled")
                }

                if (finishedHashes.contains(hashStr)) break

                try {
                    val h = sm.find(ti.infoHash())
                    if (h != null && h.isValid) {
                        val st = h.status()
                        val down = st.totalDone()
                        val now = System.currentTimeMillis()
                        val dt = (now - lastTs).coerceAtLeast(1)
                        val speed = ((down - lastBytes) * 1000L / dt).coerceAtLeast(0)
                        lastBytes = down
                        lastTs = now
                        onProgress(down, if (total > 0) total else st.totalWanted(), speed)
                        if (st.isFinished || st.isSeeding) break
                    }
                } catch (_: Throwable) { }

                delay(1000)
            }
            onProgress(if (total > 0) total else lastBytes, if (total > 0) total else lastBytes, 0)
        } finally {
            cancelFlags.remove(id)
        }
    }

    fun cancel(id: Long) {
        cancelFlags[id]?.set(true)
    }

    private fun httpGetBytes(url: String): ByteArray {
        val client = okhttp3.OkHttpClient.Builder()
            .connectTimeout(20, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(40, java.util.concurrent.TimeUnit.SECONDS)
            .build()
        val req = okhttp3.Request.Builder().url(url).get().build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw java.io.IOException("دانلود .torrent ناموفق: HTTP ${resp.code}")
            return resp.body?.bytes() ?: throw java.io.IOException("فایل تورنت خالی است")
        }
    }
}

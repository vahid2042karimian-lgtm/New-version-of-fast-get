package com.fastget.app.core

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.fastget.app.FastGetApp
import com.fastget.app.R
import com.fastget.app.data.Status
import com.fastget.app.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

/** Keeps the process alive while downloads run and shows one progress notification. */
class DownloadService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var watcher: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val app = application as FastGetApp
        if (intent?.action == ACTION_PAUSE_ALL) app.manager.pauseAll()

        goForeground(buildNotification(0, 0, 0L, -1))

        if (watcher == null) {
            watcher = scope.launch {
                combine(app.db.dao().observeAll(), app.manager.live) { list, live -> list to live }
                    .collect { (list, live) ->
                        val active = list.filter { it.status == Status.DOWNLOADING }
                        if (active.isEmpty()) {
                            stopForeground(STOP_FOREGROUND_REMOVE)
                            stopSelf()
                            return@collect
                        }
                        val speed = live.values.sumOf { it.speed }
                        val known = active.filter { it.totalBytes > 0 }
                        val total = known.sumOf { it.totalBytes }
                        val done = known.sumOf { it.downloadedBytes }
                        val pct = if (total > 0) (done * 100 / total).toInt() else -1
                        val n = buildNotification(active.size, speed, done, pct)
                        getSystemService(android.app.NotificationManager::class.java)
                            .notify(NOTIF_ID, n)
                    }
            }
        }
        return START_NOT_STICKY
    }

    private fun goForeground(n: Notification) {
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun buildNotification(count: Int, speed: Long, done: Long, pct: Int): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val pause = PendingIntent.getService(
            this, 1,
            Intent(this, DownloadService::class.java).setAction(ACTION_PAUSE_ALL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = NotificationCompat.Builder(this, FastGetApp.CHANNEL_DOWNLOADS)
            .setSmallIcon(R.drawable.ic_stat_download)
            .setContentTitle(if (count == 0) "تندگیر" else "${fa(count)} دانلود فعال")
            .setContentText(if (count == 0) "در حال آماده‌سازی…" else fa(formatSpeed(speed)))
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .addAction(0, "توقف همه", pause)
        if (pct >= 0) b.setProgress(100, pct, false) else b.setProgress(0, 0, count > 0)
        return b.build()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val NOTIF_ID = 1001
        private const val ACTION_PAUSE_ALL = "com.fastget.app.PAUSE_ALL"

        fun start(context: Context) {
            runCatching {
                ContextCompat.startForegroundService(
                    context, Intent(context, DownloadService::class.java)
                )
            }
        }
    }
}

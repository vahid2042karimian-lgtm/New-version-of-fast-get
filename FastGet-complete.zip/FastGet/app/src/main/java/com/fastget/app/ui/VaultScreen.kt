package com.fastget.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fastget.app.core.Security
import com.fastget.app.data.DownloadEntity
import com.fastget.app.ui.theme.ColorBad

/** Private downloads: shown only after the phone's biometric / screen-lock check. */
@Composable
fun VaultScreen(vm: MainViewModel, auth: AuthFn) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val items by vm.downloads.collectAsStateWithLifecycle()
    val live by vm.live.collectAsStateWithLifecycle()
    val supported = remember { Security.available(ctx) }
    var confirm by remember { mutableStateOf<DownloadEntity?>(null) }

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.screen = Screen.HOME }) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "بازگشت")
            }
            Text("پوشهٔ خصوصی", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }

        if (!supported) {
            Gate("برای استفاده از پوشهٔ خصوصی، اول در تنظیمات گوشی یک قفل صفحه یا اثرانگشت فعال کنید.", null)
            return@Column
        }
        if (!vm.vaultUnlocked) {
            LaunchedEffect(Unit) { auth("باز کردن پوشهٔ خصوصی") { vm.vaultUnlocked = true } }
            Gate("پوشهٔ خصوصی قفل است.", "باز کردن") {
                auth("باز کردن پوشهٔ خصوصی") { vm.vaultUnlocked = true }
            }
            return@Column
        }

        val mine = items.filter { it.isPrivate }
        if (mine.isEmpty()) {
            Gate("اینجا خالی است. هنگام دانلود ویدیو یا موسیقی، گزینهٔ «ذخیره در پوشهٔ خصوصی» را روشن کنید.", null)
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(top = 8.dp, bottom = 32.dp)
            ) {
                items(mine, key = { it.id }) { e ->
                    DownloadCard(e, live[e.id], vm, onDelete = { confirm = e })
                }
            }
        }
    }

    confirm?.let { e ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            containerColor = cs.surface,
            title = { Text("حذف از پوشهٔ خصوصی") },
            text = { Text("فایل برای همیشه پاک می‌شود.") },
            confirmButton = {
                TextButton(onClick = { vm.manager.delete(e.id, true); confirm = null }) {
                    Text("حذف", color = ColorBad)
                }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("انصراف") } }
        )
    }
}

@Composable
private fun Gate(message: String, action: String?, onAction: () -> Unit = {}) {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 56.dp, horizontal = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Rounded.Lock, null, Modifier.size(56.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(14.dp))
        Text(message, textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium)
        if (action != null) {
            Spacer(Modifier.height(16.dp))
            Button(onClick = onAction) { Text(action) }
        }
    }
}

package com.fastget.app.ui

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.fastget.app.core.I18n

/**
 * Lightweight Chrome-like in-app browser.
 * - Address bar, back / forward, reload, home
 * - Simple tabs
 * - Extract links → only add to download queue (no auto-start)
 * - Current page → only add (no auto-start)
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun BrowserScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val start = vm.browserStartUrl.ifBlank { "https://www.google.com" }

    var tabs by remember { mutableStateOf(listOf(start)) }
    var tabIndex by remember { mutableIntStateOf(0) }
    var urlBar by remember(start) { mutableStateOf(start) }
    var currentUrl by remember(start) { mutableStateOf(start) }
    var progress by remember { mutableFloatStateOf(0f) }
    var webView by remember { mutableStateOf<WebView?>(null) }
    var canGoBack by remember { mutableStateOf(false) }
    var canGoForward by remember { mutableStateOf(false) }
    var extracted by remember { mutableStateOf<List<String>>(emptyList()) }
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
    var showLinks by remember { mutableStateOf(false) }

    fun navigate(u: String) {
        val norm = normalizeUrl(u)
        urlBar = norm
        currentUrl = norm
        tabs = tabs.toMutableList().also { if (tabIndex in it.indices) it[tabIndex] = norm }
        webView?.loadUrl(norm)
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        // Top bar: exit + address + actions
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { vm.screen = Screen.HOME }) {
                Icon(Icons.Rounded.Close, contentDescription = "بستن")
            }
            OutlinedTextField(
                value = urlBar,
                onValueChange = { urlBar = it },
                modifier = Modifier.weight(1f).height(52.dp),
                singleLine = true,
                shape = RoundedCornerShape(24.dp),
                textStyle = MaterialTheme.typography.bodySmall,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { navigate(urlBar) })
            )
            IconButton(onClick = { webView?.reload() }) {
                Icon(Icons.Rounded.Refresh, contentDescription = "بارگذاری مجدد")
            }
            IconButton(onClick = {
                // Only add to queue — do not start
                val link = currentUrl.ifBlank { urlBar }
                if (link.startsWith("http")) {
                    vm.manager.enqueue(listOf(link), autoStart = false)
                    Toast.makeText(ctx, "به صف دانلود اضافه شد (بدون شروع)", Toast.LENGTH_SHORT).show()
                }
            }) {
                Icon(Icons.Rounded.Download, contentDescription = "افزودن به دانلود")
            }
        }

        // Nav row: back / forward / home / extract / copy
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { webView?.goBack() },
                enabled = canGoBack
            ) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "قبلی") }
            IconButton(
                onClick = { webView?.goForward() },
                enabled = canGoForward
            ) { Icon(Icons.AutoMirrored.Rounded.ArrowForward, contentDescription = "بعدی") }
            IconButton(onClick = { navigate("https://www.google.com") }) {
                Icon(Icons.Rounded.Home, contentDescription = "خانه")
            }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = {
                val link = currentUrl.ifBlank { urlBar }
                ctx.getSystemService(ClipboardManager::class.java)
                    .setPrimaryClip(ClipData.newPlainText("url", link))
                // Also queue without starting
                if (link.startsWith("http")) {
                    vm.manager.enqueue(listOf(link), autoStart = false)
                    Toast.makeText(ctx, "کپی و اضافه به صف (بدون شروع)", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(ctx, I18n.linkCopied, Toast.LENGTH_SHORT).show()
                }
            }) {
                Icon(Icons.Rounded.ContentCopy, contentDescription = "کپی")
            }
            IconButton(onClick = {
                val wv = webView ?: return@IconButton
                wv.evaluateJavascript(EXTRACT_LINKS_JS) { raw ->
                    val links = parseJsStringArray(raw)
                    if (links.isEmpty()) {
                        Toast.makeText(ctx, I18n.noLinksFound, Toast.LENGTH_SHORT).show()
                    } else {
                        extracted = links
                        selected = links.toSet()
                        showLinks = true
                    }
                }
            }) {
                Icon(Icons.Rounded.Link, contentDescription = "استخراج لینک")
            }
        }

        // Simple tabs strip
        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            tabs.forEachIndexed { i, t ->
                val label = try {
                    java.net.URI(t).host?.removePrefix("www.") ?: t
                } catch (_: Throwable) {
                    t.take(18)
                }
                val selectedTab = i == tabIndex
                Row(
                    Modifier
                        .padding(end = 6.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            if (selectedTab) MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                        .clickable {
                            tabIndex = i
                            navigate(tabs[i])
                        }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        label.take(16),
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (tabs.size > 1) {
                        Spacer(Modifier.width(4.dp))
                        Icon(
                            Icons.Rounded.Close,
                            contentDescription = "بستن تب",
                            modifier = Modifier
                                .size(14.dp)
                                .clickable {
                                    val next = tabs.toMutableList().also { it.removeAt(i) }
                                    tabs = next
                                    tabIndex = tabIndex.coerceAtMost(next.lastIndex)
                                    if (next.isNotEmpty()) navigate(next[tabIndex])
                                }
                        )
                    }
                }
            }
            IconButton(
                onClick = {
                    tabs = tabs + "https://www.google.com"
                    tabIndex = tabs.lastIndex
                    navigate("https://www.google.com")
                },
                modifier = Modifier.size(32.dp)
            ) {
                Icon(Icons.Rounded.Add, contentDescription = "تب جدید", modifier = Modifier.size(18.dp))
            }
        }

        if (progress in 0.01f..0.99f) {
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth()
            )
        }

        AndroidView(
            factory = { context ->
                WebView(context).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = true
                    settings.setSupportMultipleWindows(false)
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(
                            view: WebView?,
                            request: WebResourceRequest?
                        ): Boolean {
                            val u = request?.url?.toString() ?: return false
                            currentUrl = u
                            urlBar = u
                            canGoBack = view?.canGoBack() == true
                            canGoForward = view?.canGoForward() == true
                            return false
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            if (url != null) {
                                currentUrl = url
                                urlBar = url
                                tabs = tabs.toMutableList().also {
                                    if (tabIndex in it.indices) it[tabIndex] = url
                                }
                            }
                            canGoBack = view?.canGoBack() == true
                            canGoForward = view?.canGoForward() == true
                        }
                    }
                    webChromeClient = object : WebChromeClient() {
                        override fun onProgressChanged(view: WebView?, newProgress: Int) {
                            progress = newProgress / 100f
                        }
                    }
                    loadUrl(currentUrl)
                    webView = this
                }
            },
            modifier = Modifier.weight(1f).fillMaxWidth(),
            update = { /* keep instance */ }
        )
    }

    if (showLinks) {
        AlertDialog(
            onDismissRequest = { showLinks = false },
            title = { Text("${extracted.size} ${I18n.linksFound}") },
            text = {
                Column {
                    TextButton(onClick = {
                        selected = if (selected.size == extracted.size) emptySet() else extracted.toSet()
                    }) { Text(I18n.selectAll) }
                    Spacer(Modifier.height(4.dp))
                    LazyColumn(modifier = Modifier.height(280.dp)) {
                        items(extracted, key = { it }) { link ->
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selected = if (link in selected) selected - link else selected + link
                                    }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = link in selected,
                                    onCheckedChange = {
                                        selected = if (it) selected + link else selected - link
                                    }
                                )
                                Text(
                                    link,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val list = selected.toList()
                    if (list.isNotEmpty()) {
                        // Only add — do not start download
                        vm.manager.enqueue(list, autoStart = false)
                        Toast.makeText(
                            ctx,
                            "${list.size} لینک به صف اضافه شد (بدون شروع)",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    showLinks = false
                }) { Text(I18n.addSelected) }
            },
            dismissButton = {
                TextButton(onClick = { showLinks = false }) { Text(I18n.cancel) }
            }
        )
    }
}

private const val EXTRACT_LINKS_JS = """
(function() {
  var set = {};
  var out = [];
  function add(u) {
    if (!u) return;
    u = u.trim();
    if (u.indexOf('http://') !== 0 && u.indexOf('https://') !== 0) return;
    if (set[u]) return;
    set[u] = 1;
    out.push(u);
  }
  var anchors = document.querySelectorAll('a[href]');
  for (var i = 0; i < anchors.length; i++) add(anchors[i].href);
  var media = document.querySelectorAll('video[src], audio[src], source[src]');
  for (var j = 0; j < media.length; j++) add(media[j].src);
  return JSON.stringify(out.slice(0, 200));
})();
"""

private fun parseJsStringArray(raw: String?): List<String> {
    if (raw.isNullOrBlank() || raw == "null") return emptyList()
    var s = raw.trim()
    if (s.startsWith("\"") && s.endsWith("\"")) {
        s = s.substring(1, s.length - 1)
            .replace("\\\"", "\"")
            .replace("\\\\", "\\")
    }
    return try {
        val arr = org.json.JSONArray(s)
        buildList {
            for (i in 0 until arr.length()) {
                val u = arr.optString(i)
                if (u.startsWith("http")) add(u)
            }
        }.distinct()
    } catch (_: Exception) {
        emptyList()
    }
}

private fun normalizeUrl(raw: String): String {
    val t = raw.trim()
    if (t.isEmpty()) return "https://www.google.com"
    if (t.startsWith("http://") || t.startsWith("https://")) return t
    if (t.contains(" ") || !t.contains(".")) {
        return "https://www.google.com/search?q=" + java.net.URLEncoder.encode(t, "UTF-8")
    }
    return "https://$t"
}

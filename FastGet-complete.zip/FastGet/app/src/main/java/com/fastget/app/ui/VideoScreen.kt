package com.fastget.app.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.ViewList
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.snapshotFlow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.fastget.app.core.EngineState
import com.fastget.app.core.SearchItem
import com.fastget.app.core.Security
import com.fastget.app.core.VideoEngine
import com.fastget.app.core.fa
import com.fastget.app.core.formatEta
import com.fastget.app.ui.theme.ColorBad

@Composable
fun VideoScreen(vm: MainViewModel) {
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val engine by VideoEngine.state.collectAsState()

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.screen = Screen.HOME }) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "بازگشت")
            }
            Text(
                "جستجو",
                Modifier.weight(1f),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            IconButton(onClick = {
                vm.browserStartUrl = "https://www.google.com"
                vm.screen = Screen.BROWSER
            }) {
                Icon(Icons.Rounded.Public, contentDescription = "مرورگر")
            }
        }

        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = vm.vQuery,
                onValueChange = { vm.vQuery = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                placeholder = { Text("نام آهنگ، ویدیو، شخص یا لینک") },
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { vm.runSearch() })
            )
        }
        Spacer(Modifier.height(8.dp))
        // Type selector next to search (Video / Audio / Torrent / All) — site names not shown
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            com.fastget.app.core.MediaType.entries.forEach { t ->
                FilterChip(
                    selected = vm.vMediaType == t,
                    onClick = {
                        vm.vMediaType = t
                        vm.vMode = if (t == com.fastget.app.core.MediaType.AUDIO) 0 else 1
                    },
                    label = { Text(t.labelFa) },
                    colors = videoChipColors()
                )
            }
        }
        // Layout toggle + selection bar
        if (vm.vResults.isNotEmpty()) {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "${vm.vResults.size} نتیجه" + if (vm.vSelected.isNotEmpty()) " · ${vm.vSelected.size} انتخاب" else "",
                    style = MaterialTheme.typography.labelMedium,
                    color = cs.onSurfaceVariant
                )
                Row {
                    if (vm.vSelected.isNotEmpty()) {
                        IconButton(onClick = {
                            vm.enqueueSelected()
                            Toast.makeText(ctx, "به صف دانلود اضافه شد", Toast.LENGTH_SHORT).show()
                        }) {
                            Icon(Icons.Rounded.Download, "دانلود انتخاب‌شده‌ها", tint = cs.primary)
                        }
                        TextButton(onClick = { vm.clearSelection() }) { Text("لغو") }
                    }
                    IconButton(onClick = { vm.vGridLayout = !vm.vGridLayout }) {
                        Icon(
                            if (vm.vGridLayout) Icons.Rounded.ViewList else Icons.Rounded.GridView,
                            contentDescription = "تغییر چینش"
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(6.dp))

        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                engine is EngineState.Initializing -> Hint("در حال آماده‌سازی موتور ویدیو. بار اول چند ثانیه طول می‌کشد.")
                engine is EngineState.Failed -> Hint("موتور ویدیو بالا نیامد: ${(engine as EngineState.Failed).message}", ColorBad)
                vm.vLoading -> Column(
                    Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) { CircularProgressIndicator(color = cs.primary) }
                vm.vError != null && vm.vResults.isEmpty() -> Hint(vm.vError!!, ColorBad)
                vm.vResults.isEmpty() -> Hint(
                    "نام آهنگ، ویدیو یا شخص را بنویسید و نوع فایل را انتخاب کنید، یا لینک را بچسبانید."
                )
                vm.vGridLayout -> ResultsGrid(vm, ctx)
                else -> ResultsList(vm, ctx)
            }
        }
        Text(
            "فقط محتوایی را دانلود کنید که اجازهٔ استفاده‌اش را دارید.",
            style = MaterialTheme.typography.labelSmall,
            color = cs.onSurfaceVariant,
            modifier = Modifier.padding(vertical = 8.dp).navigationBarsPadding()
        )
    }

    vm.vSheetItem?.let { QualitySheet(vm, it) }

    if (!vm.prefs.videoTermsAccepted) {
        AlertDialog(
            onDismissRequest = { vm.screen = Screen.HOME },
            containerColor = cs.surface,
            title = { Text("قبل از شروع") },
            text = {
                Text(
                    "دانلود از بعضی سایت‌ها شرایط استفادهٔ آن‌ها را نقض می‌کند و دانلود محتوای دارای " +
                        "حق نشر بدون اجازه ممکن است غیرقانونی باشد. مسئولیت استفاده با خود شماست."
                )
            },
            confirmButton = { TextButton(onClick = { vm.prefs.acceptVideoTerms() }) { Text("متوجه شدم") } },
            dismissButton = { TextButton(onClick = { vm.screen = Screen.HOME }) { Text("بازگشت") } }
        )
    }
}

@Composable
private fun ResultsList(vm: MainViewModel, ctx: android.content.Context) {
    val listState = rememberLazyListState()
    LaunchedEffect(listState, vm.vResults.size) {
        snapshotFlow {
            val info = listState.layoutInfo
            val last = info.visibleItemsInfo.lastOrNull()?.index ?: 0
            last >= info.totalItemsCount - 3
        }.collect { nearEnd ->
            if (nearEnd) vm.loadMore()
        }
    }
    LazyColumn(
        state = listState,
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 24.dp)
    ) {
        items(vm.vResults, key = { it.url }) { item ->
            val selected = item.url in vm.vSelected
            ResultRow(
                item = item,
                selected = selected,
                onRowClick = {
                    if (vm.vSelected.isNotEmpty()) {
                        vm.toggleSelect(item)
                    } else if (vm.vMode == 0 || item.mediaType == com.fastget.app.core.MediaType.AUDIO) {
                        vm.manager.enqueueVideo(item.url, item.title, item.thumbnail, "a:mp3", false)
                        Toast.makeText(ctx, "MP3 به صف دانلود اضافه شد", Toast.LENGTH_SHORT).show()
                    } else if (item.mediaType == com.fastget.app.core.MediaType.TORRENT) {
                        vm.manager.enqueueTorrent(item.url, item.title, autoStart = false)
                        Toast.makeText(ctx, "تورنت به صف اضافه شد", Toast.LENGTH_SHORT).show()
                    } else {
                        vm.openQualitySheet(item)
                    }
                },
                onLongClick = { vm.toggleSelect(item) },
                onMp3 = {
                    vm.manager.enqueueVideo(item.url, item.title, item.thumbnail, "a:mp3", false)
                    Toast.makeText(ctx, "MP3 به صف دانلود اضافه شد", Toast.LENGTH_SHORT).show()
                },
                onVideo = { vm.openQualitySheet(item) }
            )
        }
        if (vm.vLoadingMore) {
            item {
                Box(Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(Modifier.size(28.dp))
                }
            }
        } else if (vm.vHasMore) {
            item {
                TextButton(
                    onClick = { vm.loadMore() },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("نتایج بیشتر") }
            }
        }
    }
}

@Composable
private fun ResultsGrid(vm: MainViewModel, ctx: android.content.Context) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(150.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 24.dp)
    ) {
        gridItems(vm.vResults, key = { it.url }) { item ->
            val selected = item.url in vm.vSelected
            ResultTile(
                item = item,
                selected = selected,
                onClick = {
                    if (vm.vSelected.isNotEmpty()) {
                        vm.toggleSelect(item)
                    } else if (item.mediaType == com.fastget.app.core.MediaType.AUDIO) {
                        vm.manager.enqueueVideo(item.url, item.title, item.thumbnail, "a:mp3", false)
                        Toast.makeText(ctx, "MP3 اضافه شد", Toast.LENGTH_SHORT).show()
                    } else if (item.mediaType == com.fastget.app.core.MediaType.TORRENT) {
                        vm.manager.enqueueTorrent(item.url, item.title, autoStart = false)
                        Toast.makeText(ctx, "تورنت اضافه شد", Toast.LENGTH_SHORT).show()
                    } else {
                        vm.openQualitySheet(item)
                    }
                },
                onLongClick = { vm.toggleSelect(item) }
            )
        }
        if (vm.vHasMore) {
            item {
                TextButton(onClick = { vm.loadMore() }) { Text("بیشتر") }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ResultTile(item: SearchItem, selected: Boolean, onClick: () -> Unit, onLongClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = cs.surface),
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (selected) Modifier.border(2.dp, cs.primary, RoundedCornerShape(14.dp))
                else Modifier
            )
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        Column {
            Box {
                AsyncImage(
                    model = item.thumbnail,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(96.dp)
                        .background(cs.surfaceVariant)
                )
                if (selected) {
                    Icon(
                        Icons.Rounded.CheckCircle,
                        contentDescription = null,
                        tint = cs.primary,
                        modifier = Modifier.align(Alignment.TopEnd).padding(6.dp)
                    )
                }
            }
            Text(
                item.title,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
            )
            val kind = when (item.mediaType) {
                com.fastget.app.core.MediaType.AUDIO -> "صدا"
                com.fastget.app.core.MediaType.TORRENT -> "تورنت"
                else -> "ویدیو"
            }
            Text(
                kind,
                style = MaterialTheme.typography.labelSmall,
                color = cs.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}

@Composable
private fun videoChipColors() = FilterChipDefaults.filterChipColors(
    containerColor = MaterialTheme.colorScheme.surface,
    labelColor = MaterialTheme.colorScheme.onSurfaceVariant,
    selectedContainerColor = MaterialTheme.colorScheme.primary,
    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
)

@Composable
private fun Hint(text: String, color: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onSurfaceVariant) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Text(text, color = color, style = MaterialTheme.typography.bodyMedium)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ResultRow(
    item: SearchItem,
    selected: Boolean,
    onRowClick: () -> Unit,
    onLongClick: () -> Unit,
    onMp3: () -> Unit,
    onVideo: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = cs.surface),
        modifier = Modifier
            .fillMaxWidth()
            .then(if (selected) Modifier.border(2.dp, cs.primary, RoundedCornerShape(16.dp)) else Modifier)
            .combinedClickable(onClick = onRowClick, onLongClick = onLongClick)
    ) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box {
                AsyncImage(
                    model = item.thumbnail,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(width = 104.dp, height = 58.dp)
                        .clip(RoundedCornerShape(10.dp)).background(cs.surfaceVariant)
                )
                if (selected) {
                    Icon(
                        Icons.Rounded.CheckCircle,
                        contentDescription = null,
                        tint = cs.primary,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    item.title, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold
                )
                val dur = if (item.durationSec > 0) fa(formatEta(item.durationSec)) else ""
                val kind = when (item.mediaType) {
                    com.fastget.app.core.MediaType.AUDIO -> "صدا"
                    com.fastget.app.core.MediaType.TORRENT -> "تورنت"
                    com.fastget.app.core.MediaType.VIDEO -> "ویدیو"
                    com.fastget.app.core.MediaType.ALL -> ""
                }
                val meta = listOf(kind, item.uploader, dur).filter { it.isNotBlank() }.joinToString("  ")
                Text(
                    meta,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant
                )
            }
            if (item.mediaType != com.fastget.app.core.MediaType.TORRENT && !selected) {
                IconButton(onClick = onMp3) { Icon(Icons.Rounded.MusicNote, "دانلود MP3", tint = cs.primary) }
                IconButton(onClick = onVideo) { Icon(Icons.Rounded.Movie, "دانلود ویدیو", tint = cs.secondary) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun QualitySheet(vm: MainViewModel, item: SearchItem) {
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var priv by remember { mutableStateOf(false) }
    val canPrivate = remember { Security.available(ctx) }
    val heights = vm.vSheetMeta?.heights.orEmpty()

    val options = buildList {
        add("موسیقی MP3 با بهترین کیفیت" to "a:mp3")
        add("موسیقی M4A با حجم کمتر" to "a:m4a")
        listOf(1080, 720, 480, 360).forEach { h ->
            if (heights.isEmpty() || heights.any { it >= h }) add("ویدیو ${fa(h)}p" to "v:$h")
        }
        add("ویدیو با بهترین کیفیت موجود" to "v:best")
    }

    fun close() { vm.vSheetItem = null; vm.vSheetMeta = null }

    ModalBottomSheet(onDismissRequest = { close() }, sheetState = sheet, containerColor = cs.surface) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 20.dp).navigationBarsPadding()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AsyncImage(
                    model = item.thumbnail, contentDescription = null, contentScale = ContentScale.Crop,
                    modifier = Modifier.size(width = 96.dp, height = 54.dp)
                        .clip(RoundedCornerShape(10.dp)).background(cs.surfaceVariant)
                )
                Spacer(Modifier.width(12.dp))
                Text(
                    item.title, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold
                )
            }
            Spacer(Modifier.height(12.dp))
            options.forEach { (label, spec) ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                        .background(cs.surfaceVariant.copy(alpha = 0.6f))
                        .clickable {
                            vm.manager.enqueueVideo(item.url, item.title, item.thumbnail, spec, priv && canPrivate)
                            Toast.makeText(ctx, "به صف دانلود اضافه شد", Toast.LENGTH_SHORT).show()
                            close()
                        }
                        .padding(horizontal = 14.dp, vertical = 13.dp)
                ) { Text(label, style = MaterialTheme.typography.bodyMedium) }
                Spacer(Modifier.height(8.dp))
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("ذخیره در پوشهٔ خصوصی", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        if (canPrivate) "فقط با اثرانگشت یا قفل صفحه دیده می‌شود و در گالری نمی‌آید."
                        else "برای استفاده، اول قفل صفحهٔ گوشی را فعال کنید.",
                        style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant
                    )
                }
                Switch(
                    checked = priv && canPrivate, onCheckedChange = { priv = it }, enabled = canPrivate,
                    colors = SwitchDefaults.colors(checkedTrackColor = cs.primary, checkedThumbColor = cs.onPrimary)
                )
            }
        }
    }
}

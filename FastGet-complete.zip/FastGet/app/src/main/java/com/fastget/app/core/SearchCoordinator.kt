package com.fastget.app.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext

/**
 * Decides which engines to run based on MediaType + Settings site lists,
 * runs them in parallel, merges and de-duplicates results.
 */
object SearchCoordinator {

    /**
     * Main entry used by the UI.
     * @param query free text or a direct http(s) link
     * @param type VIDEO / AUDIO / TORRENT / ALL
     * @param prefs for site lists and google toggle
     * @param count soft limit per engine
     */
    suspend fun search(
        query: String,
        type: MediaType,
        prefs: Prefs,
        count: Int = 15
    ): List<SearchItem> = withContext(Dispatchers.IO) {
        val q = query.trim()
        if (q.isEmpty()) return@withContext emptyList()

        // Direct link → let yt-dlp inspect later in ViewModel; here only text search.
        if (q.startsWith("http://") || q.startsWith("https://") || q.startsWith("magnet:")) {
            return@withContext listOf(
                SearchItem(
                    id = "direct",
                    title = q.take(80),
                    url = q,
                    mediaType = when {
                        q.startsWith("magnet:") -> MediaType.TORRENT
                        else -> type.takeIf { it != MediaType.ALL } ?: MediaType.VIDEO
                    },
                    sourceSite = "link",
                    isDirect = true
                )
            )
        }

        coroutineScope {
            val jobs = mutableListOf<kotlinx.coroutines.Deferred<List<SearchItem>>>()

            val wantVideo = type == MediaType.VIDEO || type == MediaType.ALL
            val wantAudio = type == MediaType.AUDIO || type == MediaType.ALL
            val wantTorrent = type == MediaType.TORRENT || type == MediaType.ALL

            if (wantVideo) {
                // yt-dlp YouTube search (always useful)
                jobs += async {
                    runCatching {
                        VideoEngine.search(q, SearchSource.YOUTUBE, count)
                    }.getOrElse { emptyList() }
                }
                // Porn sites from settings — via yt-dlp site: search when possible
                val pornHosts = prefs.sitesFor(SiteCategory.PORN)
                if (pornHosts.isNotEmpty()) {
                    jobs += async {
                        searchViaYtDlpSites(q, pornHosts, MediaType.VIDEO, count / 2)
                    }
                }
                val videoHosts = prefs.sitesFor(SiteCategory.VIDEO)
                    .filter { it != "youtube.com" && it != "youtu.be" }
                if (videoHosts.isNotEmpty()) {
                    jobs += async {
                        searchViaYtDlpSites(q, videoHosts, MediaType.VIDEO, count / 2)
                    }
                }
            }

            if (wantAudio) {
                jobs += async {
                    runCatching {
                        VideoEngine.search(q, SearchSource.SOUNDCLOUD, count)
                    }.getOrElse { emptyList() }
                }
                val audioHosts = prefs.sitesFor(SiteCategory.AUDIO)
                    .filter { it != "soundcloud.com" }
                if (audioHosts.isNotEmpty()) {
                    jobs += async {
                        searchViaYtDlpSites(q, audioHosts, MediaType.AUDIO, count / 2)
                    }
                }
            }

            if (wantTorrent) {
                val torrentHosts = prefs.sitesFor(SiteCategory.TORRENT)
                if (torrentHosts.isNotEmpty()) {
                    jobs += async {
                        runCatching {
                            TorrentEngine.search(q, torrentHosts, count)
                        }.getOrElse { emptyList() }
                    }
                }
            }

            if (prefs.googleSearchEnabled) {
                jobs += async {
                    runCatching {
                        GoogleEngine.search(q, type, count)
                    }.getOrElse { emptyList() }
                }
            }

            val merged = jobs.map { it.await() }.flatten()
            dedupe(merged).take(count * 2)
        }
    }

    /**
     * Uses yt-dlp `site:query` style where the extractor supports it,
     * otherwise falls back to a simple "https://host/search?q=" page probe via Google-like filter.
     * Age-gate sites get a cookie hint in a later refinement; for now we still try yt-dlp.
     */
    private suspend fun searchViaYtDlpSites(
        query: String,
        hosts: List<String>,
        media: MediaType,
        count: Int
    ): List<SearchItem> {
        // yt-dlp supports: "ytsearch", "scsearch", and for many sites just the search URL.
        // For pornhub: "https://www.pornhub.com/video/search?search=QUERY" often works with age cookie.
        val out = mutableListOf<SearchItem>()
        for (host in hosts.take(3)) {
            val searchUrl = buildSiteSearchUrl(host, query) ?: continue
            try {
                // Re-use inspect path indirectly: ask yt-dlp for flat playlist of the search page
                val items = VideoEngine.searchByUrl(searchUrl, count.coerceAtLeast(5))
                out += items.map {
                    it.copy(
                        mediaType = media,
                        sourceSite = host
                    )
                }
            } catch (_: Throwable) {
                // ignore single host failure
            }
            if (out.size >= count) break
        }
        return out.take(count)
    }

    private fun buildSiteSearchUrl(host: String, query: String): String? {
        val q = java.net.URLEncoder.encode(query, "UTF-8")
        return when {
            host.contains("pornhub") -> "https://www.pornhub.com/video/search?search=$q"
            host.contains("xvideos") -> "https://www.xvideos.com/?k=$q"
            host.contains("aparat") -> "https://www.aparat.com/search/$q"
            host.contains("vimeo") -> "https://vimeo.com/search?q=$q"
            host.contains("soundcloud") -> null // already covered by scsearch
            host.contains("youtube") -> null
            else -> "https://$host/search?q=$q"
        }
    }

    private fun dedupe(items: List<SearchItem>): List<SearchItem> {
        val seen = linkedSetOf<String>()
        return items.filter { item ->
            val key = item.url.substringBefore('?').lowercase()
            if (key in seen) false else {
                seen.add(key)
                true
            }
        }
    }
}

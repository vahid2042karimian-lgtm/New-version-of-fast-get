package com.fastget.app.core

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import java.io.File
import java.net.URLDecoder
import java.util.Locale

object Category {
    const val VIDEO = "video"
    const val AUDIO = "audio"
    const val DOCUMENT = "document"
    const val ARCHIVE = "archive"
    const val APP = "app"
    const val IMAGE = "image"
    const val OTHER = "other"

    val all = listOf(VIDEO, AUDIO, DOCUMENT, ARCHIVE, APP, IMAGE, OTHER)

    fun label(c: String) = when (c) {
        VIDEO -> I18n.t("ویدیو", "Video")
        AUDIO -> I18n.t("موسیقی", "Audio")
        DOCUMENT -> I18n.t("سند", "Documents")
        ARCHIVE -> I18n.t("فشرده", "Archives")
        APP -> I18n.t("برنامه", "Apps")
        IMAGE -> I18n.t("تصویر", "Images")
        else -> I18n.t("سایر", "Other")
    }

    private val map = mapOf(
        VIDEO to setOf("mp4", "mkv", "avi", "mov", "wmv", "flv", "webm", "m4v", "3gp", "ts"),
        AUDIO to setOf("mp3", "m4a", "aac", "wav", "flac", "ogg", "opus", "wma"),
        DOCUMENT to setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "epub", "csv"),
        ARCHIVE to setOf("zip", "rar", "7z", "tar", "gz", "bz2", "xz", "iso"),
        APP to setOf("apk", "xapk", "apks", "exe", "msi", "dmg", "deb"),
        IMAGE to setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "svg", "heic")
    )

    fun of(fileName: String): String {
        val ext = fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)
        return map.entries.firstOrNull { ext in it.value }?.key ?: OTHER
    }
}

/** Converts Latin digits (and the decimal point) to Persian ones for display. */
fun fa(s: String): String = buildString {
    for (c in s) append(
        when (c) {
            in '0'..'9' -> '۰' + (c - '0')
            '.' -> '٫'
            else -> c
        }
    )
}

fun fa(n: Number): String = fa(n.toString())

fun formatBytes(b: Long): String {
    if (b < 0) return "نامشخص"
    val units = arrayOf("بایت", "کیلوبایت", "مگابایت", "گیگابایت", "ترابایت")
    var v = b.toDouble()
    var i = 0
    while (v >= 1024 && i < units.lastIndex) { v /= 1024; i++ }
    return if (i == 0) "$b ${units[0]}" else String.format(Locale.US, "%.1f %s", v, units[i])
}

fun formatSpeed(bps: Long): String = formatBytes(bps) + "/ث"

fun formatEta(sec: Long): String {
    if (sec < 0) return "—"
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
    else String.format(Locale.US, "%d:%02d", m, s)
}

/** Short date+time for download cards (e.g. ۱۴۰۴/۰۸/۱۷ ۱۴:۳۰). */
fun formatDateTime(millis: Long): String {
    if (millis <= 0) return ""
    val cal = java.util.Calendar.getInstance().apply { timeInMillis = millis }
    val y = cal.get(java.util.Calendar.YEAR)
    val mo = cal.get(java.util.Calendar.MONTH) + 1
    val d = cal.get(java.util.Calendar.DAY_OF_MONTH)
    val h = cal.get(java.util.Calendar.HOUR_OF_DAY)
    val mi = cal.get(java.util.Calendar.MINUTE)
    return fa(String.format(Locale.US, "%04d/%02d/%02d %02d:%02d", y, mo, d, h, mi))
}

private val illegal = Regex("""[\\/:*?"<>|\u0000-\u001f]""")

fun sanitizeFileName(name: String): String {
    val n = name.replace(illegal, "_").trim().trim('.')
    return if (n.isEmpty()) "download" else n.take(120)
}

fun fileNameFromUrl(url: String): String {
    if (url.startsWith("magnet:", ignoreCase = true)) {
        val dn = Regex("""[?&]dn=([^&]+)""").find(url)?.groupValues?.getOrNull(1)
        if (!dn.isNullOrBlank()) {
            val decoded = runCatching { URLDecoder.decode(dn, "UTF-8") }.getOrDefault(dn)
            return sanitizeFileName(decoded)
        }
        val hash = Regex("""btih:([a-zA-Z0-9]+)""").find(url)?.groupValues?.getOrNull(1)?.take(12)
        return sanitizeFileName("torrent-${hash ?: url.hashCode()}")
    }
    val last = runCatching { Uri.parse(url).lastPathSegment }.getOrNull().orEmpty()
    val decoded = runCatching { URLDecoder.decode(last, "UTF-8") }.getOrDefault(last)
    return sanitizeFileName(decoded.ifBlank { "download" })
}

fun mimeOf(fileName: String): String {
    val ext = fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)
    return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
}

fun uniqueFile(dir: File, name: String): File {
    var f = File(dir, name)
    if (!f.exists() && !File(dir, "$name.part").exists()) return f
    val base = name.substringBeforeLast('.', name)
    val ext = name.substringAfterLast('.', "").let { if (it.isEmpty()) "" else ".$it" }
    var i = 1
    while (true) {
        f = File(dir, "$base ($i)$ext")
        if (!f.exists() && !File(dir, "${f.name}.part").exists()) return f
        i++
    }
}

private val urlRegex = Regex("""https?://[^\s]+""")
fun extractUrls(text: String): List<String> = urlRegex.findAll(text).map { it.value }.toList()

private val rangeRegex = Regex("""\[(\d+)-(\d+)]""")

/**
 * Batch expansion: one link per line; `file[01-20].zip` expands to 20 links.
 * Only http/https are accepted. Output is capped at 500 links per pattern.
 */
fun expandBatch(text: String): List<String> {
    val out = LinkedHashSet<String>()
    for (raw in text.lines().map { it.trim() }) {
        if (!(raw.startsWith("http://") || raw.startsWith("https://"))) continue
        val m = rangeRegex.find(raw)
        if (m == null) { out.add(raw); continue }
        val a = m.groupValues[1]
        val from = a.toIntOrNull()
        val to = m.groupValues[2].toIntOrNull()
        if (from == null || to == null || to < from || to - from >= 500) { out.add(raw); continue }
        for (i in from..to) {
            out.add(raw.replaceRange(m.range, i.toString().padStart(a.length, '0')))
        }
    }
    return out.toList()
}

/** Copies a finished file into Download/FastGet (Android 10+) and deletes the private copy. */
fun publishToDownloads(context: Context, src: File, displayName: String): String? {
    if (Build.VERSION.SDK_INT < 29) return null
    return runCatching {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, displayName)
            put(MediaStore.Downloads.MIME_TYPE, mimeOf(displayName))
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/FastGet")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return null
        resolver.openOutputStream(uri)?.use { out -> src.inputStream().use { it.copyTo(out) } }
            ?: return null
        values.clear()
        values.put(MediaStore.Downloads.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        src.delete()
        uri.toString()
    }.getOrNull()
}


/** Cross-volume safe move (renameTo fails between internal and external storage). */
fun moveFile(src: File, dst: File) {
    dst.parentFile?.mkdirs()
    src.copyTo(dst, overwrite = true)
    src.delete()
}

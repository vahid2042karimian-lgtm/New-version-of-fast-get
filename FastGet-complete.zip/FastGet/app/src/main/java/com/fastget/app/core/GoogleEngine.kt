package com.fastget.app.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

/**
 * Lightweight Google/DuckDuckGo HTML search that extracts promising download / page links.
 * No API key. Results are best-effort and filtered by MediaType.
 */
object GoogleEngine {

    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private val hrefPattern = Pattern.compile(
        """href=["'](https?://[^"']+)["']""",
        Pattern.CASE_INSENSITIVE
    )

    suspend fun search(query: String, type: MediaType, count: Int = 12): List<SearchItem> =
        withContext(Dispatchers.IO) {
            val q = query.trim().take(100)
            if (q.isEmpty()) return@withContext emptyList()

            val extra = when (type) {
                MediaType.VIDEO -> " (video OR mp4 OR watch OR trailer)"
                MediaType.AUDIO -> " (mp3 OR m4a OR flac OR audio OR listen)"
                MediaType.TORRENT -> " (torrent OR magnet OR 1337x OR nyaa)"
                MediaType.ALL -> ""
            }
            // DuckDuckGo HTML is more scrape-friendly than Google for a simple client.
            val encoded = URLEncoder.encode(q + extra, "UTF-8")
            val url = "https://html.duckduckgo.com/html/?q=$encoded"

            val body = try {
                val req = Request.Builder()
                    .url(url)
                    .header("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36")
                    .header("Accept-Language", "en-US,en;q=0.9")
                    .get()
                    .build()
                client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return@withContext emptyList()
                    resp.body?.string().orEmpty()
                }
            } catch (_: Throwable) {
                return@withContext emptyList()
            }

            val links = linkedSetOf<String>()
            val m = hrefPattern.matcher(body)
            while (m.find()) {
                var href = m.group(1) ?: continue
                // DuckDuckGo wraps redirects: /l/?uddg=<encoded>
                if (href.contains("uddg=")) {
                    val idx = href.indexOf("uddg=")
                    href = java.net.URLDecoder.decode(href.substring(idx + 5).substringBefore("&"), "UTF-8")
                }
                if (!href.startsWith("http")) continue
                if (href.contains("duckduckgo.com")) continue
                if (href.contains("google.com/search")) continue
                links.add(href)
                if (links.size >= count * 3) break
            }

            val filtered = links.filter { u ->
                when (type) {
                    MediaType.TORRENT ->
                        u.contains("magnet:") || u.contains("torrent", true) ||
                            u.contains("1337x") || u.contains("nyaa") || u.contains("rarbg") ||
                            u.contains("torrentgalaxy") || u.contains("yts.")
                    MediaType.AUDIO ->
                        u.contains("soundcloud") || u.contains("mp3", true) ||
                            u.contains("bandcamp") || u.contains("spotify") ||
                            u.contains("listen", true) || u.endsWith(".mp3") || u.endsWith(".m4a")
                    MediaType.VIDEO ->
                        u.contains("youtube") || u.contains("youtu.be") || u.contains("aparat") ||
                            u.contains("vimeo") || u.contains("watch") || u.contains("video", true) ||
                            u.contains("pornhub") || u.contains("xvideos") || u.endsWith(".mp4")
                    MediaType.ALL -> true
                }
            }.take(count)

            filtered.mapIndexed { i, u ->
                val host = try {
                    java.net.URI(u).host?.removePrefix("www.") ?: "web"
                } catch (_: Throwable) { "web" }
                val titleGuess = u.substringAfterLast('/').substringBefore('?').replace('-', ' ').replace('_', ' ')
                    .ifBlank { host }
                SearchItem(
                    id = "g$i",
                    title = titleGuess.take(80).ifBlank { u.take(60) },
                    url = u,
                    uploader = host,
                    mediaType = when {
                        type != MediaType.ALL -> type
                        u.contains("magnet:") || u.contains("torrent", true) -> MediaType.TORRENT
                        u.endsWith(".mp3") || u.contains("soundcloud") -> MediaType.AUDIO
                        else -> MediaType.VIDEO
                    },
                    sourceSite = "google",
                    isDirect = u.endsWith(".mp4") || u.endsWith(".mp3") || u.endsWith(".m4a") ||
                        u.endsWith(".mkv") || u.startsWith("magnet:")
                )
            }
        }
}

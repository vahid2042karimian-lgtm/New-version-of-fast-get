package com.fastget.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import com.fastget.app.core.expandBatch
import com.fastget.app.core.fa

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddSheet(vm: MainViewModel) {
    val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var text by remember { mutableStateOf(vm.prefill) }
    val clipboard = LocalClipboardManager.current
    val found = remember(text) { expandBatch(text) }
    val allowHttp = vm.prefs.allowHttp
    val urls = found.filter { it.startsWith("https://") || allowHttp }
    val blocked = found.size - urls.size
    val cs = MaterialTheme.colorScheme

    ModalBottomSheet(
        onDismissRequest = { vm.showAdd = false },
        sheetState = sheet,
        containerColor = cs.surface
    ) {
        Column(
            Modifier.padding(horizontal = 20.dp).padding(bottom = 20.dp)
                .navigationBarsPadding().imePadding()
        ) {
            Text("افزودن دانلود", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))

            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
                maxLines = 6,
                shape = RoundedCornerShape(16.dp),
                textStyle = TextStyle(textDirection = TextDirection.Ltr),
                placeholder = { Text("https://example.com/file.zip") }
            )

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = {
                    clipboard.getText()?.text?.let { text = if (text.isBlank()) it else text + "\n" + it }
                }) {
                    Icon(Icons.Rounded.ContentPaste, null)
                    Text("  چسباندن")
                }
                Spacer(Modifier.weight(1f))
                Text(
                    if (urls.isEmpty()) "لینک معتبری پیدا نشد" else "${fa(urls.size)} لینک شناسایی شد",
                    style = MaterialTheme.typography.labelMedium,
                    color = if (urls.isEmpty()) cs.onSurfaceVariant else cs.primary
                )
            }

            Text(
                "هر لینک در یک خط. برای دانلود گروهی می‌توانید الگو بنویسید، مثلاً file[01-20].zip",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )
            if (blocked > 0) {
                Spacer(Modifier.height(6.dp))
                Text(
                    "${fa(blocked)} لینک http رد شد، چون بدون رمزنگاری است. در تنظیمات می‌توانید اجازه بدهید.",
                    style = MaterialTheme.typography.bodySmall,
                    color = com.fastget.app.ui.theme.ColorBad
                )
            }
            Spacer(Modifier.height(16.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                    onClick = { vm.manager.enqueue(urls, true); vm.showAdd = false },
                    enabled = urls.isNotEmpty(),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = cs.primary, contentColor = cs.onPrimary
                    )
                ) { Text("شروع دانلود") }
                OutlinedButton(
                    onClick = { vm.manager.enqueue(urls, false); vm.showAdd = false },
                    enabled = urls.isNotEmpty(),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp)
                ) { Text("فقط افزودن") }
            }
        }
    }
}

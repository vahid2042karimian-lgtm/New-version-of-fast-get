package com.fastget.app.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

/**
 * HTML search engines (DuckDuckGo + Bing) — no API key.
 * Extracts page titles + URLs, filtered by [MediaType].
 */
object GoogleEngine {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(14, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private val hrefPattern = Pattern.compile(
        """href=["']([^"']+)["']""",
        Pattern.CASE_INSENSITIVE
    )
    private val ddgResult = Pattern.compile(
        """class="[^"]*result__a[^"]*"[^>]*href="([^"]+)"[^>]*>([^<]+)<""",
        Pattern.CASE_INSENSITIVE
    )
    private val bingResult = Pattern.compile(
        """<h2[^>]*>\s*<a[^>]*href="(https?://[^"]+)"[^>]*>(.*?)</a>""",
        Pattern.CASE_INSENSITIVE or Pattern.DOTALL
    )

    suspend fun search(query: String, type: MediaType, count: Int = 15): List<SearchItem> =
        withContext(Dispatchers.IO) {
            val q = query.trim().take(100)
            if (q.isEmpty()) return@withContext emptyList()

            val suffix = when (type) {
                MediaType.VIDEO, MediaType.EXTRA -> " video"
                MediaType.AUDIO -> " audio mp3"
                MediaType.FILE -> " download file"
                MediaType.TORRENT -> " torrent magnet"
                MediaType.ALL -> ""
            }
            val full = (q + suffix).trim()

            coroutineScope {
                val ddg = async { runCatching { searchDdg(full, type, count) }.getOrElse { emptyList() } }
                val bing = async { runCatching { searchBing(full, type, count) }.getOrElse { emptyList() } }
                val merged = (ddg.await() + bing.await())
                dedupe(merged).take(count)
            }
        }

    private fun searchDdg(q: String, type: MediaType, count: Int): List<SearchItem> {
        val encoded = URLEncoder.encode(q, "UTF-8")
        val url = "https://html.duckduckgo.com/html/?q=$encoded"
        val body = fetch(url) ?: return emptyList()
        val out = mutableListOf<SearchItem>()

        // Prefer structured result anchors
        val rm = ddgResult.matcher(body)
        while (rm.find() && out.size < count * 2) {
            var href = decodeDdg(rm.group(1) ?: continue)
            val title = stripTags(rm.group(2) ?: "").trim()
            if (!href.startsWith("http")) continue
            if (skipHost(href)) continue
            if (!matchesType(href, type)) continue
            out += item(out.size, title.ifBlank { titleFromUrl(href) }, href, type)
        }

        if (out.size < count / 2) {
            val m = hrefPattern.matcher(body)
            while (m.find() && out.size < count * 2) {
                var href = m.group(1) ?: continue
                href = decodeDdg(href)
                if (!href.startsWith("http")) continue
                if (skipHost(href)) continue
                if (!matchesType(href, type)) continue
                out += item(out.size, titleFromUrl(href), href, type)
            }
        }
        return out
    }

    private fun searchBing(q: String, type: MediaType, count: Int): List<SearchItem> {
        val encoded = URLEncoder.encode(q, "UTF-8")
        val url = "https://www.bing.com/search?q=$encoded&setlang=en"
        val body = fetch(url) ?: return emptyList()
        val out = mutableListOf<SearchItem>()
        val m = bingResult.matcher(body)
        while (m.find() && out.size < count * 2) {
            val href = m.group(1) ?: continue
            val title = stripTags(m.group(2) ?: "").trim()
            if (skipHost(href)) continue
            if (!matchesType(href, type)) continue
            out += item(out.size, title.ifBlank { titleFromUrl(href) }, href, type)
        }
        return out
    }

    private fun fetch(url: String): String? {
        return try {
            val req = Request.Builder()
                .url(url)
                .header(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36"
                )
                .header("Accept-Language", "en-US,en;q=0.9")
                .header("Accept", "text/html,application/xhtml+xml")
                .get()
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return null
                resp.body?.string()
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun decodeDdg(raw: String): String {
        var href = raw
        if (href.contains("uddg=")) {
            val idx = href.indexOf("uddg=")
            href = try {
                java.net.URLDecoder.decode(href.substring(idx + 5).substringBefore("&"), "UTF-8")
            } catch (_: Throwable) {
                href
            }
        }
        if (href.startsWith("//")) href = "https:$href"
        return href
    }

    private fun skipHost(u: String): Boolean {
        val low = u.lowercase()
        return low.contains("duckduckgo.com") ||
            low.contains("bing.com") ||
            low.contains("microsoft.com") ||
            low.contains("google.com/search") ||
            low.contains("youtube.com/results")
    }

    private fun matchesType(u: String, type: MediaType): Boolean {
        val low = u.lowercase()
        return when (type) {
            MediaType.TORRENT ->
                low.contains("magnet:") || low.contains("torrent") ||
                    low.contains("1337x") || low.contains("nyaa") ||
                    low.contains("rarbg") || low.contains("yts.") ||
                    low.contains("torrentgalaxy")
            MediaType.AUDIO ->
                low.contains("soundcloud") || low.contains("bandcamp") ||
                    low.contains("mp3") || low.endsWith(".m4a") ||
                    low.contains("listen") || low.contains("music")
            MediaType.FILE ->
                low.endsWith(".pdf") || low.endsWith(".zip") || low.endsWith(".rar") ||
                    low.endsWith(".7z") || low.contains("download") || low.contains("/file")
            MediaType.VIDEO ->
                // فیلتر نرم — نتایج بیشتر؛ باز شدن در مرورگر برای یافتن لینک واقعی
                !low.contains("facebook.com") && !low.contains("instagram.com")
            MediaType.EXTRA ->
                low.contains("pornhub") || low.contains("xvideos") || low.contains("xhamster") ||
                    low.contains("xnxx") || low.contains("porn") || low.contains("xxx") ||
                    low.contains("/video") || low.contains("watch")
            MediaType.ALL -> true
        }
    }

    private fun item(i: Int, title: String, url: String, type: MediaType): SearchItem {
        val host = try {
            java.net.URI(url).host?.removePrefix("www.") ?: "web"
        } catch (_: Throwable) {
            "web"
        }
        val media = when {
            type != MediaType.ALL -> type
            url.contains("magnet:") || url.contains("torrent", true) -> MediaType.TORRENT
            url.endsWith(".mp3") || url.contains("soundcloud") -> MediaType.AUDIO
            else -> MediaType.VIDEO
        }
        return SearchItem(
            id = "g$i-${url.hashCode()}",
            title = title.take(90),
            url = url,
            uploader = host,
            mediaType = media,
            // برچسب web/google تا UI بداند در مرورگر باز کند نه دانلود مستقیم
            sourceSite = "google",
            isDirect = url.endsWith(".mp4") || url.endsWith(".mp3") || url.startsWith("magnet:")
        )
    }

    private fun titleFromUrl(u: String): String =
        u.substringAfterLast('/').substringBefore('?')
            .replace('-', ' ').replace('_', ' ').ifBlank { u.take(50) }

    private fun stripTags(s: String): String =
        s.replace(Regex("<[^>]+>"), " ").replace(Regex("\\s+"), " ").trim()

    private fun dedupe(list: List<SearchItem>): List<SearchItem> {
        val seen = HashSet<String>()
        return list.filter { seen.add(it.url) }
    }
}

package com.fastget.app.ui

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Surface
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.fastget.app.core.I18n

/**
 * Lightweight Chrome-like in-app browser.
 * - Address bar, back / forward, reload, home
 * - Simple tabs
 * - Extract links → only add to download queue (no auto-start)
 * - Current page → only add (no auto-start)
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun BrowserScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val start = vm.browserStartUrl.ifBlank {
        vm.prefs.lastBrowserUrl.ifBlank { "https://www.google.com" }
    }

    val savedTabs = remember {
        vm.prefs.browserTabs.lines().map { it.trim() }.filter { it.startsWith("http") }.distinct()
    }
    var tabs by remember {
        mutableStateOf(if (savedTabs.isNotEmpty()) savedTabs else listOf(start))
    }
    var tabIndex by remember {
        mutableIntStateOf(
            tabs.indexOf(start).takeIf { it >= 0 }
                ?: tabs.indexOfFirst { it == vm.prefs.lastBrowserUrl }.takeIf { it >= 0 }
                ?: 0
        )
    }
    var urlBar by remember(start) { mutableStateOf(start) }
    var currentUrl by remember(start) { mutableStateOf(start) }
    var progress by remember { mutableFloatStateOf(0f) }
    var webView by remember { mutableStateOf<WebView?>(null) }
    var canGoBack by remember { mutableStateOf(false) }
    var canGoForward by remember { mutableStateOf(false) }
    var extracted by remember { mutableStateOf<List<String>>(emptyList()) }
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
    var showLinks by remember { mutableStateOf(false) }
    var desktopMode by remember { mutableStateOf(false) }
    var clipOffer by remember { mutableStateOf("") }
    var detectedPage by remember { mutableStateOf("") }
    var videoBanner by remember { mutableStateOf(false) }
    var showVideoMenu by remember { mutableStateOf(false) }

    fun persistTabs(list: List<String>) {
        vm.prefs.browserTabs = list.take(8).joinToString("\n")
    }

    fun navigate(u: String) {
        val norm = normalizeUrl(u)
        urlBar = norm
        currentUrl = norm
        tabs = tabs.toMutableList().also { if (tabIndex in it.indices) it[tabIndex] = norm }
        persistTabs(tabs)
        webView?.loadUrl(norm)
    }

    // Offer clipboard http(s) links to queue without auto-start
    LaunchedEffect(Unit) {
        runCatching {
            val cm = ctx.getSystemService(ClipboardManager::class.java) ?: return@LaunchedEffect
            val text = cm.primaryClip?.getItemAt(0)?.coerceToText(ctx)?.toString()?.trim().orEmpty()
            if ((text.startsWith("http://") || text.startsWith("https://") || text.startsWith("magnet:"))
                && text != currentUrl
            ) {
                clipOffer = text
            }
        }
    }

    val cs = MaterialTheme.colorScheme
    var moreMenu by remember { mutableStateOf(false) }

    fun extractLinks() {
        val wv = webView ?: return
        wv.evaluateJavascript(EXTRACT_LINKS_JS) { raw ->
            val links = parseJsStringArray(raw)
            if (links.isEmpty()) {
                Toast.makeText(ctx, I18n.noLinksFound, Toast.LENGTH_SHORT).show()
            } else {
                extracted = links
                selected = links.toSet()
                showLinks = true
            }
        }
    }

    fun queueCurrent() {
        val link = currentUrl.ifBlank { urlBar }
        if (!link.startsWith("http")) return
        if (isMediaPage(link)) {
            detectedPage = link
            showVideoMenu = true
        } else {
            vm.manager.enqueue(listOf(link), autoStart = false)
            Toast.makeText(ctx, "به صف اضافه شد (بدون شروع)", Toast.LENGTH_SHORT).show()
        }
    }

    fun copyAndQueue() {
        val link = currentUrl.ifBlank { urlBar }
        ctx.getSystemService(ClipboardManager::class.java)
            .setPrimaryClip(ClipData.newPlainText("url", link))
        if (link.startsWith("http")) {
            vm.manager.enqueue(listOf(link), autoStart = false)
            Toast.makeText(ctx, I18n.t("کپی و اضافه به صف", "Copied & queued"), Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(ctx, I18n.linkCopied, Toast.LENGTH_SHORT).show()
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(cs.background)
            .statusBarsPadding()
    ) {
        // ——— نوار بالای مدرن ———
        Surface(
            color = cs.surface,
            tonalElevation = 2.dp,
            shadowElevation = 1.dp
        ) {
            Column(Modifier.fillMaxWidth()) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { vm.screen = Screen.HOME }) {
                        Icon(Icons.Rounded.Close, contentDescription = "بستن", tint = cs.onSurface)
                    }
                    // کادر آدرس بزرگ
                    OutlinedTextField(
                        value = urlBar,
                        onValueChange = { urlBar = it },
                        modifier = Modifier.weight(1f).height(50.dp),
                        singleLine = true,
                        shape = RoundedCornerShape(22.dp),
                        textStyle = MaterialTheme.typography.bodySmall,
                        leadingIcon = {
                            val https = currentUrl.startsWith("https://") || urlBar.startsWith("https://")
                            Icon(
                                Icons.Rounded.Lock,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = if (https) cs.primary else cs.onSurfaceVariant.copy(alpha = 0.5f)
                            )
                        },
                        colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = cs.surfaceVariant.copy(alpha = 0.35f),
                            unfocusedContainerColor = cs.surfaceVariant.copy(alpha = 0.25f),
                            focusedBorderColor = cs.primary.copy(alpha = 0.4f),
                            unfocusedBorderColor = cs.outline.copy(alpha = 0.2f)
                        ),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                        keyboardActions = KeyboardActions(onGo = { navigate(urlBar) })
                    )
                    // تعداد تب
                    Box(
                        Modifier
                            .padding(horizontal = 2.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(cs.primaryContainer)
                            .clickable {
                                tabs = tabs + "https://www.google.com"
                                tabIndex = tabs.lastIndex
                                persistTabs(tabs)
                                navigate("https://www.google.com")
                            }
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                    ) {
                        Text(
                            "${tabs.size}",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = cs.onPrimaryContainer
                        )
                    }
                    Box {
                        IconButton(onClick = { moreMenu = true }) {
                            Icon(Icons.Rounded.MoreVert, contentDescription = "منو")
                        }
                        DropdownMenu(expanded = moreMenu, onDismissRequest = { moreMenu = false }) {
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        if (desktopMode) I18n.t("حالت موبایل", "Mobile mode")
                                        else I18n.t("حالت دسکتاپ", "Desktop mode")
                                    )
                                },
                                onClick = {
                                    moreMenu = false
                                    desktopMode = !desktopMode
                                    webView?.settings?.userAgentString = if (desktopMode) {
                                        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
                                    } else null
                                    webView?.reload()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(I18n.t("کپی و اضافه به صف", "Copy & queue")) },
                                onClick = { moreMenu = false; copyAndQueue() }
                            )
                            DropdownMenuItem(
                                text = { Text(I18n.t("افزودن صفحه به دانلود", "Add page to downloads")) },
                                onClick = { moreMenu = false; queueCurrent() }
                            )
                            DropdownMenuItem(
                                text = { Text(I18n.extractLinks) },
                                onClick = { moreMenu = false; extractLinks() }
                            )
                            DropdownMenuItem(
                                text = { Text(I18n.t("بارگذاری مجدد", "Reload")) },
                                onClick = { moreMenu = false; webView?.reload() }
                            )
                        }
                    }
                }

                // ——— نوار تب‌ها ———
                Row(
                    Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(start = 8.dp, end = 4.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    tabs.forEachIndexed { i, tabUrl ->
                        val label = try {
                            java.net.URI(tabUrl).host?.removePrefix("www.") ?: tabUrl
                        } catch (_: Throwable) {
                            tabUrl.take(18)
                        }
                        val selectedTab = i == tabIndex
                        Row(
                            Modifier
                                .padding(end = 6.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (selectedTab) cs.primary.copy(alpha = 0.16f)
                                    else cs.surfaceVariant.copy(alpha = 0.55f)
                                )
                                .clickable {
                                    tabIndex = i
                                    navigate(tabs[i])
                                }
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                label.take(16),
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (selectedTab) FontWeight.SemiBold else FontWeight.Medium,
                                color = if (selectedTab) cs.primary else cs.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (tabs.size > 1) {
                                Spacer(Modifier.width(6.dp))
                                Icon(
                                    Icons.Rounded.Close,
                                    contentDescription = "بستن تب",
                                    tint = cs.onSurfaceVariant,
                                    modifier = Modifier
                                        .size(14.dp)
                                        .clickable {
                                            val next = tabs.toMutableList().also { it.removeAt(i) }
                                            tabs = next
                                            tabIndex = tabIndex.coerceAtMost(next.lastIndex.coerceAtLeast(0))
                                            persistTabs(next)
                                            if (next.isNotEmpty()) navigate(next[tabIndex])
                                        }
                                )
                            }
                        }
                    }
                    IconButton(
                        onClick = {
                            tabs = tabs + "https://www.google.com"
                            tabIndex = tabs.lastIndex
                            persistTabs(tabs)
                            navigate("https://www.google.com")
                        },
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = "تب جدید", modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        if (progress in 0.01f..0.99f) {
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth(),
                color = cs.primary,
                trackColor = cs.surfaceVariant
            )
        }

        AndroidView(
            factory = { context ->
                WebView(context).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.databaseEnabled = true
                    settings.loadsImagesAutomatically = true
                    settings.useWideViewPort = true
                    settings.loadWithOverviewMode = true
                    settings.builtInZoomControls = true
                    settings.displayZoomControls = false
                    settings.mediaPlaybackRequiresUserGesture = false
                    settings.javaScriptCanOpenWindowsAutomatically = true
                    settings.setSupportMultipleWindows(false)
                    try {
                        settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                    } catch (_: Throwable) { }
                    try {
                        android.webkit.CookieManager.getInstance().setAcceptCookie(true)
                        android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                    } catch (_: Throwable) { }
                    settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = true
                    settings.setSupportMultipleWindows(false)
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(
                            view: WebView?,
                            request: WebResourceRequest?
                        ): Boolean {
                            val u = request?.url?.toString() ?: return false
                            currentUrl = u
                            urlBar = u
                            canGoBack = view?.canGoBack() == true
                            canGoForward = view?.canGoForward() == true
                            return false
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            if (url != null) {
                                currentUrl = url
                                urlBar = url
                                vm.prefs.lastBrowserUrl = url
                                if (isMediaPage(url)) {
                                    detectedPage = url
                                    videoBanner = true
                                } else {
                                    videoBanner = false
                                }
                                tabs = tabs.toMutableList().also {
                                    if (tabIndex in it.indices) it[tabIndex] = url
                                }
                            }
                            canGoBack = view?.canGoBack() == true
                            canGoForward = view?.canGoForward() == true
                        }
                    }
                    webChromeClient = object : WebChromeClient() {
                        override fun onProgressChanged(view: WebView?, newProgress: Int) {
                            progress = newProgress / 100f
                        }
                    }
                    setDownloadListener { url, _userAgent, contentDisposition, mimeType, _contentLength ->
                        if (url.isNullOrBlank()) return@setDownloadListener
                        // Browser download button path → queue only (no auto start)
                        post {
                            vm.manager.enqueue(listOf(url), autoStart = false)
                            android.widget.Toast.makeText(
                                context,
                                "لینک دانلود به صف اضافه شد",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                    loadUrl(currentUrl)
                    webView = this
                }
            },
            modifier = Modifier.weight(1f).fillMaxWidth(),
            update = { /* keep instance */ }
        )

        if (videoBanner && detectedPage.isNotBlank()) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = cs.primaryContainer)
            ) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "ویدیو شناسایی شد",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "برای انتخاب کیفیت ضربه بزنید",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Button(onClick = { showVideoMenu = true }, shape = RoundedCornerShape(12.dp)) {
                        Text(I18n.t("دانلود", "Download"))
                    }
                    TextButton(onClick = { videoBanner = false }) {
                        Text("×")
                    }
                }
            }
        }

        // ——— نوار پایین ———
        Surface(
            color = cs.surface,
            tonalElevation = 3.dp,
            shadowElevation = 4.dp
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { webView?.goBack() }, enabled = canGoBack) {
                    Icon(
                        Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = "قبلی",
                        tint = if (canGoBack) cs.onSurface else cs.onSurface.copy(alpha = 0.35f)
                    )
                }
                IconButton(onClick = { webView?.goForward() }, enabled = canGoForward) {
                    Icon(
                        Icons.AutoMirrored.Rounded.ArrowForward,
                        contentDescription = "بعدی",
                        tint = if (canGoForward) cs.onSurface else cs.onSurface.copy(alpha = 0.35f)
                    )
                }
                IconButton(onClick = { webView?.reload() }) {
                    Icon(Icons.Rounded.Refresh, contentDescription = "بارگذاری مجدد")
                }
                IconButton(onClick = { navigate("https://www.google.com") }) {
                    Icon(Icons.Rounded.Home, contentDescription = "خانه")
                }
                IconButton(onClick = { extractLinks() }) {
                    Icon(Icons.Rounded.Link, contentDescription = "استخراج لینک", tint = cs.primary)
                }
            }
        }
    }

    if (clipOffer.isNotBlank()) {
        AlertDialog(
            onDismissRequest = { clipOffer = "" },
            title = { Text(clipOffer.take(60), maxLines = 2, overflow = TextOverflow.Ellipsis) },
            confirmButton = {
                TextButton(onClick = {
                    vm.manager.enqueue(listOf(clipOffer), autoStart = false)
                    Toast.makeText(ctx, "به صف اضافه شد (بدون شروع)", Toast.LENGTH_SHORT).show()
                    clipOffer = ""
                }) { Text(I18n.addSelected) }
            },
            dismissButton = {
                TextButton(onClick = { clipOffer = "" }) { Text(I18n.cancel) }
            }
        )
    }

    if (showVideoMenu && detectedPage.isNotBlank()) {
        val pageTitle = try {
            java.net.URI(detectedPage).host?.removePrefix("www.") ?: detectedPage
        } catch (_: Throwable) {
            detectedPage.take(30)
        }
        val options = listOf(
            "ویدیو (بهترین کیفیت)" to "v:best",
            "ویدیو 720p" to "v:720",
            "ویدیو 480p" to "v:480",
            "صدا (MP3)" to "a:mp3"
        )
        AlertDialog(
            onDismissRequest = { showVideoMenu = false },
            title = { Text("انتخاب کیفیت") },
            text = {
                Column {
                    options.forEach { (label, spec) ->
                        TextButton(onClick = {
                            vm.manager.enqueueVideo(detectedPage, pageTitle, null, spec, false)
                            Toast.makeText(ctx, "به صف اضافه شد", Toast.LENGTH_SHORT).show()
                            showVideoMenu = false
                            videoBanner = false
                        }) { Text(label) }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showVideoMenu = false }) { Text(I18n.cancel) }
            }
        )
    }

    if (showLinks) {
        AlertDialog(
            onDismissRequest = { showLinks = false },
            title = { Text("${extracted.size} ${I18n.linksFound}") },
            text = {
                Column {
                    TextButton(onClick = {
                        selected = if (selected.size == extracted.size) emptySet() else extracted.toSet()
                    }) { Text(I18n.selectAll) }
                    Spacer(Modifier.height(4.dp))
                    LazyColumn(modifier = Modifier.height(280.dp)) {
                        items(extracted, key = { it }) { link ->
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selected = if (link in selected) selected - link else selected + link
                                    }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = link in selected,
                                    onCheckedChange = {
                                        selected = if (it) selected + link else selected - link
                                    }
                                )
                                Text(
                                    link,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val list = selected.toList()
                    if (list.isNotEmpty()) {
                        // Only add — do not start download
                        vm.manager.enqueue(list, autoStart = false)
                        Toast.makeText(
                            ctx,
                            "${list.size} لینک به صف اضافه شد (بدون شروع)",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    showLinks = false
                }) { Text(I18n.addSelected) }
            },
            dismissButton = {
                TextButton(onClick = { showLinks = false }) { Text(I18n.cancel) }
            }
        )
    }
}

private const val EXTRACT_LINKS_JS = """
(function() {
  var set = {};
  var out = [];
  var mediaFirst = [];
  function isMedia(u) {
    var l = (u || '').toLowerCase();
    return /\.(mp4|webm|mkv|m3u8|mp3|m4a|flac|pdf|zip|rar|7z)(\?|$)/.test(l) ||
      l.indexOf('magnet:') === 0 ||
      l.indexOf('/video') !== -1 ||
      l.indexOf('watch?v=') !== -1 ||
      l.indexOf('youtu.be/') !== -1;
  }
  function add(u, prefer) {
    if (!u) return;
    u = String(u).trim();
    if (u.indexOf('//') === 0) u = 'https:' + u;
    if (u.indexOf('magnet:') === 0) {
      if (set[u]) return;
      set[u] = 1;
      mediaFirst.push(u);
      return;
    }
    if (u.indexOf('http://') !== 0 && u.indexOf('https://') !== 0) return;
    if (set[u]) return;
    set[u] = 1;
    if (prefer || isMedia(u)) mediaFirst.push(u); else out.push(u);
  }
  var anchors = document.querySelectorAll('a[href]');
  for (var i = 0; i < anchors.length; i++) add(anchors[i].href, false);
  var media = document.querySelectorAll('video, audio, source');
  for (var j = 0; j < media.length; j++) {
    add(media[j].currentSrc || media[j].src, true);
    if (media[j].getAttribute) add(media[j].getAttribute('data-src'), true);
  }
  var metas = document.querySelectorAll('meta[property="og:video"], meta[property="og:video:url"]');
  for (var k = 0; k < metas.length; k++) add(metas[k].content, true);
  return JSON.stringify(mediaFirst.concat(out).slice(0, 250));
})();
"""

private fun parseJsStringArray(raw: String?): List<String> {
    if (raw.isNullOrBlank() || raw == "null") return emptyList()
    var s = raw.trim()
    if (s.startsWith("\"") && s.endsWith("\"")) {
        s = s.substring(1, s.length - 1)
            .replace("\\\"", "\"")
            .replace("\\\\", "\\")
    }
    return try {
        val arr = org.json.JSONArray(s)
        buildList {
            for (i in 0 until arr.length()) {
                val u = arr.optString(i)
                if (u.startsWith("http")) add(u)
            }
        }.distinct()
    } catch (_: Exception) {
        emptyList()
    }
}

private fun normalizeUrl(raw: String): String {
    val t = raw.trim()
    if (t.isEmpty()) return "https://www.google.com"
    if (t.startsWith("http://") || t.startsWith("https://")) return t
    if (t.contains(" ") || !t.contains(".")) {
        return "https://www.google.com/search?q=" + java.net.URLEncoder.encode(t, "UTF-8")
    }
    return "https://$t"
}

private fun isMediaPage(url: String): Boolean {
    val u = url.lowercase()
    return u.contains("youtube.com/watch") ||
        u.contains("youtu.be/") ||
        u.contains("youtube.com/shorts/") ||
        u.contains("vimeo.com/") ||
        u.contains("dailymotion.com/video") ||
        u.contains("soundcloud.com/") ||
        u.contains("twitter.com/") && u.contains("/status/") ||
        u.contains("x.com/") && u.contains("/status/") ||
        u.contains("instagram.com/reel") ||
        u.contains("tiktok.com/") && u.contains("/video/")
}

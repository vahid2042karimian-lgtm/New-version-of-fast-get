package com.fastget.app.ui

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.border
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.FolderZip
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.RadioButtonChecked
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.InsertDriveFile
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PauseCircle
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fastget.app.core.Category
import com.fastget.app.core.Live
import com.fastget.app.core.Prefs
import com.fastget.app.core.Segments
import com.fastget.app.core.fa
import com.fastget.app.core.formatBytes
import com.fastget.app.core.formatDateTime
import com.fastget.app.core.formatEta
import com.fastget.app.core.formatSpeed
import com.fastget.app.core.DownloadManager
import com.fastget.app.core.mimeOf
import com.fastget.app.data.DownloadEntity
import com.fastget.app.data.Kind
import com.fastget.app.data.Status
import coil.compose.AsyncImage
import androidx.compose.ui.layout.ContentScale
import com.fastget.app.ui.theme.ColorBad
import com.fastget.app.ui.theme.ColorOk
import com.fastget.app.ui.theme.ColorWarn
import com.fastget.app.ui.theme.LocalPalette
import java.io.File

// ─────────────────── Home list filter models ───────────────────

enum class HomeFilterCategory { ALL, OTHERS, ARCHIVES, PROGRAMS, VIDEO, MUSIC, IMAGES, DOCUMENTS, TORRENTS }
enum class HomeFilterStatus { ALL, STOPPED, RUNNING, FAILED, TIME, SUCCESSFUL }
enum class HomeFilterSort {
    DEFAULT, NAME_AZ, NAME_ZA, PROGRESS_HIGH, PROGRESS_LOW,
    SIZE_LARGE, SIZE_SMALL, STATUS_PRIORITY, NEWEST, OLDEST
}

private fun resolveCategory(e: DownloadEntity): HomeFilterCategory {
    if (e.kind == Kind.TORRENT) return HomeFilterCategory.TORRENTS
    return when (e.category) {
        Category.VIDEO -> HomeFilterCategory.VIDEO
        Category.AUDIO -> HomeFilterCategory.MUSIC
        Category.ARCHIVE -> HomeFilterCategory.ARCHIVES
        Category.APP -> HomeFilterCategory.PROGRAMS
        Category.IMAGE -> HomeFilterCategory.IMAGES
        Category.DOCUMENT -> HomeFilterCategory.DOCUMENTS
        else -> {
            // fallback by extension / kind
            when (Category.of(e.fileName)) {
                Category.VIDEO -> HomeFilterCategory.VIDEO
                Category.AUDIO -> HomeFilterCategory.MUSIC
                Category.ARCHIVE -> HomeFilterCategory.ARCHIVES
                Category.APP -> HomeFilterCategory.PROGRAMS
                Category.IMAGE -> HomeFilterCategory.IMAGES
                Category.DOCUMENT -> HomeFilterCategory.DOCUMENTS
                else -> if (e.kind == Kind.VIDEO) HomeFilterCategory.VIDEO
                else HomeFilterCategory.OTHERS
            }
        }
    }
}

private fun matchesStatus(e: DownloadEntity, s: HomeFilterStatus): Boolean = when (s) {
    HomeFilterStatus.ALL -> true
    HomeFilterStatus.STOPPED -> e.status == Status.PAUSED
    HomeFilterStatus.RUNNING -> e.status == Status.DOWNLOADING
    HomeFilterStatus.FAILED -> e.status == Status.FAILED
    HomeFilterStatus.TIME -> e.status == Status.DOWNLOADING || e.status == Status.PAUSED
    HomeFilterStatus.SUCCESSFUL -> e.status == Status.COMPLETED
}

private fun progressRatio(e: DownloadEntity): Float {
    val total = e.totalBytes
    if (total <= 0) return 0f
    return (e.downloadedBytes.toFloat() / total.toFloat()).coerceIn(0f, 1f)
}

private fun statusRank(status: String): Int = when (status) {
    Status.DOWNLOADING -> 0
    Status.PAUSED -> 1
    Status.QUEUED -> 2
    Status.FAILED -> 3
    Status.COMPLETED -> 4
    else -> 5
}

private fun applyHomeFilters(
    items: List<DownloadEntity>,
    cat: HomeFilterCategory,
    status: HomeFilterStatus,
    sort: HomeFilterSort
): List<DownloadEntity> {
    val filtered = items.filter { e ->
        val catOk = cat == HomeFilterCategory.ALL || resolveCategory(e) == cat
        catOk && matchesStatus(e, status)
    }
    return when (sort) {
        HomeFilterSort.DEFAULT -> filtered // id DESC already from DB observe
        HomeFilterSort.NAME_AZ -> filtered.sortedBy { it.fileName.lowercase() }
        HomeFilterSort.NAME_ZA -> filtered.sortedByDescending { it.fileName.lowercase() }
        HomeFilterSort.PROGRESS_HIGH -> filtered.sortedByDescending { progressRatio(it) }
        HomeFilterSort.PROGRESS_LOW -> filtered.sortedBy { progressRatio(it) }
        HomeFilterSort.SIZE_LARGE -> filtered.sortedByDescending { it.totalBytes.coerceAtLeast(0) }
        HomeFilterSort.SIZE_SMALL -> filtered.sortedBy { it.totalBytes.coerceAtLeast(0) }
        HomeFilterSort.STATUS_PRIORITY -> filtered.sortedWith(
            compareBy<DownloadEntity> { statusRank(it.status) }.thenByDescending { it.id }
        )
        HomeFilterSort.NEWEST -> filtered.sortedByDescending { it.createdAt }
        HomeFilterSort.OLDEST -> filtered.sortedBy { it.createdAt }
    }
}

private fun activeFilterCount(cat: HomeFilterCategory, status: HomeFilterStatus, sort: HomeFilterSort): Int {
    var n = 0
    if (cat != HomeFilterCategory.ALL) n++
    if (status != HomeFilterStatus.ALL) n++
    if (sort != HomeFilterSort.DEFAULT) n++
    return n
}

@Composable
fun App(vm: MainViewModel, auth: AuthFn) {
    // Keep runtime language in sync.
    com.fastget.app.core.I18n.set(vm.prefs.language.ifEmpty { "fa" })

    // First-run language choice (before lock screen so the user can read it).
    if (vm.prefs.language.isEmpty()) {
        LanguageScreen(onPick = { lang ->
            vm.prefs.language = lang
            com.fastget.app.core.I18n.set(lang)
            vm.screen = Screen.HOME
        })
        return
    }
    if (vm.locked) {
        LockScreen(auth = { auth(com.fastget.app.core.I18n.t("باز کردن فست‌گت", "Unlock FastGet")) { vm.locked = false } })
        return
    }
    BackHandler(enabled = vm.showFilterPanel) {
        vm.showFilterPanel = false
    }
    BackHandler(enabled = !vm.showFilterPanel && vm.screen != Screen.HOME && vm.screen != Screen.LANGUAGE) {
        vm.screen = Screen.HOME
    }
    when (vm.screen) {
        Screen.HOME -> HomeScreen(vm)
        Screen.SETTINGS -> SettingsScreen(vm)
        Screen.VIDEO -> VideoScreen(vm)
        Screen.VAULT -> VaultScreen(vm, auth)
        Screen.BROWSER -> BrowserScreen(vm)
        Screen.LANGUAGE -> LanguageScreen(onPick = { lang ->
            vm.prefs.language = lang
            com.fastget.app.core.I18n.set(lang)
            vm.screen = Screen.HOME
        })
    }
    if (vm.showAdd) AddSheet(vm)

    // آموزش سراسری (خانه / جستجو / مرورگر)
    if (vm.showTutorial) {
        LaunchedEffect(vm.tutorialStep) {
            val target = AppTutorialSteps.getOrNull(vm.tutorialStep)?.screen
            if (target != null && vm.screen != target) {
                vm.screen = target
            }
        }
        TutorialOverlay(
            stepIndex = vm.tutorialStep,
            onNext = {
                if (vm.tutorialStep >= AppTutorialSteps.lastIndex) {
                    vm.showTutorial = false
                    vm.prefs.tutorialDone = true
                    vm.screen = Screen.HOME
                } else {
                    vm.tutorialStep += 1
                }
            },
            onSkip = {
                vm.showTutorial = false
                vm.prefs.tutorialDone = true
                vm.screen = Screen.HOME
            }
        )
    }
}


@Composable
fun HomeScreen(vm: MainViewModel) {
    val all by vm.downloads.collectAsStateWithLifecycle()
    // فقط عمومی؛ vault جداست
    val publicItems = all.filter { !it.isPrivate }
    val items = remember(publicItems, vm.homeListId) {
        when (vm.homeListId) {
            "all" -> publicItems
            "main" -> publicItems.filter {
                val lid = it.listId.ifBlank { "main" }
                lid == "main"
            }
            else -> publicItems.filter { it.listId == vm.homeListId }
        }
    }
    val live by vm.live.collectAsStateWithLifecycle()
    var confirm by remember { mutableStateOf<DownloadEntity?>(null) }
    val cs = MaterialTheme.colorScheme

    // لیست واقعی پس از Category + Status + Sorting
    val filtered = remember(items, vm.filterCategory, vm.filterStatus, vm.filterSort) {
        applyHomeFilters(items, vm.filterCategory, vm.filterStatus, vm.filterSort)
    }
    val activeCount = items.count { it.status == Status.DOWNLOADING }
    val queuedCount = items.count { it.status == Status.QUEUED }
    val speed = live.values.sumOf { it.speed }
    val filterCount = activeFilterCount(vm.filterCategory, vm.filterStatus, vm.filterSort)

    // اولین ورود: آموزش نقطه‌ای
    LaunchedEffect(Unit) {
        if (!vm.prefs.tutorialDone && !vm.showTutorial) {
            vm.tutorialStep = 0
            vm.showTutorial = true
        }
    }

    Scaffold(
        containerColor = cs.background,
        floatingActionButton = {
            FloatingActionButton(
                onClick = { vm.openAdd() },
                containerColor = cs.primary,
                contentColor = cs.onPrimary
            ) {
                Icon(Icons.Rounded.Add, contentDescription = "افزودن لینک")
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(if (vm.prefs.homeGridLayout) 4.dp else 2.dp)
            ) {
                item { HeaderRow(vm, filterCount) }
                if (activeCount > 0 || queuedCount > 0) {
                    item {
                        Text(
                            buildString {
                                if (activeCount > 0) append("${fa(activeCount)} در حال دانلود")
                                if (activeCount > 0 && queuedCount > 0) append(" · ")
                                if (queuedCount > 0) append("${fa(queuedCount)} در صف")
                                if (speed > 0) append(" · ${fa(formatSpeed(speed))}")
                            },
                            style = MaterialTheme.typography.labelMedium,
                            color = cs.primary,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                    }
                }
                item { SearchEntry(onClick = { vm.screen = Screen.VIDEO }) }
                // سوییچ ساده لیست — فقط اگر لیست سفارشی وجود داشته باشد
                item { HomeListSwitcher(vm) }

                // Multi-select toolbar
                if (vm.hSelected.isNotEmpty()) {
                    item {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${vm.hSelected.size} انتخاب", style = MaterialTheme.typography.labelLarge)
                            Row {
                                TextButton(onClick = {
                                    filtered.forEach { vm.hSelected = vm.hSelected + it.id }
                                }) { Text("همه") }
                                TextButton(onClick = {
                                    vm.hSelected.forEach { id -> vm.manager.delete(id, true) }
                                    vm.hSelected = emptySet()
                                }) { Text(com.fastget.app.core.I18n.delete, color = ColorBad) }
                                TextButton(onClick = { vm.hSelected = emptySet() }) { Text("لغو") }
                            }
                        }
                    }
                }

                if (filtered.isEmpty()) {
                    item { EmptyState() }
                } else if (vm.prefs.homeGridLayout) {
                    // چینش تایل — دو ستونه
                    item {
                        val rows = filtered.chunked(2)
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            rows.forEach { row ->
                                Row(
                                    Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    row.forEach { e ->
                                        val selected = e.id in vm.hSelected
                                        Box(Modifier.weight(1f)) {
                                            DownloadCard(
                                                e, live[e.id], vm,
                                                selected = selected,
                                                tile = true,
                                                onToggleSelect = {
                                                    vm.hSelected =
                                                        if (e.id in vm.hSelected) vm.hSelected - e.id
                                                        else vm.hSelected + e.id
                                                },
                                                onDelete = { confirm = e }
                                            )
                                        }
                                    }
                                    if (row.size == 1) Spacer(Modifier.weight(1f))
                                }
                            }
                        }
                    }
                } else {
                    items(filtered, key = { it.id }) { e ->
                        val selected = e.id in vm.hSelected
                        DownloadCard(
                            e, live[e.id], vm,
                            selected = selected,
                            tile = false,
                            onToggleSelect = {
                                vm.hSelected =
                                    if (e.id in vm.hSelected) vm.hSelected - e.id
                                    else vm.hSelected + e.id
                            },
                            onDelete = { confirm = e }
                        )
                    }
                }
            }

            // پنل فیلتر روی لیست
            if (vm.showFilterPanel) {
                FilterPanelOverlay(vm)
            }

        }
    }

    confirm?.let { e ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            containerColor = cs.surface,
            title = { Text(com.fastget.app.core.I18n.deleteDownload) },
            text = { Text(e.fileName, maxLines = 2, overflow = TextOverflow.Ellipsis) },
            confirmButton = {
                TextButton(onClick = { vm.manager.delete(e.id, true); confirm = null }) {
                    Text(com.fastget.app.core.I18n.deleteWithFile, color = ColorBad)
                }
            },
            dismissButton = {
                TextButton(onClick = { vm.manager.delete(e.id, false); confirm = null }) {
                    Text(com.fastget.app.core.I18n.deleteFromList)
                }
            }
        )
    }
}

@Composable
private fun HeaderRow(vm: MainViewModel, filterCount: Int) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // سمت چپ: منو / قفل / تنظیمات — بدون نام برنامه
        var more by remember { mutableStateOf(false) }
        Box {
            IconButton(onClick = { more = true }) {
                Icon(Icons.Rounded.MoreVert, contentDescription = "بیشتر")
            }
            DropdownMenu(expanded = more, onDismissRequest = { more = false }) {
                DropdownMenuItem(
                    text = { Text(com.fastget.app.core.I18n.pauseAll) },
                    leadingIcon = { Icon(Icons.Rounded.PauseCircle, null) },
                    onClick = { more = false; vm.manager.pauseAll() }
                )
                DropdownMenuItem(
                    text = { Text(com.fastget.app.core.I18n.resumeAll) },
                    leadingIcon = { Icon(Icons.Rounded.PlayArrow, null) },
                    onClick = { more = false; vm.manager.resumeAll() }
                )
            }
        }
        IconButton(onClick = { vm.screen = Screen.VAULT }) {
            Icon(Icons.Rounded.Lock, contentDescription = "پوشهٔ خصوصی")
        }
        IconButton(onClick = { vm.screen = Screen.SETTINGS }) {
            Icon(Icons.Rounded.Settings, contentDescription = "تنظیمات")
        }
        Spacer(Modifier.weight(1f))
        // سمت راست: آیکن فیلتر (Sliders / Tune) + نشانگر تعداد
        Box {
            IconButton(onClick = { vm.showFilterPanel = !vm.showFilterPanel }) {
                Icon(
                    Icons.Rounded.Tune,
                    contentDescription = "فیلتر",
                    tint = cs.primary,
                    modifier = Modifier.size(24.dp)
                )
            }
            if (filterCount > 0) {
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 6.dp, end = 6.dp)
                        .size(16.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(cs.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        fa(filterCount),
                        color = cs.onPrimary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun SearchEntry(onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(cs.surface)
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Search, null, tint = cs.primary)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(com.fastget.app.core.I18n.searchMusicVideo, fontWeight = FontWeight.SemiBold)
            Text(
                com.fastget.app.core.I18n.searchHint,
                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
            )
        }
    }
}

/**
 * لیست‌ها پیش‌فرض جمع‌شده و تقریباً مخفی‌اند.
 * با ردیف ظریف «لیست‌ها» باز می‌شوند؛ چیپ‌ها pill نرم.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun HomeListSwitcher(vm: MainViewModel) {
    val customs = vm.prefs.customLists()
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    var expanded by remember { mutableStateOf(false) }
    var showCreate by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var deleteTarget by remember { mutableStateOf<Prefs.DownloadListDef?>(null) }

    val currentTitle = when (vm.homeListId) {
        "all" -> "همه"
        "main" -> com.fastget.app.core.I18n.listMain
        else -> customs.firstOrNull { it.id == vm.homeListId }?.title ?: com.fastget.app.core.I18n.lists
    }

    Column(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .clickable { expanded = !expanded }
                .padding(horizontal = 4.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                com.fastget.app.core.I18n.lists,
                style = MaterialTheme.typography.labelMedium,
                color = cs.onSurfaceVariant.copy(alpha = 0.85f)
            )
            Spacer(Modifier.width(6.dp))
            Box(
                Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(cs.primary.copy(alpha = 0.12f))
                    .padding(horizontal = 10.dp, vertical = 3.dp)
            ) {
                Text(
                    currentTitle,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = cs.primary
                )
            }
            Spacer(Modifier.weight(1f))
            Icon(
                if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                contentDescription = null,
                tint = cs.onSurfaceVariant.copy(alpha = 0.7f),
                modifier = Modifier.size(20.dp)
            )
        }

        AnimatedVisibility(
            visible = expanded,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            Column(Modifier.padding(top = 6.dp, bottom = 4.dp)) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf("all" to com.fastget.app.core.I18n.listAll, "main" to com.fastget.app.core.I18n.listMain).forEach { (id, title) ->
                        PrettyListChip(
                            title = title,
                            selected = vm.homeListId == id,
                            onClick = { vm.homeListId = id }
                        )
                    }
                    customs.forEach { list ->
                        PrettyListChip(
                            title = list.title,
                            selected = vm.homeListId == list.id,
                            onClick = { vm.homeListId = list.id },
                            onLongClick = { deleteTarget = list }
                        )
                    }
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(22.dp))
                            .border(
                                width = 1.dp,
                                color = cs.primary.copy(alpha = 0.35f),
                                shape = RoundedCornerShape(22.dp)
                            )
                            .clickable { showCreate = true; newName = "" }
                            .padding(horizontal = 14.dp, vertical = 9.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Rounded.Add,
                                null,
                                Modifier.size(15.dp),
                                tint = cs.primary.copy(alpha = 0.9f)
                            )
                            Spacer(Modifier.width(5.dp))
                            Text(
                                com.fastget.app.core.I18n.listNew,
                                style = MaterialTheme.typography.labelLarge,
                                color = cs.primary.copy(alpha = 0.9f)
                            )
                        }
                    }
                }
                if (customs.isNotEmpty()) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "برای حذف لیست، نگه دارید",
                        style = MaterialTheme.typography.labelSmall,
                        color = cs.onSurfaceVariant.copy(alpha = 0.55f)
                    )
                }
            }
        }
    }

    if (showCreate) {
        AlertDialog(
            onDismissRequest = { showCreate = false },
            containerColor = cs.surface,
            shape = RoundedCornerShape(24.dp),
            title = { Text("لیست جدید", fontWeight = FontWeight.SemiBold) },
            text = {
                Column {
                    Text(
                        "یک نام کوتاه بگذارید؛ بعداً از افزودن لینک یا منوی فایل به این لیست بفرستید.",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant
                    )
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text(com.fastget.app.core.I18n.nameLabel) },
                        shape = RoundedCornerShape(16.dp)
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val t = newName.trim()
                        if (t.isEmpty()) {
                            Toast.makeText(ctx, "نام را وارد کنید", Toast.LENGTH_SHORT).show()
                            return@TextButton
                        }
                        val def = vm.prefs.addCustomList(t)
                        vm.homeListId = def.id
                        expanded = true
                        showCreate = false
                        Toast.makeText(ctx, "«${def.title}» آماده است", Toast.LENGTH_SHORT).show()
                    }
                ) { Text(com.fastget.app.core.I18n.createList, color = cs.primary) }
            },
            dismissButton = {
                TextButton(onClick = { showCreate = false }) { Text(com.fastget.app.core.I18n.later) }
            }
        )
    }

    deleteTarget?.let { list ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            containerColor = cs.surface,
            shape = RoundedCornerShape(24.dp),
            title = { Text("حذف «${list.title}»؟") },
            text = { Text("دانلودها پاک نمی‌شوند؛ در «همه» می‌مانند.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        vm.prefs.removeCustomList(list.id)
                        if (vm.homeListId == list.id) vm.homeListId = "main"
                        deleteTarget = null
                    }
                ) { Text(com.fastget.app.core.I18n.delete, color = ColorBad) }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) { Text(com.fastget.app.core.I18n.cancel) }
            }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PrettyListChip(
    title: String,
    selected: Boolean,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null
) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(22.dp)
    val bg = if (selected) cs.primary else cs.surfaceVariant.copy(alpha = 0.45f)
    val fg = if (selected) cs.onPrimary else cs.onSurface.copy(alpha = 0.88f)
    Box(
        Modifier
            .clip(shape)
            .background(bg)
            .then(
                if (onLongClick != null) {
                    Modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick)
                } else {
                    Modifier.clickable(onClick = onClick)
                }
            )
            .padding(horizontal = 16.dp, vertical = 9.dp)
    ) {
        Text(
            title,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
            color = fg,
            maxLines = 1
        )
    }
}

@Composable
private fun FilterPanelOverlay(vm: MainViewModel) {
    val cs = MaterialTheme.colorScheme
    // انتخاب موقت تا قبل از Apply
    var draftCat by remember(vm.showFilterPanel) { mutableStateOf(vm.filterCategory) }
    var draftStatus by remember(vm.showFilterPanel) { mutableStateOf(vm.filterStatus) }
    var draftSort by remember(vm.showFilterPanel) { mutableStateOf(vm.filterSort) }
    var openCat by remember { mutableStateOf(true) }
    var openStatus by remember { mutableStateOf(false) }
    var openSort by remember { mutableStateOf(false) }

    // پس‌زمینه تیره برای بستن با لمس بیرون
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.35f))
            .clickable { vm.showFilterPanel = false }
    ) {
        Surface(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 52.dp, end = 12.dp, start = 12.dp)
                .fillMaxWidth(0.92f)
                .clickable(enabled = false) { /* block dismiss */ },
            shape = RoundedCornerShape(20.dp),
            color = cs.surface,
            tonalElevation = 6.dp,
            shadowElevation = 8.dp
        ) {
            Column(
                Modifier
                    .padding(14.dp)
                    .heightIn(max = 480.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    "فیلتر فهرست",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(10.dp))

                FilterSection(
                    title = "Category",
                    expanded = openCat,
                    onToggle = { openCat = !openCat }
                ) {
                    HomeFilterCategory.entries.forEach { opt ->
                        FilterOptionRow(
                            label = categoryLabel(opt),
                            selected = draftCat == opt,
                            onClick = { draftCat = opt }
                        )
                    }
                }

                FilterSection(
                    title = "Status",
                    expanded = openStatus,
                    onToggle = { openStatus = !openStatus }
                ) {
                    HomeFilterStatus.entries.forEach { opt ->
                        FilterOptionRow(
                            label = statusLabel(opt),
                            selected = draftStatus == opt,
                            onClick = { draftStatus = opt }
                        )
                    }
                }

                FilterSection(
                    title = "Sorting",
                    expanded = openSort,
                    onToggle = { openSort = !openSort }
                ) {
                    HomeFilterSort.entries.forEach { opt ->
                        FilterOptionRow(
                            label = sortLabel(opt),
                            selected = draftSort == opt,
                            onClick = { draftSort = opt }
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))
                HorizontalDivider(color = cs.outline.copy(alpha = 0.25f))
                Spacer(Modifier.height(12.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            draftCat = HomeFilterCategory.ALL
                            draftStatus = HomeFilterStatus.ALL
                            draftSort = HomeFilterSort.DEFAULT
                            vm.filterCategory = HomeFilterCategory.ALL
                            vm.filterStatus = HomeFilterStatus.ALL
                            vm.filterSort = HomeFilterSort.DEFAULT
                            vm.showFilterPanel = false
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp)
                    ) { Text(com.fastget.app.core.I18n.clearFilters) }
                    Button(
                        onClick = {
                            vm.filterCategory = draftCat
                            vm.filterStatus = draftStatus
                            vm.filterSort = draftSort
                            vm.showFilterPanel = false
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = cs.primary,
                            contentColor = cs.onPrimary
                        )
                    ) { Text(com.fastget.app.core.I18n.apply) }
                }
            }
        }
    }
}

@Composable
private fun FilterSection(
    title: String,
    expanded: Boolean,
    onToggle: () -> Unit,
    content: @Composable () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .clickable(onClick = onToggle)
                .padding(vertical = 10.dp, horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                color = cs.primary,
                modifier = Modifier.weight(1f)
            )
            Icon(
                if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                contentDescription = null,
                tint = cs.onSurfaceVariant
            )
        }
        AnimatedVisibility(
            visible = expanded,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            Column(Modifier.padding(start = 4.dp, bottom = 6.dp)) {
                content()
            }
        }
    }
}

@Composable
private fun FilterOptionRow(label: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .background(if (selected) cs.primary.copy(alpha = 0.12f) else Color.Transparent)
            .padding(horizontal = 10.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            if (selected) Icons.Rounded.RadioButtonChecked else Icons.Rounded.RadioButtonUnchecked,
            contentDescription = null,
            tint = if (selected) cs.primary else cs.onSurfaceVariant,
            modifier = Modifier.size(20.dp)
        )
        Spacer(Modifier.width(10.dp))
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            color = if (selected) cs.primary else cs.onSurface
        )
    }
}

private fun categoryLabel(c: HomeFilterCategory): String = when (c) {
    HomeFilterCategory.ALL -> "All"
    HomeFilterCategory.OTHERS -> "Others"
    HomeFilterCategory.ARCHIVES -> "Archives"
    HomeFilterCategory.PROGRAMS -> "Programs"
    HomeFilterCategory.VIDEO -> "Video"
    HomeFilterCategory.MUSIC -> "Music"
    HomeFilterCategory.IMAGES -> "Images"
    HomeFilterCategory.DOCUMENTS -> "Documents"
    HomeFilterCategory.TORRENTS -> "Torrents"
}

private fun statusLabel(s: HomeFilterStatus): String = when (s) {
    HomeFilterStatus.ALL -> "All"
    HomeFilterStatus.STOPPED -> "Stopped"
    HomeFilterStatus.RUNNING -> "Running"
    HomeFilterStatus.FAILED -> "Failed"
    HomeFilterStatus.TIME -> "Time"
    HomeFilterStatus.SUCCESSFUL -> "Successful"
}

private fun sortLabel(s: HomeFilterSort): String = when (s) {
    HomeFilterSort.DEFAULT -> "Default order"
    HomeFilterSort.NAME_AZ -> "Name: A → Z"
    HomeFilterSort.NAME_ZA -> "Name: Z → A"
    HomeFilterSort.PROGRESS_HIGH -> "Progress: highest"
    HomeFilterSort.PROGRESS_LOW -> "Progress: lowest"
    HomeFilterSort.SIZE_LARGE -> "Size: largest"
    HomeFilterSort.SIZE_SMALL -> "Size: smallest"
    HomeFilterSort.STATUS_PRIORITY -> "Status priority"
    HomeFilterSort.NEWEST -> "Newest first"
    HomeFilterSort.OLDEST -> "Oldest first"
}

@Composable
private fun EmptyState() {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            Icons.Rounded.CloudDownload, null,
            Modifier.size(56.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(12.dp))
        Text(com.fastget.app.core.I18n.nothingToShow, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(4.dp))
        Text(
            "با «افزودن لینک» شروع کنید یا در مرورگر از گزینهٔ اشتراک‌گذاری، تندگیر را انتخاب کنید.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}

private fun categoryStyle(c: String): Pair<ImageVector, Color> = when (c) {
    Category.VIDEO -> Icons.Rounded.Movie to Color(0xFFF43F5E)
    Category.AUDIO -> Icons.Rounded.MusicNote to Color(0xFFA855F7)
    Category.DOCUMENT -> Icons.Rounded.Description to Color(0xFF3B82F6)
    Category.ARCHIVE -> Icons.Rounded.FolderZip to Color(0xFFF59E0B)
    Category.APP -> Icons.Rounded.Apps to Color(0xFF22C55E)
    Category.IMAGE -> Icons.Rounded.Image to Color(0xFF06B6D4)
    else -> Icons.Rounded.InsertDriveFile to Color(0xFF94A3B8)
}

private fun statusText(e: DownloadEntity): String = when (e.status) {
    Status.DOWNLOADING ->
        if (e.totalBytes > 0) "${fa((e.downloadedBytes * 100 / e.totalBytes).toInt())}٪ دریافت شد"
        else "در حال دریافت"
    Status.QUEUED -> "در صف انتظار"
    Status.PAUSED -> "متوقف شده"
    Status.FAILED -> e.error ?: "ناموفق"
    else -> fa(formatBytes(e.totalBytes))
}

@Composable
private fun statusColor(status: String): Color = when (status) {
    Status.DOWNLOADING -> MaterialTheme.colorScheme.primary
    Status.COMPLETED -> ColorOk
    Status.FAILED -> ColorBad
    Status.PAUSED -> ColorWarn
    else -> MaterialTheme.colorScheme.onSurfaceVariant
}

@Composable
@OptIn(ExperimentalFoundationApi::class)
internal fun DownloadCard(
    e: DownloadEntity,
    live: Live?,
    vm: MainViewModel,
    onDelete: () -> Unit,
    selected: Boolean = false,
    onToggleSelect: (() -> Unit)? = null,
    tile: Boolean = false
) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val (icon, color) = categoryStyle(e.category)
    var menu by remember { mutableStateOf(false) }
    var editUrl by remember { mutableStateOf(false) }
    var urlDraft by remember(e.url) { mutableStateOf(e.url) }

    Card(
        shape = RoundedCornerShape(if (tile) 14.dp else 10.dp),
        colors = CardDefaults.cardColors(containerColor = cs.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = if (tile) 1.dp else 0.dp),
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (selected) Modifier.border(2.dp, cs.primary, RoundedCornerShape(if (tile) 14.dp else 10.dp))
                else Modifier
            )
            .then(
                if (onToggleSelect != null)
                    Modifier.combinedClickable(onClick = { }, onLongClick = onToggleSelect)
                else Modifier
            )
    ) {
        Column(Modifier.padding(horizontal = if (tile) 8.dp else 10.dp, vertical = if (tile) 8.dp else 6.dp)) {
            if (tile) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(72.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(color.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    if (e.thumbnail != null) {
                        AsyncImage(
                            model = e.thumbnail, contentDescription = null, contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Icon(icon, null, tint = color, modifier = Modifier.size(28.dp))
                    }
                }
                Spacer(Modifier.height(6.dp))
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.then(
                    if (onToggleSelect != null) Modifier.combinedClickable(
                        onClick = { if (vm.hSelected.isNotEmpty()) onToggleSelect() },
                        onLongClick = onToggleSelect
                    ) else Modifier
                )
            ) {
                if (!tile) {
                    Box(
                        Modifier.size(24.dp).clip(RoundedCornerShape(6.dp))
                            .background(color.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (e.thumbnail != null) {
                            AsyncImage(
                                model = e.thumbnail, contentDescription = null, contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(8.dp))
                            )
                        } else {
                            Icon(icon, null, tint = color, modifier = Modifier.size(14.dp))
                        }
                    }
                    Spacer(Modifier.width(8.dp))
                }
                Text(
                    e.fileName,
                    maxLines = if (tile) 2 else 1,
                    overflow = TextOverflow.Ellipsis,
                    style = if (tile) MaterialTheme.typography.labelLarge else MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.weight(1f)
                )
                if (!tile) {
                    PrimaryAction(e, vm, ctx)
                }
                Box {
                    IconButton(onClick = { menu = true }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Rounded.MoreVert, contentDescription = "بیشتر", modifier = Modifier.size(18.dp))
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(
                            text = { Text(com.fastget.app.core.I18n.copyLink) },
                            onClick = {
                                menu = false
                                vm.lastClip = e.url
                                ctx.getSystemService(ClipboardManager::class.java)
                                    .setPrimaryClip(ClipData.newPlainText("url", e.url))
                                Toast.makeText(ctx, "لینک کپی شد", Toast.LENGTH_SHORT).show()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(com.fastget.app.core.I18n.editLink) },
                            onClick = {
                                menu = false
                                urlDraft = e.url
                                editUrl = true
                            }
                        )
                        if (e.status == Status.QUEUED || e.status == Status.PAUSED) {
                            DropdownMenuItem(
                                text = { Text(com.fastget.app.core.I18n.priorityUp) },
                                onClick = {
                                    menu = false
                                    vm.manager.setPriority(e.id, e.priority + 1)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(com.fastget.app.core.I18n.priorityDown) },
                                onClick = {
                                    menu = false
                                    vm.manager.setPriority(e.id, e.priority - 1)
                                }
                            )
                        }
                        DropdownMenuItem(
                            text = { Text(com.fastget.app.core.I18n.refreshLinkContinue) },
                            onClick = {
                                menu = false
                                vm.manager.refreshAndContinue(e.id)
                                Toast.makeText(ctx, "در حال رفرش لینک…", Toast.LENGTH_SHORT).show()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(com.fastget.app.core.I18n.restart) },
                            onClick = { menu = false; vm.manager.restart(e.id) }
                        )
                        if (e.isPrivate || e.listId == "vault") {
                            DropdownMenuItem(
                                text = { Text(com.fastget.app.core.I18n.moveToMain) },
                                onClick = {
                                    menu = false
                                    vm.manager.moveToList(e.id, "main")
                                    Toast.makeText(ctx, "به لیست اصلی منتقل شد", Toast.LENGTH_SHORT).show()
                                }
                            )
                        } else {
                            DropdownMenuItem(
                                text = { Text(com.fastget.app.core.I18n.moveToLocked) },
                                onClick = {
                                    menu = false
                                    vm.manager.moveToList(e.id, "vault")
                                    Toast.makeText(ctx, "به فضای محافظت‌شده منتقل شد", Toast.LENGTH_SHORT).show()
                                }
                            )
                        }
                        vm.prefs.customLists().forEach { list ->
                            if (list.id != e.listId) {
                                DropdownMenuItem(
                                    text = { Text("انتقال به «${list.title}»") },
                                    onClick = {
                                        menu = false
                                        vm.manager.moveToList(e.id, list.id)
                                        Toast.makeText(ctx, "منتقل شد", Toast.LENGTH_SHORT).show()
                                    }
                                )
                            }
                        }
                        DropdownMenuItem(
                            text = { Text(com.fastget.app.core.I18n.delete, color = ColorBad) },
                            onClick = { menu = false; onDelete() }
                        )
                    }
                }
            }

            if (e.status != Status.COMPLETED) {
                Spacer(Modifier.height(6.dp))
                val isVideoScale = e.kind == Kind.VIDEO && e.totalBytes == DownloadManager.VIDEO_SCALE
                if (e.totalBytes > 0 && !isVideoScale) {
                    SegmentBar(e)
                } else if (e.status == Status.DOWNLOADING || isVideoScale) {
                    val frac = if (e.totalBytes > 0)
                        (e.downloadedBytes.toFloat() / e.totalBytes.toFloat()).coerceIn(0f, 1f)
                    else 0f
                    LinearProgressIndicator(
                        progress = frac,
                        modifier = Modifier.fillMaxWidth().height(3.dp).clip(RoundedCornerShape(2.dp)),
                        color = cs.primary,
                        trackColor = cs.surfaceVariant
                    )
                }
                Spacer(Modifier.height(4.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    val sizeLine = when {
                        isVideoScale && e.totalBytes > 0 -> {
                            val pct = ((e.downloadedBytes * 100) / e.totalBytes).toInt().coerceIn(0, 99)
                            "${fa(pct)}٪ دریافت شد"
                        }
                        e.totalBytes > 0 -> {
                            val left = (e.totalBytes - e.downloadedBytes).coerceAtLeast(0)
                            "${fa(formatBytes(e.downloadedBytes))} / ${fa(formatBytes(e.totalBytes))} · باقی ${fa(formatBytes(left))}"
                        }
                        else -> fa(formatBytes(e.downloadedBytes))
                    }
                    Text(sizeLine, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                    if (e.status == Status.DOWNLOADING && live != null) {
                        val eta = if (live.etaSec >= 0) " · ${fa(formatEta(live.etaSec))}" else ""
                        Text(
                            fa(formatSpeed(live.speed)) + eta,
                            style = MaterialTheme.typography.labelSmall,
                            color = cs.primary
                        )
                    } else {
                        Text(
                            statusText(e),
                            style = MaterialTheme.typography.labelSmall,
                            color = statusColor(e.status)
                        )
                    }
                }
            } else {
                Spacer(Modifier.height(2.dp))
                Text(
                    fa(formatBytes(e.totalBytes)),
                    style = MaterialTheme.typography.labelSmall,
                    color = cs.onSurfaceVariant
                )
            }
        }
    }

    if (editUrl) {
        AlertDialog(
            onDismissRequest = { editUrl = false },
            title = { Text(com.fastget.app.core.I18n.editLink) },
            text = {
                OutlinedTextField(
                    value = urlDraft,
                    onValueChange = { urlDraft = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = false,
                    maxLines = 4,
                    label = { Text(com.fastget.app.core.I18n.newLink) }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.manager.updateUrl(e.id, urlDraft)
                    editUrl = false
                    Toast.makeText(ctx, "لینک به‌روز شد", Toast.LENGTH_SHORT).show()
                }) { Text(com.fastget.app.core.I18n.save) }
            },
            dismissButton = {
                TextButton(onClick = { editUrl = false }) { Text(com.fastget.app.core.I18n.cancel) }
            }
        )
    }
}

@Composable
private fun PrimaryAction(e: DownloadEntity, vm: MainViewModel, ctx: Context) {
    when (e.status) {
        Status.DOWNLOADING, Status.QUEUED ->
            IconButton(onClick = { vm.manager.pause(e.id) }) {
                Icon(Icons.Rounded.Pause, contentDescription = "توقف")
            }
        Status.PAUSED ->
            IconButton(onClick = { vm.manager.resume(e.id) }) {
                Icon(Icons.Rounded.PlayArrow, contentDescription = "ادامه")
            }
        Status.FAILED ->
            IconButton(onClick = { vm.manager.retry(e.id) }) {
                Icon(Icons.Rounded.Refresh, contentDescription = "تلاش دوباره")
            }
        else ->
            IconButton(onClick = { openDownload(ctx, e) }) {
                Icon(Icons.Rounded.FolderOpen, contentDescription = "باز کردن")
            }
    }
}

/** Draws one slice per segment, so you can see the parallel connections filling in. */
@Composable
private fun SegmentBar(e: DownloadEntity) {
    val pal = LocalPalette.current
    val cs = MaterialTheme.colorScheme
    val segs = remember(e.segments) { Segments.decode(e.segments) }
    Canvas(Modifier.fillMaxWidth().height(3.dp).clip(RoundedCornerShape(2.dp))) {
        val rtl = layoutDirection == LayoutDirection.Rtl
        val total = e.totalBytes.toFloat().coerceAtLeast(1f)
        drawRect(cs.surfaceVariant)

        fun slice(startFrac: Float, widthFrac: Float, c: Color) {
            val w = (size.width * widthFrac).coerceAtLeast(0f)
            val x = size.width * startFrac
            drawRect(c, Offset(if (rtl) size.width - x - w else x, 0f), Size(w, size.height))
        }

        if (segs.isEmpty()) {
            slice(0f, e.downloadedBytes / total, pal.primary)
        } else {
            segs.forEachIndexed { i, s ->
                slice(s.start / total, s.done.get() / total, if (i % 2 == 0) pal.primary else pal.secondary)
            }
            segs.drop(1).forEach { s ->
                slice(s.start / total, 1.5f / size.width, cs.surface)
            }
        }
    }
}

private fun openDownload(ctx: Context, e: DownloadEntity) {
    val uri: Uri = try {
        if (e.publicUri != null) Uri.parse(e.publicUri)
        else FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", File(e.localPath))
    } catch (_: Exception) {
        Toast.makeText(ctx, "فایل پیدا نشد", Toast.LENGTH_SHORT).show()
        return
    }
    val intent = Intent(Intent.ACTION_VIEW)
        .setDataAndType(uri, mimeOf(e.fileName))
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        ctx.startActivity(intent)
    } catch (_: ActivityNotFoundException) {
        Toast.makeText(ctx, "برنامه‌ای برای باز کردن این فایل نیست", Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun LanguageScreen(onPick: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier
            .fillMaxSize()
            .background(cs.background)
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally
    ) {
        Text(
            "فست‌گت / FastGet",
            style = MaterialTheme.typography.headlineMedium,
            color = cs.onBackground
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "زبان برنامه را انتخاب کنید\nChoose your language",
            style = MaterialTheme.typography.bodyLarge,
            color = cs.onSurfaceVariant,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        Spacer(Modifier.height(40.dp))
        androidx.compose.material3.Button(
            onClick = { onPick("fa") },
            Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text("فارسی", style = MaterialTheme.typography.titleMedium)
        }
        Spacer(Modifier.height(16.dp))
        androidx.compose.material3.OutlinedButton(
            onClick = { onPick("en") },
            Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text("English", style = MaterialTheme.typography.titleMedium)
        }
    }
}

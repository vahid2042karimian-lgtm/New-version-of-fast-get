package com.fastget.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CheckCircle
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import com.fastget.app.core.Prefs
import com.fastget.app.ui.theme.ColorBad
import androidx.fragment.app.FragmentActivity
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import com.fastget.app.core.EngineState
import com.fastget.app.core.Security
import com.fastget.app.core.VideoEngine
import kotlinx.coroutines.launch
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.fastget.app.core.fa
import com.fastget.app.ui.theme.AppPalette
import com.fastget.app.ui.theme.Palettes
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val p = vm.prefs
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val engine by VideoEngine.state.collectAsState()
    // null = main menu; otherwise detail page id
    var page by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier.fillMaxSize().statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
            .padding(bottom = 32.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = {
                if (page != null) page = null else vm.screen = Screen.HOME
            }) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "بازگشت")
            }
            Text(
                when (page) {
                    "lang" -> "زبان"
                    "sites" -> "سایت‌های جستجو"
                    "browser" -> "میانبر مرورگر"
                    "schedule" -> "زمان‌بندی"
                    "path" -> "مسیر ذخیره"
                    "display" -> "نمایش"
                    "theme" -> "تم رنگی"
                    "speed" -> "سرعت و اتصال"
                    "behavior" -> "رفتار برنامه"
                    "security" -> "امنیت"
                    "lists" -> "لیست‌های دانلود"
                    "engine" -> "موتور ویدیو"
                    else -> com.fastget.app.core.I18n.settings
                },
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }

        if (page == null) {
            // Main menu — one row per category
            SettingsMenuRow(com.fastget.app.core.I18n.language) { page = "lang" }
            SettingsMenuRow(com.fastget.app.core.I18n.searchSites) { page = "sites" }
            SettingsMenuRow(com.fastget.app.core.I18n.browserShortcuts) { page = "browser" }
            SettingsMenuRow(com.fastget.app.core.I18n.schedule) { page = "schedule" }
            SettingsMenuRow(com.fastget.app.core.I18n.downloadLists) { page = "lists" }
            SettingsMenuRow(com.fastget.app.core.I18n.savePath) { page = "path" }
            SettingsMenuRow(com.fastget.app.core.I18n.display) { page = "display" }
            SettingsMenuRow(com.fastget.app.core.I18n.theme) { page = "theme" }
            SettingsMenuRow(com.fastget.app.core.I18n.speedConn) { page = "speed" }
            SettingsMenuRow(com.fastget.app.core.I18n.behavior) { page = "behavior" }
            SettingsMenuRow(com.fastget.app.core.I18n.guide) {
                vm.tutorialStep = 0
                vm.showTutorial = true
                vm.screen = Screen.HOME
            }
            SettingsMenuRow(com.fastget.app.core.I18n.securityShort) { page = "security" }
            SettingsMenuRow(com.fastget.app.core.I18n.videoEngine) { page = "engine" }
            return@Column
        }

        if (page == "lang") Accordion("زبان / Language", startOpen = true, showHeader = false) {
            Text(
                "زبان برنامه (فعلاً فقط ذخیره می‌شود؛ ترجمه کامل متن‌ها در قدم‌های بعد)",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilterChip(
                    selected = p.language == "fa" || p.language.isEmpty(),
                    onClick = {
                        p.language = "fa"
                        com.fastget.app.core.I18n.set("fa")
                    },
                    label = { Text("فارسی") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = cs.primaryContainer,
                        selectedLabelColor = cs.onPrimaryContainer
                    )
                )
                FilterChip(
                    selected = p.language == "en",
                    onClick = {
                        p.language = "en"
                        com.fastget.app.core.I18n.set("en")
                    },
                    label = { Text("English") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = cs.primaryContainer,
                        selectedLabelColor = cs.onPrimaryContainer
                    )
                )
            }
        }

        if (page == "sites") Accordion("موتورهای جستجو — سایت‌ها", startOpen = true, showHeader = false) {
            Text(
                "هر خط یک دامنه. موتورها فقط از این لیست‌ها جستجو می‌کنند. نام سایت‌ها در صفحه جستجو نشان داده نمی‌شود.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("جستجوی گوگل / داک‌داک‌گو", style = MaterialTheme.typography.bodyLarge)
                    Text(
                        "نتایج وب را هم برای لینک دانلود استخراج می‌کند",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant
                    )
                }
                Switch(
                    checked = p.googleSearchEnabled,
                    onCheckedChange = { p.googleSearchEnabled = it },
                    colors = SwitchDefaults.colors(checkedTrackColor = cs.primary)
                )
            }
            Spacer(Modifier.height(12.dp))
            SiteListEditor("ویدیو", p.sitesVideo) { p.sitesVideo = it }
            Spacer(Modifier.height(10.dp))
            SiteListEditor("صدا", p.sitesAudio) { p.sitesAudio = it }
            Spacer(Modifier.height(10.dp))
            SiteListEditor("فایل", p.sitesFile) { p.sitesFile = it }
            Spacer(Modifier.height(10.dp))
            SiteListEditor("تورنت", p.sitesTorrent) { p.sitesTorrent = it }
        }

        if (page == "browser") Accordion("میانبر مرورگر", startOpen = true, showHeader = false) {
            Text(
                "لیست قدیمی میانبر باز کردن در مرورگر داخلی (اختیاری).",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            var sitesDraft by remember(p.customSites) { mutableStateOf(p.customSites) }
            OutlinedTextField(
                value = sitesDraft,
                onValueChange = { sitesDraft = it },
                modifier = Modifier.fillMaxWidth().height(100.dp),
                label = { Text("میانبرها") }
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = { p.customSites = sitesDraft }) {
                Text("ذخیره میانبرها")
            }
        }

        if (page == "schedule") Accordion("زمان‌بندی دانلود", startOpen = true, showHeader = false) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("فعال‌سازی زمان‌بندی", style = MaterialTheme.typography.bodyLarge)
                    Text(
                        "فقط در بازه ساعت مشخص دانلودهای جدید شروع شوند",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant
                    )
                }
                Switch(
                    checked = p.scheduleEnabled,
                    onCheckedChange = { p.scheduleEnabled = it },
                    colors = SwitchDefaults.colors(checkedTrackColor = cs.primary)
                )
            }
            if (p.scheduleEnabled) {
                Spacer(Modifier.height(12.dp))
                Text(
                    "از ساعت ${fa(p.scheduleStartHour)} تا ${fa(p.scheduleEndHour)}",
                    style = MaterialTheme.typography.bodyMedium
                )
                Text("ساعت شروع: ${fa(p.scheduleStartHour)}", style = MaterialTheme.typography.bodySmall)
                Slider(
                    value = p.scheduleStartHour.toFloat(),
                    onValueChange = { p.scheduleStartHour = it.roundToInt() },
                    valueRange = 0f..23f,
                    steps = 22,
                    colors = SliderDefaults.colors(thumbColor = cs.primary, activeTrackColor = cs.primary)
                )
                Text("ساعت پایان: ${fa(p.scheduleEndHour)}", style = MaterialTheme.typography.bodySmall)
                Slider(
                    value = p.scheduleEndHour.toFloat(),
                    onValueChange = { p.scheduleEndHour = it.roundToInt() },
                    valueRange = 0f..23f,
                    steps = 22,
                    colors = SliderDefaults.colors(thumbColor = cs.primary, activeTrackColor = cs.primary)
                )
                Spacer(Modifier.height(12.dp))
                Text("اعمال روی لیست‌ها", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                Text(
                    "کدام لیست‌ها فقط در این بازه شروع شوند",
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant
                )
                Spacer(Modifier.height(6.dp))
                val targets = p.scheduleTargetsSet()
                ScheduleTargetChip("همه لیست‌ها", "all" in targets) {
                    p.scheduleTargetLists = if ("all" in targets) "main" else "all"
                }
                ScheduleTargetChip("لیست اصلی", "all" in targets || "main" in targets) {
                    if ("all" in targets) p.scheduleTargetLists = "main"
                    else toggleScheduleTarget(p, "main")
                }
                // لیست محافظت‌شده فقط با نام خنثی — بدون اشاره به محتوا
                ScheduleTargetChip("فضای قفل‌شده", "all" in targets || "vault" in targets) {
                    if ("all" in targets) p.scheduleTargetLists = "vault"
                    else toggleScheduleTarget(p, "vault")
                }
                p.customLists().forEach { list ->
                    ScheduleTargetChip(list.title, "all" in targets || list.id in targets) {
                        if ("all" in targets) p.scheduleTargetLists = list.id
                        else toggleScheduleTarget(p, list.id)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            HorizontalDivider(color = cs.outline.copy(alpha = 0.25f))
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f).padding(end = 8.dp)) {
                    Text("زمان‌بندی فضای قفل‌شده", style = MaterialTheme.typography.bodyLarge)
                    Text(
                        "مستقل از لیست اصلی؛ برای تغییر نیاز به تأیید هویت دارد",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant
                    )
                }
                Switch(
                    checked = p.scheduleVaultEnabled,
                    onCheckedChange = { want ->
                        val act = ctx as? FragmentActivity
                        if (want && p.vaultLockMode != "none" && act != null && Security.available(ctx)) {
                            Security.prompt(
                                activity = act,
                                title = "تأیید زمان‌بندی فضای قفل‌شده",
                                onSuccess = { p.scheduleVaultEnabled = true }
                            )
                        } else {
                            p.scheduleVaultEnabled = want
                        }
                    },
                    colors = SwitchDefaults.colors(checkedTrackColor = cs.primary)
                )
            }
        }

        if (page == "lists") Accordion("لیست‌های دانلود", startOpen = true, showHeader = false) {
            Text(
                "لیست اصلی و فضای قفل‌شده همیشه هستند. می‌توانید لیست سفارشی بسازید و از منوی هر دانلود به آن منتقل کنید.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            var newListName by remember { mutableStateOf("") }
            OutlinedTextField(
                value = newListName,
                onValueChange = { newListName = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("نام لیست جدید") }
            )
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = {
                    if (newListName.isNotBlank()) {
                        p.addCustomList(newListName)
                        newListName = ""
                        Toast.makeText(ctx, "لیست ساخته شد", Toast.LENGTH_SHORT).show()
                    }
                },
                shape = RoundedCornerShape(14.dp)
            ) { Text("ساخت لیست") }
            Spacer(Modifier.height(12.dp))
            p.customLists().forEach { list ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(list.title, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                    TextButton(onClick = { p.removeCustomList(list.id) }) {
                        Text("حذف", color = ColorBad)
                    }
                }
            }
            if (p.customLists().isEmpty()) {
                Text("هنوز لیست سفارشی ندارید.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
        }

        if (page == "path") Accordion("مسیر ذخیره", startOpen = true, showHeader = false) {
            Text(
                "فایل‌ها خودکار در Download/FastGet و زیرپوشه‌های Video / Audio / Documents / … ذخیره می‌شوند. انتخاب دستی پوشه حذف شده است.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )
        }

        if (page == "display") Accordion("نمایش", startOpen = true, showHeader = false) {
            Text("چینش فهرست دانلود", style = MaterialTheme.typography.bodyLarge)
            Text(
                "روی صفحه اصلی و فضای قفل‌شده اعمال می‌شود",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // خطی
                Surface(
                    onClick = { p.homeGridLayout = false },
                    shape = RoundedCornerShape(14.dp),
                    color = if (!p.homeGridLayout) cs.primary else cs.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        "خطی",
                        Modifier.padding(vertical = 12.dp).fillMaxWidth(),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        fontWeight = FontWeight.SemiBold,
                        color = if (!p.homeGridLayout) cs.onPrimary else cs.onSurface
                    )
                }
                // تایل
                Surface(
                    onClick = { p.homeGridLayout = true },
                    shape = RoundedCornerShape(14.dp),
                    color = if (p.homeGridLayout) cs.primary else cs.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        "تایل",
                        Modifier.padding(vertical = 12.dp).fillMaxWidth(),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        fontWeight = FontWeight.SemiBold,
                        color = if (p.homeGridLayout) cs.onPrimary else cs.onSurface
                    )
                }
            }
        }

        if (page == "theme") Accordion("تم رنگی", startOpen = true, showHeader = false) {
            Palettes.chunked(2).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { pal ->
                        ThemeCard(pal, selected = p.themeId == pal.id, modifier = Modifier.weight(1f)) {
                            p.setTheme(pal.id)
                        }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }

        if (page == "speed") Accordion("سرعت و اتصال", startOpen = true, showHeader = false) {
            Text("تعداد بخش‌های هر دانلود: ${fa(p.threads)}", style = MaterialTheme.typography.bodyLarge)
            Text(
                "فایل به همین تعداد تکه تقسیم و هم‌زمان دریافت می‌شود. روی دانلودهای جدید اعمال می‌شود.",
                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
            )
            Slider(
                value = p.threads.toFloat(),
                onValueChange = { p.threads = it.roundToInt() },
                valueRange = 1f..16f, steps = 14,
                colors = SliderDefaults.colors(thumbColor = cs.primary, activeTrackColor = cs.primary)
            )
            Spacer(Modifier.height(8.dp))
            Text("دانلود هم‌زمان: ${fa(p.maxParallel)}", style = MaterialTheme.typography.bodyLarge)
            Slider(
                value = p.maxParallel.toFloat(),
                onValueChange = { p.maxParallel = it.roundToInt() },
                valueRange = 1f..5f, steps = 3,
                colors = SliderDefaults.colors(thumbColor = cs.primary, activeTrackColor = cs.primary)
            )
            Spacer(Modifier.height(8.dp))
            Text("محدودیت سرعت هر دانلود", style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    0L to "نامحدود", 512L to "۵۱۲ کیلوبایت", 1024L to "۱ مگابایت",
                    2048L to "۲ مگابایت", 5120L to "۵ مگابایت"
                ).forEach { (kb, label) ->
                    FilterChip(
                        selected = p.speedLimitKb == kb,
                        onClick = { p.speedLimitKb = kb },
                        label = { Text(label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = cs.primary, selectedLabelColor = cs.onPrimary
                        )
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            SwitchRow("فقط با وای‌فای دانلود کن", p.wifiOnly) { p.wifiOnly = it }
        }

        if (page == "behavior") Accordion("رفتار برنامه", startOpen = true, showHeader = false) {
            SwitchRow("تشخیص لینک کپی‌شده", p.clipboardWatch) { p.clipboardWatch = it }
            SwitchRow("انتقال فایل کامل‌شده به پوشهٔ Download/FastGet", p.publishToDownloads) {
                p.publishToDownloads = it
            }
        }

        if (page == "security") Accordion("امنیت", startOpen = true, showHeader = false) {
            Text(
                "به‌طور پیش‌فرض قفلی فعال نیست. روش دلخواه را انتخاب کنید.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            Text("قفل ورود به برنامه", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
            LockModeRow("بدون رمز", p.appLockMode == "none") { p.appLockMode = "none" }
            LockModeRow("فقط رمز / قفل صفحه", p.appLockMode == "pin") {
                if (!Security.available(ctx)) {
                    Toast.makeText(ctx, "اول قفل صفحه یا اثرانگشت گوشی را فعال کنید", Toast.LENGTH_LONG).show()
                } else p.appLockMode = "pin"
            }
            LockModeRow("اثرانگشت با رمز پشتیبان", p.appLockMode == "bio") {
                if (!Security.available(ctx)) {
                    Toast.makeText(ctx, "اول قفل صفحه یا اثرانگشت گوشی را فعال کنید", Toast.LENGTH_LONG).show()
                } else p.appLockMode = "bio"
            }
            Spacer(Modifier.height(14.dp))
            Text("ورود به فضای قفل‌شده", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
            Text(
                "فایل‌های این بخش در گالری و Downloads دیده نمی‌شوند.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )
            LockModeRow("بدون رمز", p.vaultLockMode == "none") { p.vaultLockMode = "none" }
            LockModeRow("فقط رمز / قفل صفحه", p.vaultLockMode == "pin") {
                if (!Security.available(ctx)) {
                    Toast.makeText(ctx, "اول قفل صفحه یا اثرانگشت گوشی را فعال کنید", Toast.LENGTH_LONG).show()
                } else p.vaultLockMode = "pin"
            }
            LockModeRow("اثرانگشت با رمز پشتیبان", p.vaultLockMode == "bio") {
                if (!Security.available(ctx)) {
                    Toast.makeText(ctx, "اول قفل صفحه یا اثرانگشت گوشی را فعال کنید", Toast.LENGTH_LONG).show()
                } else p.vaultLockMode = "bio"
            }
            Spacer(Modifier.height(14.dp))
            SwitchRow("جلوگیری از اسکرین‌شات و پنهان در لیست اخیر", p.secureScreen) {
                p.secureScreen = it
            }
            SwitchRow("اجازهٔ لینک‌های http (بدون رمزنگاری)", p.allowHttp) { p.allowHttp = it }
        }

        if (page == "engine") Accordion("موتور ویدیو", startOpen = true, showHeader = false) {
            Text(
                when (engine) {
                    is EngineState.Ready -> "آماده"
                    is EngineState.Initializing -> "در حال آماده‌سازی…"
                    is EngineState.Failed -> "خطا: " + (engine as EngineState.Failed).message
                },
                style = MaterialTheme.typography.bodyLarge
            )
            Text(
                "بیش از ۱۰۰۰ سایت از جمله یوتیوب، اینستاگرام، ساندکلود و بسیاری از سایت‌های ویدیویی پشتیبانی می‌شود (yt-dlp). اگر دانلودی ناموفق شد موتور را به‌روزرسانی کنید. هر سه روز یک‌بار خودکار بررسی می‌شود.",
                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            Button(
                enabled = engine is EngineState.Ready,
                onClick = {
                    scope.launch {
                        val msg = try {
                            VideoEngine.update(ctx).also { p.markEngineUpdated() }
                        } catch (t: Throwable) {
                            VideoEngine.friendlyError(t)
                        }
                        Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
                    }
                }
            ) { Text("به‌روزرسانی موتور ویدیو") }
        }
    }
}

private fun toggleScheduleTarget(p: Prefs, id: String) {
    val set = p.scheduleTargetsSet().toMutableSet()
    set.remove("all")
    if (id in set) set.remove(id) else set.add(id)
    if (set.isEmpty()) set.add("main")
    p.scheduleTargetLists = set.joinToString(",")
}

@Composable
private fun ScheduleTargetChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label) },
        modifier = Modifier.padding(end = 6.dp, bottom = 6.dp),
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = cs.primary,
            selectedLabelColor = cs.onPrimary
        )
    )
}

@Composable
private fun LockModeRow(label: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            if (selected) Icons.Rounded.CheckCircle else Icons.Rounded.ExpandMore,
            contentDescription = null,
            tint = if (selected) cs.primary else cs.onSurfaceVariant,
            modifier = Modifier.size(22.dp)
        )
        Spacer(Modifier.size(10.dp))
        Text(
            label,
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            color = if (selected) cs.primary else cs.onSurface
        )
    }
}

@Composable
private fun SiteListEditor(label: String, value: String, onSave: (String) -> Unit) {
    var draft by remember(value) { mutableStateOf(value) }
    Text(label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    Spacer(Modifier.height(4.dp))
    OutlinedTextField(
        value = draft,
        onValueChange = { draft = it },
        modifier = Modifier.fillMaxWidth().height(96.dp),
        label = { Text("هر خط یک دامنه") }
    )
    Spacer(Modifier.height(4.dp))
    Button(onClick = { onSave(draft) }) {
        Text("ذخیره")
    }
}


@Composable
private fun SettingsMenuRow(title: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(cs.surface)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
        Icon(Icons.Rounded.ExpandMore, contentDescription = null, tint = cs.onSurfaceVariant)
    }
}

@Composable
private fun Section(title: String) {
    // kept for any leftover call sites; prefer Accordion
    Text(
        title,
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 18.dp, bottom = 10.dp)
    )
}

/** Collapsed-by-default settings group; tap header to expand. */
@Composable
private fun Accordion(
    title: String,
    startOpen: Boolean = false,
    showHeader: Boolean = true,
    content: @Composable () -> Unit
) {
    var open by remember(title) { mutableStateOf(startOpen) }
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(cs.surface)
    ) {
        if (showHeader) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { open = !open }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    title,
                    Modifier.weight(1f),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = cs.primary
                )
                Icon(
                    if (open) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                    contentDescription = null,
                    tint = cs.onSurfaceVariant
                )
            }
        } else {
            open = true
        }
        if (open) {
            Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 16.dp, top = if (showHeader) 0.dp else 16.dp)) {
                content()
            }
        }
    }
}

@Composable
private fun SettingBlock(content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(bottom = 10.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(16.dp)
    ) { content() }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().padding(bottom = 10.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(cs.surface)
            .clickable { onChange(!checked) }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = cs.primary, checkedThumbColor = cs.onPrimary)
        )
    }
}

@Composable
private fun ThemeCard(pal: AppPalette, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Box(
        modifier
            .height(96.dp)
            .clip(shape)
            .background(pal.bg)
            .border(
                BorderStroke(if (selected) 2.5.dp else 1.dp, if (selected) pal.primary else pal.textDim.copy(alpha = 0.35f)),
                shape
            )
            .clickable(onClick = onClick)
            .padding(12.dp)
    ) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(pal.primary, pal.secondary, pal.surfaceHigh).forEach {
                    Box(Modifier.size(18.dp).clip(CircleShape).background(it))
                }
            }
            Text(pal.name, color = pal.text, fontWeight = FontWeight.SemiBold)
        }
        if (selected) {
            Icon(
                Icons.Rounded.CheckCircle, null, tint = pal.primary,
                modifier = Modifier.align(Alignment.TopStart).size(22.dp)
            )
        }
    }
}

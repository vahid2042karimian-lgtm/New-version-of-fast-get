package com.fastget.app.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.ViewList
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.snapshotFlow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Surface
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.fastget.app.core.EngineState
import com.fastget.app.core.SearchItem
import com.fastget.app.core.Security
import com.fastget.app.core.VideoEngine
import com.fastget.app.core.fa
import com.fastget.app.core.formatBytes
import com.fastget.app.core.formatEta
import com.fastget.app.ui.theme.ColorBad

@Composable
fun VideoScreen(vm: MainViewModel) {
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val engine by VideoEngine.state.collectAsState()

    Column(
        Modifier
            .fillMaxSize()
            .background(cs.background)
            .statusBarsPadding()
            .padding(horizontal = 16.dp)
    ) {
        // سربرگ مینیمال — بدون میانبر مستقل مرورگر
        Row(
            Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { vm.screen = Screen.HOME }) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "بازگشت")
            }
            Column(Modifier.weight(1f)) {
                Text(
                    com.fastget.app.core.I18n.t("جستجو", "Search"),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    com.fastget.app.core.I18n.searchHint,
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        val types = buildList {
            add(com.fastget.app.core.MediaType.VIDEO)
            add(com.fastget.app.core.MediaType.AUDIO)
            add(com.fastget.app.core.MediaType.FILE)
            add(com.fastget.app.core.MediaType.TORRENT)
            add(com.fastget.app.core.MediaType.ALL)
            if (vm.prefs.extraSearchEnabled) add(com.fastget.app.core.MediaType.EXTRA)
        }
        var typeMenu by remember { mutableStateOf(false) }

        // کادر یکپارچه جستجو + نوع + دکمه
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = cs.surface,
            tonalElevation = 2.dp,
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 4.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                OutlinedTextField(
                    value = vm.vQuery,
                    onValueChange = { vm.vQuery = it },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    shape = RoundedCornerShape(18.dp),
                    placeholder = { Text(com.fastget.app.core.I18n.searchEllipsis) },
                    leadingIcon = {
                        Icon(Icons.Rounded.Search, null, tint = cs.onSurfaceVariant)
                    },
                    colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = cs.primary.copy(alpha = 0.45f),
                        unfocusedBorderColor = cs.outline.copy(alpha = 0.25f),
                        focusedContainerColor = cs.surface,
                        unfocusedContainerColor = cs.surface
                    ),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { vm.runSearch() })
                )
                Box {
                    FilterChip(
                        selected = true,
                        onClick = { typeMenu = true },
                        label = {
                            Text(
                                vm.vMediaType.label,
                                style = MaterialTheme.typography.labelLarge,
                                maxLines = 1
                            )
                        },
                        shape = RoundedCornerShape(14.dp),
                        colors = videoChipColors()
                    )
                    DropdownMenu(
                        expanded = typeMenu,
                        onDismissRequest = { typeMenu = false }
                    ) {
                        types.forEach { opt ->
                            DropdownMenuItem(
                                text = { Text(opt.label) },
                                onClick = {
                                    vm.vMediaType = opt
                                    vm.vMode = if (opt == com.fastget.app.core.MediaType.AUDIO) 0 else 1
                                    typeMenu = false
                                }
                            )
                        }
                    }
                }
                FilledIconButton(
                    onClick = { vm.runSearch() },
                    enabled = vm.vQuery.isNotBlank() && !vm.vLoading,
                    shape = RoundedCornerShape(16.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = cs.primary,
                        contentColor = cs.onPrimary,
                        disabledContainerColor = cs.surfaceVariant,
                        disabledContentColor = cs.onSurfaceVariant
                    )
                ) {
                    Icon(Icons.Rounded.Search, contentDescription = "جستجو")
                }
            }
        }
        // Layout toggle + selection bar
        if (vm.vResults.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "${vm.vResults.size} نتیجه" + if (vm.vSelected.isNotEmpty()) " · ${vm.vSelected.size} انتخاب" else "",
                    style = MaterialTheme.typography.labelMedium,
                    color = cs.onSurfaceVariant
                )
                Row {
                    if (vm.vSelected.isNotEmpty()) {
                        IconButton(onClick = {
                            vm.enqueueSelected()
                            Toast.makeText(ctx, com.fastget.app.core.I18n.t("به صف دانلود اضافه شد", "Added to download queue"), Toast.LENGTH_SHORT).show()
                        }) {
                            Icon(Icons.Rounded.Download, "دانلود انتخاب‌شده‌ها", tint = cs.primary)
                        }
                        TextButton(onClick = { vm.clearSelection() }) { Text(com.fastget.app.core.I18n.cancelShort) }
                    }
                    IconButton(onClick = { vm.vGridLayout = !vm.vGridLayout }) {
                        Icon(
                            if (vm.vGridLayout) Icons.Rounded.ViewList else Icons.Rounded.GridView,
                            contentDescription = "تغییر چینش"
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(6.dp))

        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                engine is EngineState.Initializing -> Hint(com.fastget.app.core.I18n.t("در حال آماده‌سازی موتور ویدیو…", "Preparing video engine…"))
                engine is EngineState.Failed -> Hint("موتور ویدیو بالا نیامد: ${(engine as EngineState.Failed).message}", ColorBad)
                vm.vLoading -> Column(
                    Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) { CircularProgressIndicator(color = cs.primary) }
                vm.vError != null && vm.vResults.isEmpty() -> Column(
                    Modifier.fillMaxSize().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(vm.vError!!, color = ColorBad, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(12.dp))
                    TextButton(onClick = { vm.runSearch() }) { Text(com.fastget.app.core.I18n.retry) }
                }
                vm.vResults.isEmpty() -> Hint(
                    "نام آهنگ، ویدیو یا شخص را بنویسید و نوع فایل را انتخاب کنید، یا لینک را بچسبانید."
                )
                vm.vGridLayout -> ResultsGrid(vm, ctx)
                else -> ResultsList(vm, ctx)
            }
        }
        Text(
            "فقط محتوایی را دانلود کنید که اجازهٔ استفاده‌اش را دارید.",
            style = MaterialTheme.typography.labelSmall,
            color = cs.onSurfaceVariant,
            modifier = Modifier.padding(vertical = 8.dp).navigationBarsPadding()
        )
    }

    vm.vSheetItem?.let { QualitySheet(vm, it) }

    if (!vm.prefs.videoTermsAccepted) {
        AlertDialog(
            onDismissRequest = { vm.screen = Screen.HOME },
            containerColor = cs.surface,
            title = { Text("قبل از شروع") },
            text = {
                Text(
                    "دانلود از بعضی سایت‌ها شرایط استفادهٔ آن‌ها را نقض می‌کند و دانلود محتوای دارای " +
                        "حق نشر بدون اجازه ممکن است غیرقانونی باشد. مسئولیت استفاده با خود شماست."
                )
            },
            confirmButton = { TextButton(onClick = { vm.prefs.acceptVideoTerms() }) { Text("متوجه شدم") } },
            dismissButton = { TextButton(onClick = { vm.screen = Screen.HOME }) { Text(com.fastget.app.core.I18n.back) } }
        )
    }
}

@Composable
private fun ResultsList(vm: MainViewModel, ctx: android.content.Context) {
    val listState = rememberLazyListState()
    LaunchedEffect(listState, vm.vResults.size) {
        snapshotFlow {
            val info = listState.layoutInfo
            val last = info.visibleItemsInfo.lastOrNull()?.index ?: 0
            last >= info.totalItemsCount - 3
        }.collect { nearEnd ->
            if (nearEnd) vm.loadMore()
        }
    }
    LazyColumn(
        state = listState,
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 24.dp)
    ) {
        items(vm.vResults, key = { it.url }) { item ->
            val selected = item.url in vm.vSelected
            ResultRow(
                item = item,
                selected = selected,
                onRowClick = {
                    if (vm.vSelected.isNotEmpty()) {
                        vm.toggleSelect(item)
                    } else if (item.sourceSite == "google" || item.sourceSite == "web") {
                        // نتایج گوگل → باز کردن در مرورگر داخلی برای یافتن لینک واقعی
                        vm.browserStartUrl = item.url
                        vm.screen = Screen.BROWSER
                    } else if (vm.vMode == 0 || item.mediaType == com.fastget.app.core.MediaType.AUDIO) {
                        val adult = item.mediaType == com.fastget.app.core.MediaType.EXTRA ||
                            vm.prefs.isAdultUrl(item.url)
                        if (adult && !vm.prefs.extraSearchEnabled) {
                            Toast.makeText(ctx, com.fastget.app.core.I18n.t("ابتدا محتوای محدود را فعال کنید", "Enable restricted content first"), Toast.LENGTH_SHORT).show()
                        } else {
                            vm.manager.enqueueVideo(item.url, item.title, item.thumbnail, "a:mp3", adult)
                            Toast.makeText(ctx, com.fastget.app.core.I18n.t("MP3 به صف اضافه شد", "MP3 queued"), Toast.LENGTH_SHORT).show()
                        }
                    } else if (item.mediaType == com.fastget.app.core.MediaType.TORRENT) {
                        vm.manager.enqueueTorrent(item.url, item.title, autoStart = false)
                        Toast.makeText(ctx, com.fastget.app.core.I18n.t("تورنت به صف اضافه شد", "Torrent queued"), Toast.LENGTH_SHORT).show()
                    } else {
                        vm.openQualitySheet(item)
                    }
                },
                onLongClick = { vm.toggleSelect(item) },
                onMp3 = {
                    val adult = item.mediaType == com.fastget.app.core.MediaType.EXTRA ||
                        vm.prefs.isAdultUrl(item.url)
                    if (adult && !vm.prefs.extraSearchEnabled) {
                        Toast.makeText(ctx, com.fastget.app.core.I18n.t("ابتدا محتوای محدود را فعال کنید", "Enable restricted content first"), Toast.LENGTH_SHORT).show()
                    } else {
                        vm.manager.enqueueVideo(item.url, item.title, item.thumbnail, "a:mp3", adult)
                        Toast.makeText(ctx, com.fastget.app.core.I18n.t("MP3 به صف اضافه شد", "MP3 queued"), Toast.LENGTH_SHORT).show()
                    }
                },
                onVideo = { vm.openQualitySheet(item) }
            )
        }
        if (vm.vLoadingMore) {
            item {
                Box(Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(Modifier.size(28.dp))
                }
            }
        } else if (vm.vHasMore) {
            item {
                TextButton(
                    onClick = { vm.loadMore() },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(com.fastget.app.core.I18n.moreResults) }
            }
        }
    }
}

@Composable
private fun ResultsGrid(vm: MainViewModel, ctx: android.content.Context) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(150.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 24.dp)
    ) {
        gridItems(vm.vResults, key = { it.url }) { item ->
            val selected = item.url in vm.vSelected
            ResultTile(
                item = item,
                selected = selected,
                onClick = {
                    if (vm.vSelected.isNotEmpty()) {
                        vm.toggleSelect(item)
                    } else if (item.sourceSite == "google" || item.sourceSite == "web") {
                        vm.browserStartUrl = item.url
                        vm.screen = Screen.BROWSER
                    } else if (item.mediaType == com.fastget.app.core.MediaType.AUDIO) {
                        val adult = item.mediaType == com.fastget.app.core.MediaType.EXTRA ||
                            vm.prefs.isAdultUrl(item.url)
                        if (adult && !vm.prefs.extraSearchEnabled) {
                            Toast.makeText(ctx, com.fastget.app.core.I18n.t("ابتدا محتوای محدود را فعال کنید", "Enable restricted content first"), Toast.LENGTH_SHORT).show()
                        } else {
                            vm.manager.enqueueVideo(item.url, item.title, item.thumbnail, "a:mp3", adult)
                            Toast.makeText(ctx, "MP3 اضافه شد", Toast.LENGTH_SHORT).show()
                        }
                    } else if (item.mediaType == com.fastget.app.core.MediaType.TORRENT) {
                        vm.manager.enqueueTorrent(item.url, item.title, autoStart = false)
                        Toast.makeText(ctx, "تورنت اضافه شد", Toast.LENGTH_SHORT).show()
                    } else {
                        vm.openQualitySheet(item)
                    }
                },
                onLongClick = { vm.toggleSelect(item) }
            )
        }
        if (vm.vHasMore) {
            item {
                TextButton(onClick = { vm.loadMore() }) { Text(com.fastget.app.core.I18n.loadMore) }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ResultTile(item: SearchItem, selected: Boolean, onClick: () -> Unit, onLongClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = cs.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (selected) Modifier.border(1.5.dp, cs.primary, RoundedCornerShape(18.dp))
                else Modifier.border(1.dp, cs.outline.copy(alpha = 0.12f), RoundedCornerShape(18.dp))
            )
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        Column {
            Box {
                AsyncImage(
                    model = item.thumbnail,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                        .clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp))
                        .background(cs.surfaceVariant)
                )
                if (selected) {
                    Icon(
                        Icons.Rounded.CheckCircle,
                        contentDescription = null,
                        tint = cs.primary,
                        modifier = Modifier.align(Alignment.TopEnd).padding(6.dp)
                    )
                }
            }
            Text(
                item.title,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
            )
            val kind = when (item.mediaType) {
                com.fastget.app.core.MediaType.AUDIO -> "صدا"
                com.fastget.app.core.MediaType.TORRENT -> "تورنت"
                com.fastget.app.core.MediaType.FILE -> "فایل"
                com.fastget.app.core.MediaType.EXTRA -> "+۱۸"
                else -> "ویدیو"
            }
            Text(
                kind,
                style = MaterialTheme.typography.labelSmall,
                color = cs.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}

@Composable
private fun videoChipColors() = FilterChipDefaults.filterChipColors(
    containerColor = MaterialTheme.colorScheme.surface,
    labelColor = MaterialTheme.colorScheme.onSurfaceVariant,
    selectedContainerColor = MaterialTheme.colorScheme.primary,
    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
)

@Composable
private fun Hint(text: String, color: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onSurfaceVariant) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Text(text, color = color, style = MaterialTheme.typography.bodyMedium)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ResultRow(
    item: SearchItem,
    selected: Boolean,
    onRowClick: () -> Unit,
    onLongClick: () -> Unit,
    onMp3: () -> Unit,
    onVideo: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = cs.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (selected) Modifier.border(1.5.dp, cs.primary, RoundedCornerShape(18.dp))
                else Modifier.border(1.dp, cs.outline.copy(alpha = 0.12f), RoundedCornerShape(18.dp))
            )
            .combinedClickable(onClick = onRowClick, onLongClick = onLongClick)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box {
                AsyncImage(
                    model = item.thumbnail,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(width = 108.dp, height = 62.dp)
                        .clip(RoundedCornerShape(12.dp)).background(cs.surfaceVariant)
                )
                if (selected) {
                    Icon(
                        Icons.Rounded.CheckCircle,
                        contentDescription = null,
                        tint = cs.primary,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    item.title, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold
                )
                val dur = if (item.durationSec > 0) fa(formatEta(item.durationSec)) else ""
                val kind = when (item.mediaType) {
                    com.fastget.app.core.MediaType.AUDIO -> "صدا"
                    com.fastget.app.core.MediaType.TORRENT -> "تورنت"
                    com.fastget.app.core.MediaType.FILE -> "فایل"
                    com.fastget.app.core.MediaType.EXTRA -> "+۱۸"
                    com.fastget.app.core.MediaType.VIDEO -> "ویدیو"
                    com.fastget.app.core.MediaType.ALL -> ""
                }
                val meta = listOf(kind, item.uploader, dur).filter { it.isNotBlank() }.joinToString("  ")
                Text(
                    meta,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant
                )
            }
            if (item.mediaType != com.fastget.app.core.MediaType.TORRENT && !selected) {
                IconButton(onClick = onMp3) { Icon(Icons.Rounded.MusicNote, "دانلود MP3", tint = cs.primary) }
                IconButton(onClick = onVideo) { Icon(Icons.Rounded.Movie, "دانلود ویدیو", tint = cs.secondary) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun QualitySheet(vm: MainViewModel, item: SearchItem) {
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val forceAdult = item.mediaType == com.fastget.app.core.MediaType.EXTRA ||
        vm.prefs.isAdultUrl(item.url)
    var priv by remember { mutableStateOf(forceAdult) }
    var targetListId by remember { mutableStateOf(if (forceAdult) "vault" else "main") }
    val canPrivate = remember { Security.available(ctx) }
    val heights = vm.vSheetMeta?.heights.orEmpty()
    val qualities = vm.vSheetMeta?.qualities.orEmpty()
    val listOptions = remember(vm.prefs.customListsRaw) {
        buildList {
            add("main" to "لیست اصلی")
            add("vault" to "فضای قفل‌شده")
            vm.prefs.customLists().forEach { add(it.id to it.title) }
        }
    }

    val options = buildList {
        add("موسیقی MP3 با بهترین کیفیت" to "a:mp3")
        add("موسیقی M4A با حجم کمتر" to "a:m4a")
        if (qualities.isNotEmpty()) {
            qualities.forEach { q ->
                val size = if (q.filesize > 0) " · ${formatBytes(q.filesize)}" else ""
                add("${q.labelFa}$size" to q.spec)
            }
        } else {
            listOf(1080, 720, 480, 360).forEach { h ->
                if (heights.isEmpty() || heights.any { it >= h }) add("ویدیو ${fa(h)}p" to "v:$h")
            }
            add("ویدیو با بهترین کیفیت موجود" to "v:best")
        }
    }

    fun close() { vm.vSheetItem = null; vm.vSheetMeta = null }

    ModalBottomSheet(onDismissRequest = { close() }, sheetState = sheet, containerColor = cs.surface) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 20.dp).navigationBarsPadding()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AsyncImage(
                    model = item.thumbnail, contentDescription = null, contentScale = ContentScale.Crop,
                    modifier = Modifier.size(width = 96.dp, height = 54.dp)
                        .clip(RoundedCornerShape(10.dp)).background(cs.surfaceVariant)
                )
                Spacer(Modifier.width(12.dp))
                Text(
                    item.title, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold
                )
            }
            if (forceAdult) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "محتوای محدود — فقط در فضای قفل‌شده ذخیره می‌شود.",
                    style = MaterialTheme.typography.bodySmall,
                    color = com.fastget.app.ui.theme.ColorWarn
                )
            } else {
                Spacer(Modifier.height(10.dp))
                Text(com.fastget.app.core.I18n.sendToList, style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOptions.forEach { (id, title) ->
                        FilterChip(
                            selected = targetListId == id,
                            onClick = { targetListId = id },
                            label = { Text(title) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = cs.primary,
                                selectedLabelColor = cs.onPrimary
                            )
                        )
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            options.forEach { (label, spec) ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                        .background(cs.surfaceVariant.copy(alpha = 0.6f))
                        .clickable {
                            if (forceAdult && !vm.prefs.extraSearchEnabled) {
                                Toast.makeText(
                                    ctx,
                                    "ابتدا محتوای محدود را در فضای قفل‌شده فعال کنید",
                                    Toast.LENGTH_SHORT
                                ).show()
                                return@clickable
                            }
                            val listId = if (forceAdult) "vault" else targetListId
                            val usePrivate = forceAdult || listId == "vault" || (priv && canPrivate)
                            vm.manager.enqueueVideo(
                                item.url, item.title, item.thumbnail, spec, usePrivate,
                                targetListId = listId
                            )
                            Toast.makeText(
                                ctx,
                                if (usePrivate) "به فضای قفل‌شده اضافه شد" else "به صف دانلود اضافه شد",
                                Toast.LENGTH_SHORT
                            ).show()
                            close()
                        }
                        .padding(horizontal = 14.dp, vertical = 13.dp)
                ) { Text(label, style = MaterialTheme.typography.bodyMedium) }
                Spacer(Modifier.height(8.dp))
            }
            if (!forceAdult) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("ذخیره در پوشهٔ خصوصی", style = MaterialTheme.typography.bodyMedium)
                        Text(
                            if (canPrivate) "فقط با اثرانگشت یا قفل صفحه دیده می‌شود و در گالری نمی‌آید."
                            else "برای استفاده، اول قفل صفحهٔ گوشی را فعال کنید.",
                            style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = priv && canPrivate, onCheckedChange = { priv = it }, enabled = canPrivate,
                        colors = SwitchDefaults.colors(checkedTrackColor = cs.primary, checkedThumbColor = cs.onPrimary)
                    )
                }
            }
        }
    }
}

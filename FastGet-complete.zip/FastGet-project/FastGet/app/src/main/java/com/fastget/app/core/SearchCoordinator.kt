package com.fastget.app.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Decides which engines to run based on MediaType + Settings site lists,
 * runs them in parallel, merges and de-duplicates results.
 */
object SearchCoordinator {

    /**
     * Main entry used by the UI.
     * @param query free text or a direct http(s) link
     * @param type VIDEO / AUDIO / TORRENT / ALL
     * @param prefs for site lists and google toggle
     * @param count soft limit per engine
     */
    suspend fun search(
        query: String,
        type: MediaType,
        prefs: Prefs,
        count: Int = 15
    ): List<SearchItem> = withContext(Dispatchers.IO) {
        val q = query.trim()
        if (q.isEmpty()) return@withContext emptyList()

        // Direct link → let yt-dlp inspect later in ViewModel; here only text search.
        if (q.startsWith("http://") || q.startsWith("https://") || q.startsWith("magnet:")) {
            return@withContext listOf(
                SearchItem(
                    id = "direct",
                    title = q.take(80),
                    url = q,
                    mediaType = when {
                        q.startsWith("magnet:") -> MediaType.TORRENT
                        else -> type.takeIf { it != MediaType.ALL } ?: MediaType.VIDEO
                    },
                    sourceSite = "link",
                    isDirect = true
                )
            )
        }

        coroutineScope {
            val jobs = mutableListOf<kotlinx.coroutines.Deferred<List<SearchItem>>>()

            val wantVideo = type == MediaType.VIDEO || type == MediaType.ALL
            val wantAudio = type == MediaType.AUDIO || type == MediaType.ALL
            val wantFile = type == MediaType.FILE || type == MediaType.ALL
            val wantTorrent = type == MediaType.TORRENT || type == MediaType.ALL
            val wantExtra = type == MediaType.EXTRA && prefs.extraSearchEnabled

            if (wantVideo) {
                // YouTube is primary — always run first path with full count
                jobs += async {
                    runCatching {
                        VideoEngine.search(q, SearchSource.YOUTUBE, count)
                    }.getOrElse { emptyList() }
                }
                val videoHosts = prefs.sitesFor(SiteCategory.VIDEO)
                    .filter { it != "youtube.com" && it != "youtu.be" }
                if (videoHosts.isNotEmpty()) {
                    jobs += async {
                        runCatching {
                            searchViaYtDlpSites(q, videoHosts, MediaType.VIDEO, (count / 2).coerceAtLeast(5))
                        }.getOrElse { emptyList() }
                    }
                }
            }

            if (wantAudio) {
                jobs += async {
                    runCatching {
                        VideoEngine.search(q, SearchSource.SOUNDCLOUD, count)
                    }.getOrElse { emptyList() }
                }
                val audioHosts = prefs.sitesFor(SiteCategory.AUDIO)
                    .filter { it != "soundcloud.com" }
                if (audioHosts.isNotEmpty()) {
                    jobs += async {
                        searchViaYtDlpSites(q, audioHosts, MediaType.AUDIO, count / 2)
                    }
                }
            }

            if (wantFile) {
                val fileHosts = prefs.sitesFor(SiteCategory.FILE)
                if (fileHosts.isNotEmpty()) {
                    jobs += async {
                        searchViaYtDlpSites(q, fileHosts, MediaType.FILE, count / 2)
                    }
                }
            }

            if (wantTorrent) {
                val torrentHosts = prefs.sitesFor(SiteCategory.TORRENT)
                if (torrentHosts.isNotEmpty()) {
                    jobs += async {
                        runCatching {
                            TorrentEngine.search(q, torrentHosts, count)
                        }.getOrElse { emptyList() }
                    }
                }
            }

            // Extra sites only when Vault toggle is on and user selected EXTRA
            if (wantExtra) {
                val extraHosts = prefs.sitesFor(SiteCategory.EXTRA)
                if (extraHosts.isNotEmpty()) {
                    jobs += async {
                        searchViaYtDlpSites(q, extraHosts, MediaType.EXTRA, count)
                    }
                }
            }

            if (prefs.googleSearchEnabled) {
                jobs += async {
                    runCatching {
                        GoogleEngine.search(q, type, count)
                    }.getOrElse { emptyList() }
                }
            }

            val results = jobs.map { job ->
                async {
                    withTimeoutOrNull(30_000L) { job.await() } ?: emptyList()
                }
            }.map { it.await() }
            val flat = results.flatten()
            // Prioritize primary engines (youtube / soundcloud) over generic web
            val primary = flat.filter { it.sourceSite in setOf("youtube", "soundcloud") }
            val secondary = flat.filter {
                it.sourceSite !in setOf("youtube", "soundcloud", "google", "bing", "ddg")
            }
            val web = flat.filter { it.sourceSite in setOf("google", "bing", "ddg") }
            // نتایج بیشتر برای پر کردن صفحه + دکمه «بیشتر»
            dedupe(primary + secondary + web).take((count * 3).coerceAtLeast(40))
        }
    }

    /**
     * Uses yt-dlp `site:query` style where the extractor supports it,
     * otherwise falls back to a simple "https://host/search?q=" page probe via Google-like filter.
     * Age-gate sites get a cookie hint in a later refinement; for now we still try yt-dlp.
     */
    private suspend fun searchViaYtDlpSites(
        query: String,
        hosts: List<String>,
        media: MediaType,
        count: Int
    ): List<SearchItem> = coroutineScope {
        val perHost = (count / hosts.size.coerceAtLeast(1)).coerceIn(5, 15)
        val jobs = hosts.take(5).map { host ->
            async {
                val searchUrl = buildSiteSearchUrl(host, query) ?: return@async emptyList()
                runCatching {
                    VideoEngine.searchByUrl(searchUrl, perHost).map {
                        it.copy(mediaType = media, sourceSite = host)
                    }
                }.getOrElse { emptyList() }
            }
        }
        jobs.flatMap { it.await() }.take(count)
    }

    private fun buildSiteSearchUrl(host: String, query: String): String? {
        val h = host.lowercase().removePrefix("www.")
        val q = java.net.URLEncoder.encode(query, "UTF-8")
        return when {
            h.contains("pornhub") -> "https://www.pornhub.com/video/search?search=$q"
            h.contains("xvideos") -> "https://www.xvideos.com/?k=$q"
            h.contains("xhamster") -> "https://xhamster.com/search/$q"
            h.contains("xnxx") -> "https://www.xnxx.com/search/$q"
            h.contains("aparat") -> "https://www.aparat.com/search/$q"
            h.contains("vimeo") -> "https://vimeo.com/search?q=$q"
            h.contains("dailymotion") -> "https://www.dailymotion.com/search/$q"
            h.contains("bilibili") -> "https://search.bilibili.com/all?keyword=$q"
            h.contains("soundcloud") -> null
            h.contains("youtube") || h == "youtu.be" -> null
            h.contains("1337x") -> "https://www.1337x.to/search/$q/1/"
            h.contains("nyaa") -> "https://nyaa.si/?f=0&c=0_0&q=$q"
            else -> "https://$h/search?q=$q"
        }
    }

    private fun dedupe(items: List<SearchItem>): List<SearchItem> {
        val seen = linkedSetOf<String>()
        return items.filter { item ->
            val key = item.url.substringBefore('?').lowercase()
            if (key in seen) false else {
                seen.add(key)
                true
            }
        }
    }
}

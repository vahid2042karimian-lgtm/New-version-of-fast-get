package com.fastget.app.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

/**
 * Searches torrent indexers listed in Settings (sites_torrent).
 * Best-effort HTML scrape; prefers magnet links, then detail pages.
 */
object TorrentEngine {

    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private val magnetPattern = Pattern.compile(
        """(magnet:\?xt=urn:btih:[a-zA-Z0-9]+)[^"'\s<]*""",
        Pattern.CASE_INSENSITIVE
    )

    suspend fun search(query: String, hosts: List<String>, count: Int = 20): List<SearchItem> =
        withContext(Dispatchers.IO) {
            val q = query.trim().take(80)
            if (q.isEmpty() || hosts.isEmpty()) return@withContext emptyList()

            coroutineScope {
                hosts.take(5).map { host ->
                    async { searchOneHost(host, q, count) }
                }.awaitAll().flatten()
                    .distinctBy { it.url.lowercase() }
                    .take(count)
            }
        }

    private fun searchOneHost(host: String, query: String, limit: Int): List<SearchItem> {
        val h = host.lowercase().removePrefix("www.")
        val encoded = URLEncoder.encode(query, "UTF-8")
        val candidates = when {
            h.contains("1337x") -> listOf(
                "https://www.1337x.to/search/$encoded/1/",
                "https://1337x.to/search/$encoded/1/",
                "https://www.$h/search/$encoded/1/"
            )
            h.contains("nyaa") -> listOf(
                "https://nyaa.si/?f=0&c=0_0&q=$encoded",
                "https://$h/?q=$encoded"
            )
            h.contains("yts") || h.contains("yify") -> listOf(
                "https://yts.mx/browse-movies/$encoded/all/all/0/latest/0/all",
                "https://$h/browse-movies/$encoded"
            )
            h.contains("torrentgalaxy") -> listOf(
                "https://torrentgalaxy.to/torrents.php?search=$encoded"
            )
            h.contains("thepiratebay") || h.contains("tpb") -> listOf(
                "https://thepiratebay.org/search.php?q=$encoded"
            )
            else -> listOf(
                "https://$h/search/$encoded/1/",
                "https://$h/search?q=$encoded",
                "https://$h/?q=$encoded"
            )
        }
        for (url in candidates) {
            val html = fetch(url) ?: continue
            val items = parsePage(html, h, limit)
            if (items.isNotEmpty()) return items
        }
        return emptyList()
    }

    private fun fetch(url: String): String? {
        return try {
            val req = Request.Builder()
                .url(url)
                .header(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                )
                .header("Accept", "text/html,application/xhtml+xml")
                .get()
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return null
                resp.body?.string()
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun parsePage(html: String, host: String, limit: Int): List<SearchItem> {
        val out = mutableListOf<SearchItem>()
        val seen = mutableSetOf<String>()

        // 1) Magnets
        val mm = magnetPattern.matcher(html)
        var i = 0
        while (mm.find() && out.size < limit) {
            val magnet = mm.group(1) ?: continue
            if (!seen.add(magnet.lowercase())) continue
            val title = extractNearbyTitle(html, mm.start()) ?: "Torrent · $host #${++i}"
            out.add(
                SearchItem(
                    id = "mag-${magnet.hashCode()}",
                    title = title,
                    url = magnet,
                    uploader = host,
                    mediaType = MediaType.TORRENT,
                    sourceSite = host,
                    isDirect = true
                )
            )
        }

        // 2) 1337x style: /torrent/ID/Name/
        val re1337 = Pattern.compile(
            """href=["'](/torrent/\d+/[^"']+)["'][^>]*>([^<]{3,120})""",
            Pattern.CASE_INSENSITIVE
        )
        val m1337 = re1337.matcher(html)
        while (m1337.find() && out.size < limit) {
            var path = m1337.group(1) ?: continue
            val title = cleanTitle(m1337.group(2) ?: "")
            if (title.isBlank()) continue
            if (path.startsWith("/")) path = "https://www.$host$path"
            if (!seen.add(path.lowercase())) continue
            out.add(
                SearchItem(
                    id = "t1337-${path.hashCode()}",
                    title = title,
                    url = path,
                    uploader = host,
                    mediaType = MediaType.TORRENT,
                    sourceSite = host,
                    isDirect = false
                )
            )
        }

        // 3) Nyaa style: /view/12345
        val reNyaa = Pattern.compile(
            """href=["'](/view/\d+)["'][^>]*>([^<]{3,120})""",
            Pattern.CASE_INSENSITIVE
        )
        val mNyaa = reNyaa.matcher(html)
        while (mNyaa.find() && out.size < limit) {
            var path = mNyaa.group(1) ?: continue
            val title = cleanTitle(mNyaa.group(2) ?: "")
            if (title.isBlank()) continue
            if (path.startsWith("/")) path = "https://$host$path"
            if (!seen.add(path.lowercase())) continue
            out.add(
                SearchItem(
                    id = "nyaa-${path.hashCode()}",
                    title = title,
                    url = path,
                    uploader = host,
                    mediaType = MediaType.TORRENT,
                    sourceSite = host,
                    isDirect = false
                )
            )
        }

        // 4) Generic torrent detail links with sensible path
        if (out.size < 5) {
            val hrefRe = Pattern.compile("""href=["']([^"']+)["']""", Pattern.CASE_INSENSITIVE)
            val hm = hrefRe.matcher(html)
            while (hm.find() && out.size < limit) {
                var href = hm.group(1) ?: continue
                if (href.startsWith("/")) href = "https://$host$href"
                if (!href.startsWith("http")) continue
                val lower = href.lowercase()
                if (isSearchLike(lower)) continue
                if (!(lower.contains("/torrent") || lower.contains("/view/") ||
                        lower.contains("download") && lower.contains("id="))
                ) continue
                if (!seen.add(href.lowercase())) continue
                val title = href.substringAfterLast('/').substringBefore('?')
                    .replace('-', ' ').replace('_', ' ').take(80)
                    .ifBlank { host }
                out.add(
                    SearchItem(
                        id = "tp-${href.hashCode()}",
                        title = title,
                        url = href,
                        uploader = host,
                        mediaType = MediaType.TORRENT,
                        sourceSite = host,
                        isDirect = false
                    )
                )
            }
        }

        return out
    }

    /**
     * Resolve a torrent detail page to a magnet (or .torrent URL) for real download.
     */
    suspend fun resolveMagnet(detailUrl: String): String? = withContext(Dispatchers.IO) {
        if (detailUrl.startsWith("magnet:", ignoreCase = true)) return@withContext detailUrl
        if (detailUrl.endsWith(".torrent", ignoreCase = true)) return@withContext detailUrl
        val html = fetch(detailUrl) ?: return@withContext null
        val mm = magnetPattern.matcher(html)
        if (mm.find()) return@withContext mm.group(1)
        // common magnet href
        val hrefMagnet = Pattern.compile(
            """href=["'](magnet:\?[^"']+)["']""",
            Pattern.CASE_INSENSITIVE
        ).matcher(html)
        if (hrefMagnet.find()) return@withContext hrefMagnet.group(1)
        null
    }

    private fun isSearchLike(low: String): Boolean =
        low.contains("/search") || low.contains("?q=") || low.contains("/category") ||
            low.contains("login") || low.contains("register")

    private fun cleanTitle(raw: String): String =
        raw.replace(Regex("""\s+"""), " ").trim()
            .replace("&amp;", "&").replace("&#39;", "'")
            .take(120)

    private fun extractNearbyTitle(html: String, at: Int): String? {
        val from = (at - 400).coerceAtLeast(0)
        val window = html.substring(from, at)
        val m = Pattern.compile(
            """>([^<]{8,100})</a>\s*$""",
            Pattern.CASE_INSENSITIVE
        ).matcher(window)
        var last: String? = null
        while (m.find()) last = cleanTitle(m.group(1) ?: "")
        return last?.takeIf { it.length >= 5 }
    }
}

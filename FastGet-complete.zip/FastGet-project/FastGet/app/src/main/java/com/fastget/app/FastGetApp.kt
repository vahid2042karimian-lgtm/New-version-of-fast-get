package com.fastget.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import com.fastget.app.core.DownloadManager
import com.fastget.app.core.Prefs
import com.fastget.app.core.VideoEngine
import com.fastget.app.data.AppDatabase

class FastGetApp : Application() {

    lateinit var prefs: Prefs
        private set
    lateinit var db: AppDatabase
        private set
    lateinit var manager: DownloadManager
        private set

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        // اعمال زبان ذخیره‌شده از همان شروع برنامه
        com.fastget.app.core.I18n.set(prefs.language.ifBlank { "fa" })
        db = AppDatabase.get(this)
        manager = DownloadManager(this, db.dao(), prefs)
        createChannels()
        VideoEngine.initAsync(this, prefs)
        // Torrent session on background thread (native libtorrent)
        Thread {
            try {
                com.fastget.app.core.TorrentDownloader.ensureStarted(this@FastGetApp)
            } catch (_: Throwable) {
                // Unsupported ABI or missing native lib — HTTP/video still work
            }
        }.start()
    }

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_DOWNLOADS,
                getString(R.string.channel_downloads),
                NotificationManager.IMPORTANCE_LOW
            )
        )
        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_DONE,
                getString(R.string.channel_done),
                NotificationManager.IMPORTANCE_DEFAULT
            )
        )
    }

    companion object {
        const val CHANNEL_DOWNLOADS = "downloads"
        const val CHANNEL_DONE = "done"
    }
}

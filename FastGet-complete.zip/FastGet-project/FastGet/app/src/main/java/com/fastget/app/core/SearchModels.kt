package com.fastget.app.core

/**
 * Shared models for the multi-engine search system.
 */

/** Type selector next to the search box. EXTRA only appears when enabled from Vault. */
enum class MediaType(val labelFa: String, val labelEn: String) {
    VIDEO("ویدیو", "Video"),
    AUDIO("صدا", "Audio"),
    FILE("فایل", "File"),
    TORRENT("تورنت", "Torrent"),
    ALL("همه", "All"),
    /** Only shown in search UI when prefs.extraSearchEnabled (configured inside Vault). */
    EXTRA("+۱۸", "+18");

    /** برچسب مطابق زبان فعلی برنامه */
    val label: String
        get() = if (I18n.lang == "en") labelEn else labelFa
}

/** Category of a site list. */
enum class SiteCategory(val key: String, val labelFa: String) {
    VIDEO("video", "ویدیو"),
    AUDIO("audio", "صدا"),
    FILE("file", "فایل"),
    TORRENT("torrent", "تورنت"),
    /** Private list — edited only inside Vault; never labeled in Settings. */
    EXTRA("extra", "+۱۸")
}

data class SiteEntry(
    val host: String,
    val category: SiteCategory,
    val needsAgeGate: Boolean = false,
    val searchPath: String = ""
)

data class SearchItem(
    val id: String,
    val title: String,
    val url: String,
    val uploader: String = "",
    val durationSec: Long = 0L,
    val thumbnail: String? = null,
    val mediaType: MediaType = MediaType.VIDEO,
    val sourceSite: String = "",
    val sizeBytes: Long = 0L,
    val seeds: Int = 0,
    val quality: String = "",
    val isDirect: Boolean = false
)

/**
 * One selectable download quality extracted from yt-dlp formats.
 * [height] 0 means audio-only or unknown.
 */
data class QualityOption(
    val height: Int,
    val formatId: String = "",
    val ext: String = "mp4",
    /** Approximate total size in bytes; -1 if unknown. */
    val filesize: Long = -1L,
    val fps: Int = 0,
    val vcodec: String = "",
    val acodec: String = "",
    val note: String = ""
) {
    /** Spec passed to VideoEngine.download / enqueueVideo. */
    val spec: String
        get() = if (height > 0) "v:$height" else "v:best"

    val labelFa: String
        get() = when {
            height >= 2160 -> "4K · ${height}p"
            height >= 1440 -> "2K · ${height}p"
            height >= 1080 -> "Full HD · ${height}p"
            height >= 720 -> "HD · ${height}p"
            height > 0 -> "${height}p"
            else -> I18n.t("بهترین کیفیت", "Best quality")
        }
}

data class VideoMeta(
    val title: String,
    val uploader: String,
    val durationSec: Long,
    val thumbnail: String?,
    /** Distinct heights descending — kept for existing UI (VideoScreen). */
    val heights: List<Int>,
    val site: String,
    /** Rich quality list for Add Link sheet (Stage 4+). */
    val qualities: List<QualityOption> = emptyList()
)

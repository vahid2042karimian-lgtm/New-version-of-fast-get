package com.fastget.app.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

data class RectFrac(
    val left: Float,
    val top: Float,
    val width: Float,
    val height: Float
)

/**
 * @param screen صفحه‌ای که قبل از نمایش این مرحله باید باز شود (null = همان صفحه)
 */
data class TutorialStep(
    val title: String,
    val body: String,
    val hole: RectFrac,
    val cardBelow: Boolean = true,
    val screen: Screen? = Screen.HOME
)

/** راهنمای کامل: خانه، لیست‌ها، جستجو، مرورگر، افزودن لینک، فضای قفل‌شده */
val AppTutorialSteps: List<TutorialStep> = listOf(
    TutorialStep(
        title = "خوش آمدید",
        body = "این راهنما بخش‌های مهم را نشان می‌دهد. می‌توانید رد کنید؛ بعداً از تنظیمات → راهنمای برنامه دوباره ببینید.",
        hole = RectFrac(0.12f, 0.30f, 0.76f, 0.16f),
        cardBelow = true,
        screen = Screen.HOME
    ),
    TutorialStep(
        title = "جستجوی سریع",
        body = "از این نوار وارد صفحهٔ جستجو شوید: ویدیو، موسیقی، تورنت و نتایج وب.",
        hole = RectFrac(0.04f, 0.13f, 0.92f, 0.11f),
        cardBelow = true,
        screen = Screen.HOME
    ),
    TutorialStep(
        title = "لیست‌های دانلود",
        body = "این ردیف معمولاً جمع است. باز کنید تا لیست اصلی، لیست‌های خودتان و «جدید» را ببینید. دانلودها را می‌توانید بین لیست‌ها جابه‌جا کنید.",
        hole = RectFrac(0.04f, 0.23f, 0.92f, 0.09f),
        cardBelow = true,
        screen = Screen.HOME
    ),
    TutorialStep(
        title = "فیلتر فهرست",
        body = "آیکن اسلایدر بالا سمت راست: فیلتر دسته (ویدیو، موسیقی…)، وضعیت (در حال دانلود، تمام‌شده…) و مرتب‌سازی.",
        hole = RectFrac(0.78f, 0.015f, 0.18f, 0.075f),
        cardBelow = true,
        screen = Screen.HOME
    ),
    TutorialStep(
        title = "افزودن لینک",
        body = "دکمه ＋ : لینک را بچسبانید. نوع فایل خودکار تشخیص داده می‌شود؛ کیفیت، حجم و لیست مقصد را انتخاب کنید.",
        hole = RectFrac(0.70f, 0.80f, 0.26f, 0.13f),
        cardBelow = false,
        screen = Screen.HOME
    ),
    TutorialStep(
        title = "فضای قفل‌شده",
        body = "آیکن قفل: فایل‌های خصوصی اینجایند و در گالری دیده نمی‌شوند. قفل و زمان‌بندی جدا در تنظیمات امنیتی است.",
        hole = RectFrac(0.05f, 0.015f, 0.28f, 0.075f),
        cardBelow = true,
        screen = Screen.HOME
    ),
    TutorialStep(
        title = "صفحهٔ جستجو",
        body = "اینجا عبارت را بنویسید. نوع (ویدیو / صوتی / تورنت / …) را انتخاب کنید تا فقط همان منابع گشته شوند.",
        hole = RectFrac(0.04f, 0.06f, 0.92f, 0.14f),
        cardBelow = true,
        screen = Screen.VIDEO
    ),
    TutorialStep(
        title = "نتایج و کیفیت",
        body = "روی نتیجه بزنید تا کیفیت و لیست مقصد را ببینید. نتایج وب ممکن است در مرورگر داخلی باز شوند تا لینک واقعی را پیدا کنید.",
        hole = RectFrac(0.06f, 0.28f, 0.88f, 0.36f),
        cardBelow = false,
        screen = Screen.VIDEO
    ),
    TutorialStep(
        title = "مرورگر داخلی",
        body = "سایت را باز کنید، لینک‌ها را استخراج کنید یا صفحه را برای دانلود بفرستید. میانبرها از تنظیمات قابل تنظیم‌اند.",
        hole = RectFrac(0.04f, 0.08f, 0.92f, 0.12f),
        cardBelow = true,
        screen = Screen.BROWSER
    ),
    TutorialStep(
        title = "استخراج از صفحه",
        body = "در مرورگر می‌توانید لینک‌های رسانهٔ صفحه را بگیرید و به صف دانلود یا لیست دلخواه بفرستید.",
        hole = RectFrac(0.08f, 0.35f, 0.84f, 0.28f),
        cardBelow = false,
        screen = Screen.BROWSER
    ),
    TutorialStep(
        title = "کارت دانلود",
        body = "برگشت به فهرست اصلی: توقف، ادامه، رفرش لینک، انتقال به لیست دیگر و حذف از منوی ⋮ هر کارت.",
        hole = RectFrac(0.05f, 0.40f, 0.90f, 0.30f),
        cardBelow = false,
        screen = Screen.HOME
    ),
    TutorialStep(
        title = "تمام",
        body = "آماده‌اید. برای دیدن دوبارهٔ راهنما: تنظیمات → راهنمای برنامه.",
        hole = RectFrac(0.15f, 0.32f, 0.70f, 0.18f),
        cardBelow = true,
        screen = Screen.HOME
    )
)

/** سازگاری با نام قبلی */
val HomeTutorialSteps get() = AppTutorialSteps

@Composable
fun TutorialOverlay(
    stepIndex: Int,
    steps: List<TutorialStep> = AppTutorialSteps,
    onNext: () -> Unit,
    onSkip: () -> Unit
) {
    if (stepIndex !in steps.indices) return
    val step = steps[stepIndex]
    val cs = MaterialTheme.colorScheme
    val scrim = Color.Black.copy(alpha = 0.74f)

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) { }
    ) {
        val w = constraints.maxWidth.toFloat()
        val h = constraints.maxHeight.toFloat()
        val hole = Rect(
            offset = Offset(step.hole.left * w, step.hole.top * h),
            size = Size(step.hole.width * w, step.hole.height * h)
        )

        Canvas(Modifier.fillMaxSize()) {
            val holePath = Path().apply {
                addRoundRect(
                    RoundRect(
                        hole.left - 6f,
                        hole.top - 6f,
                        hole.right + 6f,
                        hole.bottom + 6f,
                        CornerRadius(28f, 28f)
                    )
                )
            }
            clipPath(holePath, clipOp = ClipOp.Difference) {
                drawRect(scrim)
            }
            drawRoundRect(
                color = Color.White.copy(alpha = 0.4f),
                topLeft = Offset(hole.left - 6f, hole.top - 6f),
                size = Size(hole.width + 12f, hole.height + 12f),
                cornerRadius = CornerRadius(28f, 28f),
                style = Stroke(width = 2.5f)
            )
        }

        val cardAlign = if (step.cardBelow) Alignment.BottomCenter else Alignment.TopCenter
        val cardPad =
            if (step.cardBelow) Modifier.padding(bottom = 32.dp)
            else Modifier.padding(top = 64.dp)

        Box(Modifier.fillMaxSize().then(cardPad), contentAlignment = cardAlign) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp),
                shape = RoundedCornerShape(22.dp),
                color = cs.surface,
                tonalElevation = 6.dp,
                shadowElevation = 10.dp
            ) {
                Column(Modifier.padding(18.dp)) {
                    Text(
                        "${stepIndex + 1} / ${steps.size}",
                        style = MaterialTheme.typography.labelMedium,
                        color = cs.primary
                    )
                    Spacer(Modifier.height(6.dp))
                    AnimatedContent(
                        targetState = stepIndex,
                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                        label = "tut"
                    ) { idx ->
                        Column {
                            Text(
                                steps[idx].title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                steps[idx].body,
                                style = MaterialTheme.typography.bodyMedium,
                                color = cs.onSurfaceVariant
                            )
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = onSkip) { Text(com.fastget.app.core.I18n.skip) }
                        Spacer(Modifier.weight(1f))
                        Button(
                            onClick = onNext,
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = cs.primary,
                                contentColor = cs.onPrimary
                            )
                        ) {
                            Text(if (stepIndex >= steps.lastIndex) com.fastget.app.core.I18n.done else com.fastget.app.core.I18n.next)
                        }
                    }
                }
            }
        }
    }
}

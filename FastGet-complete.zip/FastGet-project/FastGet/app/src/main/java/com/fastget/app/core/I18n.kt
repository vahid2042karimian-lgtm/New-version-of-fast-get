package com.fastget.app.core

/**
 * Simple runtime strings for FA / EN without rewriting every composable to stringResource.
 * Call [I18n.set] when language changes; [t] returns the active language text.
 */
object I18n {
    @Volatile
    var lang: String = "fa"
        private set

    fun set(language: String) {
        lang = if (language == "en") "en" else "fa"
    }

    fun t(fa: String, en: String): String = if (lang == "en") en else fa

    // ---- common UI ----
    val appName get() = t("فست‌گت", "FastGet")
    val settings get() = t("تنظیمات", "Settings")
    val back get() = t("بازگشت", "Back")
    val addLink get() = t("افزودن لینک", "Add link")
    val browser get() = t("مرورگر", "Browser")
    val vault get() = t("پوشهٔ خصوصی", "Private vault")
    val more get() = t("بیشتر", "More")
    val pauseAll get() = t("توقف همه", "Pause all")
    val resumeAll get() = t("ادامهٔ همه", "Resume all")
    val copyLink get() = t("کپی لینک", "Copy link")
    val editLink get() = t("ویرایش لینک", "Edit link")
    val restart get() = t("شروع مجدد از صفر", "Restart from scratch")
    val delete get() = t("حذف", "Delete")
    val save get() = t("ذخیره", "Save")
    val cancel get() = t("انصراف", "Cancel")
    val priorityUp get() = t("اولویت بالاتر", "Higher priority")
    val priorityDown get() = t("اولویت پایین‌تر", "Lower priority")
    val pause get() = t("توقف", "Pause")
    val resume get() = t("ادامه", "Resume")
    val retry get() = t("تلاش دوباره", "Retry")
    val open get() = t("باز کردن", "Open")
    val linkCopied get() = t("لینک کپی شد", "Link copied")
    val linkUpdated get() = t("لینک به‌روز شد", "Link updated")
    val newLink get() = t("لینک جدید", "New link")
    val deleteDownload get() = t("حذف دانلود", "Delete download")
    val deleteWithFile get() = t("حذف همراه فایل", "Delete with file")
    val deleteFromList get() = t("فقط از فهرست", "Remove from list only")
    val searchMusicVideo get() = t("جستجوی موسیقی و ویدیو", "Search music & video")
    val searchHint get() = t(
        "اسم خواننده یا آهنگ را بنویسید یا لینک یوتیوب و سایت‌های ویدیویی را بچسبانید",
        "Enter artist/song name or paste a video link"
    )
    val tabAll get() = t("همه", "All")
    val tabActive get() = t("در حال انجام", "Active")
    val tabDone get() = t("تمام‌شده", "Completed")
    val tabFailed get() = t("ناموفق", "Failed")
    val allCategories get() = t("همهٔ دسته‌ها", "All categories")
    val downloadingN get() = t("در حال دانلود", "downloading")
    val queuedN get() = t("در صف", "queued")
    val videoMusic get() = t("ویدیو و موسیقی", "Video & music")
    val music get() = t("موسیقی", "Music")
    val video get() = t("ویدیو", "Video")
    val language get() = t("زبان / Language", "Language")
    val customSites get() = t("سایت‌های دستی", "Custom sites")
    val schedule get() = t("زمان‌بندی دانلود", "Download schedule")
    val savePath get() = t("مسیر ذخیره", "Save location")
    val theme get() = t("تم رنگی", "Color theme")
    val speedConn get() = t("سرعت و اتصال", "Speed & connection")
    val behavior get() = t("رفتار برنامه", "App behavior")
    val security get() = t("امنیت و حریم خصوصی", "Security & privacy")
    val videoEngine get() = t("موتور ویدیو", "Video engine")
    val pickFolder get() = t("انتخاب پوشه", "Pick folder")
    val savePathBtn get() = t("ذخیره مسیر", "Save path")
    val reset get() = t("بازنشانی", "Reset")
    val folderPicked get() = t("پوشه انتخاب شد", "Folder selected")
    val refresh get() = t("تازه‌سازی", "Refresh")
    val addToDownload get() = t("افزودن به دانلود", "Add to download")
    val extractLinks get() = t("استخراج لینک‌ها", "Extract links")
    val noLinksFound get() = t("لینکی پیدا نشد", "No links found")
    val linksFound get() = t("لینک پیدا شد", "links found")
    val addSelected get() = t("افزودن انتخاب‌شده‌ها", "Add selected")
    val selectAll get() = t("انتخاب همه", "Select all")

    // ---- home / lists ----
    val lists get() = t("لیست‌ها", "Lists")
    val listMain get() = t("اصلی", "Main")
    val listAll get() = t("همه", "All")
    val listNew get() = t("جدید", "New")
    val listLocked get() = t("فضای قفل‌شده", "Locked space")
    val filter get() = t("فیلتر", "Filter")
    val apply get() = t("اعمال", "Apply")
    val clearFilters get() = t("پاک کردن فیلتر", "Clear filters")
    val nothingToShow get() = t("موردی برای نمایش وجود ندارد", "Nothing to show")
    val refreshLinkContinue get() = t("رفرش لینک و ادامه", "Refresh link & continue")
    val moveToLocked get() = t("انتقال به فضای قفل‌شده", "Move to locked space")
    val moveToMain get() = t("انتقال به لیست اصلی", "Move to main list")
    val guide get() = t("راهنمای برنامه", "App guide")
    val next get() = t("بعدی", "Next")
    val skip get() = t("رد کردن", "Skip")
    val done get() = t("تمام", "Done")
    val later get() = t("بعداً", "Later")

    // ---- settings menu ----
    val searchSites get() = t("سایت‌های جستجو", "Search sites")
    val browserShortcuts get() = t("میانبر مرورگر", "Browser shortcuts")
    val downloadLists get() = t("لیست‌های دانلود", "Download lists")
    val display get() = t("نمایش", "Display")
    val securityShort get() = t("امنیت", "Security")
    val searchEllipsis get() = t("جستجو…", "Search…")
    val loadMore get() = t("بیشتر", "More")
    val moreResults get() = t("نتایج بیشتر", "More results")
    val sendToList get() = t("ارسال به لیست", "Send to list")
    val createList get() = t("ساخت", "Create")
    val nameLabel get() = t("نام", "Name")
    val cancelShort get() = t("لغو", "Cancel")
    val selectedN get() = t("انتخاب", "selected")
}


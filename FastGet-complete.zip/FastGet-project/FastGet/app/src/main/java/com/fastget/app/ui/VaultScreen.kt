package com.fastget.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fastget.app.core.Security
import com.fastget.app.data.DownloadEntity
import com.fastget.app.ui.theme.ColorBad
import com.fastget.app.ui.theme.ColorWarn

/** Private downloads: shown only after the phone's biometric / screen-lock check. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VaultScreen(vm: MainViewModel, auth: AuthFn) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val items by vm.downloads.collectAsStateWithLifecycle()
    val live by vm.live.collectAsStateWithLifecycle()
    val supported = remember { Security.available(ctx) }
    var confirm by remember { mutableStateOf<DownloadEntity?>(null) }

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.screen = Screen.HOME }) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "بازگشت")
            }
            Text("پوشهٔ خصوصی", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }

        val needAuth = vm.prefs.vaultLockMode != "none"
        if (needAuth && !supported) {
            Gate("برای قفل این بخش، اول در تنظیمات گوشی قفل صفحه یا اثرانگشت فعال کنید.", null)
            return@Column
        }
        if (needAuth && !vm.vaultUnlocked) {
            LaunchedEffect(Unit) { auth("باز کردن فضای قفل‌شده") { vm.vaultUnlocked = true } }
            Gate("فضای قفل‌شده است.", "باز کردن") {
                auth("باز کردن فضای قفل‌شده") { vm.vaultUnlocked = true }
            }
            return@Column
        }
        if (!needAuth && !vm.vaultUnlocked) {
            LaunchedEffect(Unit) { vm.vaultUnlocked = true }
        }

        val p = vm.prefs
        val domains = remember(p.sitesExtra) {
            p.sitesExtra.lines()
                .map { normalizeDomain(it) }
                .filter { it.isNotEmpty() }
                .distinct()
        }
        var newDomain by remember { mutableStateOf("") }
        var domainError by remember { mutableStateOf<String?>(null) }

        fun saveDomains(list: List<String>) {
            p.sitesExtra = list.joinToString("\n")
        }

        fun addDomain() {
            val d = normalizeDomain(newDomain)
            domainError = null
            when {
                d.isEmpty() -> domainError = "دامنه را وارد کنید"
                !d.contains('.') -> domainError = "دامنه معتبر نیست (مثال: example.com)"
                domains.any { it == d } -> domainError = "این دامنه قبلاً اضافه شده"
                else -> {
                    saveDomains(domains + d)
                    newDomain = ""
                }
            }
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 32.dp)
        ) {
            // ───── کارت محتوای +۱۸ ─────
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    color = cs.surfaceVariant.copy(alpha = 0.55f)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Row(
                            Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(ColorWarn.copy(alpha = 0.18f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("+۱۸", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = ColorWarn)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    "محتوای +۱۸",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    "محتوای بزرگسال و جستجوی پورن",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = cs.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = p.extraSearchEnabled,
                                onCheckedChange = {
                                    p.extraSearchEnabled = it
                                    if (it && p.sitesExtra.isBlank()) {
                                        // دامنه‌های پیش‌فرض برای اولین فعال‌سازی
                                        p.sitesExtra = listOf(
                                            "pornhub.com",
                                            "xvideos.com",
                                            "xhamster.com",
                                            "xnxx.com"
                                        ).joinToString("\n")
                                    }
                                    if (!it && vm.vMediaType == com.fastget.app.core.MediaType.EXTRA) {
                                        vm.vMediaType = com.fastget.app.core.MediaType.VIDEO
                                    }
                                },
                                colors = SwitchDefaults.colors(
                                    checkedTrackColor = ColorWarn,
                                    checkedThumbColor = cs.onPrimary
                                )
                            )
                        }

                        if (p.extraSearchEnabled) {
                            Spacer(Modifier.height(14.dp))
                            Text(
                                "با روشن بودن این گزینه، نوع «+۱۸» در نوار جستجو ظاهر می‌شود و لینک‌های این دامنه‌ها فقط در فضای محافظت‌شده ذخیره می‌شوند.",
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant
                            )
                            Spacer(Modifier.height(14.dp))

                            // افزودن دامنه
                            Text(
                                "سایت‌های خصوصی",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(Modifier.height(8.dp))
                            Row(
                                Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.Top,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = newDomain,
                                    onValueChange = {
                                        newDomain = it
                                        domainError = null
                                    },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp),
                                    placeholder = { Text("example.com") },
                                    leadingIcon = {
                                        Icon(Icons.Rounded.Public, contentDescription = null, modifier = Modifier.size(20.dp))
                                    },
                                    isError = domainError != null,
                                    supportingText = domainError?.let { { Text(it, color = ColorBad) } },
                                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                                    keyboardActions = KeyboardActions(onDone = { addDomain() }),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = ColorWarn,
                                        unfocusedBorderColor = cs.outline.copy(alpha = 0.4f)
                                    )
                                )
                                Button(
                                    onClick = { addDomain() },
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.height(56.dp)
                                ) {
                                    Icon(Icons.Rounded.Add, contentDescription = "افزودن", modifier = Modifier.size(20.dp))
                                }
                            }

                            if (domains.isNotEmpty()) {
                                Spacer(Modifier.height(12.dp))
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    domains.forEach { domain ->
                                        DomainChip(
                                            domain = domain,
                                            onRemove = {
                                                saveDomains(domains.filter { it != domain })
                                            }
                                        )
                                    }
                                }
                            } else {
                                Spacer(Modifier.height(10.dp))
                                Text(
                                    "هنوز دامنه‌ای اضافه نشده. دامنه‌های سایت‌های بزرگسال را اینجا وارد کنید.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = cs.onSurfaceVariant
                                )
                            }
                        } else {
                            Spacer(Modifier.height(10.dp))
                            Text(
                                "برای استفاده از دانلود و جستجوی محتوای بزرگسال، این گزینه را روشن کنید.",
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // ───── دانلودهای خصوصی ─────
            item {
                Spacer(Modifier.height(4.dp))
                Text(
                    "دانلودهای خصوصی",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )
            }
            val mine = items.filter { it.isPrivate }
            if (mine.isEmpty()) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        color = cs.surfaceVariant.copy(alpha = 0.35f)
                    ) {
                        Text(
                            "اینجا خالی است. هنگام افزودن لینک +۱۸ یا انتخاب «ذخیره در پوشهٔ خصوصی»، فایل‌ها اینجا ظاهر می‌شوند.",
                            modifier = Modifier.padding(16.dp),
                            style = MaterialTheme.typography.bodyMedium,
                            color = cs.onSurfaceVariant
                        )
                    }
                }
            } else if (vm.prefs.homeGridLayout) {
                item {
                    val rows = mine.chunked(2)
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        rows.forEach { row ->
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                row.forEach { e ->
                                    Box(Modifier.weight(1f)) {
                                        DownloadCard(
                                            e, live[e.id], vm,
                                            tile = true,
                                            onDelete = { confirm = e }
                                        )
                                    }
                                }
                                if (row.size == 1) Spacer(Modifier.weight(1f))
                            }
                        }
                    }
                }
            } else {
                items(mine, key = { it.id }) { e ->
                    DownloadCard(e, live[e.id], vm, tile = false, onDelete = { confirm = e })
                }
            }
        }
    }

    confirm?.let { e ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            containerColor = cs.surface,
            title = { Text("حذف از پوشهٔ خصوصی") },
            text = { Text("فایل برای همیشه پاک می‌شود.") },
            confirmButton = {
                TextButton(onClick = { vm.manager.delete(e.id, true); confirm = null }) {
                    Text("حذف", color = ColorBad)
                }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("انصراف") } }
        )
    }
}

@Composable
private fun DomainChip(domain: String, onRemove: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(
        shape = RoundedCornerShape(50),
        color = cs.surface,
        modifier = Modifier.border(1.dp, cs.outline.copy(alpha = 0.35f), RoundedCornerShape(50))
    ) {
        Row(
            Modifier.padding(start = 12.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                domain,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            IconButton(onClick = onRemove, modifier = Modifier.size(28.dp)) {
                Icon(
                    Icons.Rounded.Close,
                    contentDescription = "حذف",
                    modifier = Modifier.size(16.dp),
                    tint = cs.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun Gate(message: String, action: String?, onAction: () -> Unit = {}) {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 56.dp, horizontal = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Rounded.Lock, null, Modifier.size(56.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(14.dp))
        Text(message, textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium)
        if (action != null) {
            Spacer(Modifier.height(16.dp))
            Button(onClick = onAction) { Text(action) }
        }
    }
}

private fun normalizeDomain(raw: String): String {
    return raw.trim().lowercase()
        .removePrefix("https://")
        .removePrefix("http://")
        .removePrefix("www.")
        .substringBefore('/')
        .substringBefore('?')
        .trim()
}

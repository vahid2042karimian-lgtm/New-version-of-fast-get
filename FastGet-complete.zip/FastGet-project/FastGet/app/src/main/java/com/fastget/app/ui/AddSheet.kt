package com.fastget.app.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.InsertDriveFile
import androidx.compose.material.icons.rounded.InsertLink
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Storage
import coil.compose.AsyncImage
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import android.widget.Toast
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.fastget.app.core.QualityOption
import com.fastget.app.core.SegmentedDownloader
import com.fastget.app.core.VideoEngine
import com.fastget.app.core.VideoMeta
import com.fastget.app.core.expandBatch
import com.fastget.app.core.fa
import com.fastget.app.core.formatBytes
import com.fastget.app.ui.theme.ColorBad
import com.fastget.app.ui.theme.ColorOk
import com.fastget.app.ui.theme.ColorWarn
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/** نتیجه تشخیص هوشمند لینک (اسکلت مرحله ۱ — منطق کامل در مراحل بعد) */
sealed class LinkDetectResult {
    data object Idle : LinkDetectResult()
    data object Probing : LinkDetectResult()
    data class DirectFile(
        val url: String,
        val fileName: String?,
        val totalBytes: Long,
        val acceptRanges: Boolean
    ) : LinkDetectResult()
    data class Video(
        val url: String,
        val meta: VideoMeta,
        val isAdult: Boolean
    ) : LinkDetectResult()
    data class WebPage(val url: String, val note: String) : LinkDetectResult()
    data class Batch(val urls: List<String>) : LinkDetectResult()
    data class Error(val message: String) : LinkDetectResult()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddSheet(vm: MainViewModel) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val cs = MaterialTheme.colorScheme
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var text by remember { mutableStateOf(vm.prefill) }
    var detect by remember { mutableStateOf<LinkDetectResult>(LinkDetectResult.Idle) }
    var selectedQuality by remember { mutableStateOf<QualityOption?>(null) }
    // لیست مقصد دانلود (main / vault / سفارشی)
    var targetListId by remember { mutableStateOf("main") }
    // برای جلوگیری از درخواست تکراری هنگام تایپ سریع
    var lastProbed by remember { mutableStateOf("") }

    val allowHttp = vm.prefs.allowHttp
    val found = remember(text) { expandBatch(text) }
    val magnets = remember(text) {
        text.lines().map { it.trim() }.filter { it.startsWith("magnet:", ignoreCase = true) }
    }
    val validUrls = found.filter {
        it.startsWith("https://") || (allowHttp && it.startsWith("http://"))
    } + magnets
    val blockedHttp = found.count { it.startsWith("http://") && !allowHttp }

    // تشخیص خودکار با debounce کوتاه
    LaunchedEffect(text) {
        val primary = validUrls.firstOrNull()
        if (primary.isNullOrBlank()) {
            detect = LinkDetectResult.Idle
            lastProbed = ""
            return@LaunchedEffect
        }
        // چند لینک → حالت گروهی (فعلاً ساده)
        if (validUrls.size > 1) {
            detect = LinkDetectResult.Batch(validUrls)
            lastProbed = primary
            return@LaunchedEffect
        }
        // همان لینک قبلاً بررسی شده
        if (primary == lastProbed && detect !is LinkDetectResult.Idle && detect !is LinkDetectResult.Error) {
            return@LaunchedEffect
        }
        // مکث کوتاه بعد از توقف تایپ
        delay(450)
        if (text.trim() != primary && !text.contains(primary)) return@LaunchedEffect

        detect = LinkDetectResult.Probing
        lastProbed = primary

        val result = withContext(Dispatchers.IO) {
            runCatching { probeLink(primary, vm) }
                .getOrElse { LinkDetectResult.Error(it.message ?: "خطای ناشناخته در شناسایی") }
        }
        // فقط اگر هنوز همان لینک است نتیجه را اعمال کن
        if (lastProbed == primary) {
            detect = result
            // پیش‌فرض بهترین کیفیت (اولین آیتم = بالاترین height)
            if (result is LinkDetectResult.Video) {
                selectedQuality = result.meta.qualities.firstOrNull()
                    ?: result.meta.heights.firstOrNull()?.let { QualityOption(height = it) }
            } else {
                selectedQuality = null
            }
        }
    }

    fun recheck() {
        lastProbed = ""
        // با تغییر lastProbed، LaunchedEffect دوباره اجرا می‌شود
        val t = text
        text = t + " "
        text = t
    }

    ModalBottomSheet(
        onDismissRequest = { vm.showAdd = false },
        sheetState = sheetState,
        containerColor = cs.surface,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        dragHandle = {
            Box(
                Modifier
                    .padding(top = 12.dp, bottom = 4.dp)
                    .size(width = 40.dp, height = 4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(cs.onSurfaceVariant.copy(alpha = 0.35f))
            )
        }
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .imePadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 16.dp)
        ) {
            // ——— عنوان ———
            Text(
                "افزودن لینک",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "لینک را وارد کنید؛ نوع محتوا به‌صورت خودکار شناسایی می‌شود.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )
            Spacer(Modifier.height(16.dp))

            // ——— کادر ورودی ———
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = false,
                minLines = 2,
                maxLines = 5,
                shape = RoundedCornerShape(18.dp),
                textStyle = TextStyle(textDirection = TextDirection.Ltr),
                placeholder = {
                    Text(
                        "https://…",
                        color = cs.onSurfaceVariant.copy(alpha = 0.6f)
                    )
                },
                leadingIcon = {
                    Icon(
                        Icons.Rounded.InsertLink,
                        contentDescription = null,
                        tint = cs.primary
                    )
                },
                trailingIcon = {
                    Row {
                        if (text.isNotBlank()) {
                            IconButton(onClick = { text = ""; detect = LinkDetectResult.Idle }) {
                                Icon(Icons.Rounded.Clear, contentDescription = "پاک کردن")
                            }
                        }
                        IconButton(onClick = {
                            clipboard.getText()?.text?.let { clip ->
                                text = if (text.isBlank()) clip.trim() else text.trimEnd() + "\n" + clip.trim()
                            }
                        }) {
                            Icon(Icons.Rounded.ContentPaste, contentDescription = "جای‌گذاری")
                        }
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = cs.primary,
                    unfocusedBorderColor = cs.outline.copy(alpha = 0.5f)
                )
            )

            // ——— نوار وضعیت تشخیص ———
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                StatusChip(detect = detect, urlCount = validUrls.size, blocked = blockedHttp)
                if (validUrls.isNotEmpty() && detect !is LinkDetectResult.Probing) {
                    TextButton(onClick = { recheck() }) {
                        Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("بررسی مجدد", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }

            if (blockedHttp > 0) {
                Spacer(Modifier.height(6.dp))
                Text(
                    "${fa(blockedHttp)} لینک http رد شد. در تنظیمات می‌توانید اجازه بدهید.",
                    style = MaterialTheme.typography.bodySmall,
                    color = ColorBad
                )
            }

            // ——— محتوای پویا بر اساس نتیجه تشخیص ———
            AnimatedContent(
                targetState = detect,
                transitionSpec = { fadeIn() + expandVertically() togetherWith fadeOut() + shrinkVertically() },
                label = "detectContent"
            ) { state ->
                when (state) {
                    is LinkDetectResult.Idle -> {
                        Spacer(Modifier.height(8.dp))
                    }
                    is LinkDetectResult.Probing -> {
                        ProbingBlock()
                    }
                    is LinkDetectResult.DirectFile -> {
                        FileInfoBlock(state)
                    }
                    is LinkDetectResult.Video -> {
                        VideoInfoSkeleton(
                            result = state,
                            selectedQuality = selectedQuality,
                            onSelectQuality = { selectedQuality = it },
                            adultEnabled = vm.prefs.extraSearchEnabled
                        )
                    }
                    is LinkDetectResult.WebPage -> {
                        WebPageBlock(state)
                    }
                    is LinkDetectResult.Batch -> {
                        BatchBlock(state)
                    }
                    is LinkDetectResult.Error -> {
                        ErrorBlock(state.message)
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            HorizontalDivider(color = cs.outline.copy(alpha = 0.25f))
            Spacer(Modifier.height(12.dp))

            // ——— انتخاب لیست مقصد ———
            val isAdultDetect = (detect as? LinkDetectResult.Video)?.isAdult == true
            TargetListPicker(
                prefs = vm.prefs,
                selectedId = if (isAdultDetect) "vault" else targetListId,
                forceVault = isAdultDetect,
                onSelect = { targetListId = it }
            )
            Spacer(Modifier.height(12.dp))

            // ——— دکمه‌های عملیات ———
            val adultBlocked = (detect as? LinkDetectResult.Video)?.let {
                it.isAdult && !vm.prefs.extraSearchEnabled
            } == true
            ActionButtons(
                detect = detect,
                hasUrls = validUrls.isNotEmpty(),
                adultBlocked = adultBlocked,
                onAddToList = {
                    scope.launch {
                        val msg = submitLink(
                            vm, detect, selectedQuality,
                            autoStart = false,
                            targetListId = if (isAdultDetect) "vault" else targetListId
                        )
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        // در صورت خطا / مسدود / تکراری پنجره باز می‌ماند
                        val keepOpen = msg.startsWith("خطا") || msg.startsWith("مسدود") ||
                            msg.contains("قبلاً") || msg.contains("تکراری")
                        if (!keepOpen) vm.showAdd = false
                    }
                },
                onDownload = {
                    scope.launch {
                        val msg = submitLink(
                            vm, detect, selectedQuality,
                            autoStart = true,
                            targetListId = if (isAdultDetect) "vault" else targetListId
                        )
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        val keepOpen = msg.startsWith("خطا") || msg.startsWith("مسدود") ||
                            msg.contains("قبلاً") || msg.contains("تکراری")
                        if (!keepOpen) vm.showAdd = false
                    }
                }
            )
        }
    }
}

// ───────────────────────────── UI blocks ─────────────────────────────

@Composable
private fun StatusChip(detect: LinkDetectResult, urlCount: Int, blocked: Int) {
    val cs = MaterialTheme.colorScheme
    val (label, color) = when (detect) {
        is LinkDetectResult.Idle ->
            if (urlCount == 0) "لینک معتبری پیدا نشد" to cs.onSurfaceVariant
            else "${fa(urlCount)} لینک شناسایی شد" to cs.primary
        is LinkDetectResult.Probing -> "در حال شناسایی…" to cs.primary
        is LinkDetectResult.DirectFile -> "فایل مستقیم" to ColorOk
        is LinkDetectResult.Video ->
            if (detect.isAdult) "ویدیوی خصوصی +۱۸" to ColorWarn
            else "ویدیو شناسایی شد" to ColorOk
        is LinkDetectResult.WebPage -> "صفحه وب" to ColorWarn
        is LinkDetectResult.Batch -> "${fa(detect.urls.size)} لینک گروهی" to cs.primary
        is LinkDetectResult.Error -> "خطا در شناسایی" to ColorBad
    }
    Text(
        label,
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.Medium,
        color = color
    )
}

@Composable
private fun ProbingBlock() {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        CircularProgressIndicator(
            modifier = Modifier.size(20.dp),
            strokeWidth = 2.dp,
            color = cs.primary
        )
        Spacer(Modifier.width(10.dp))
        Text(
            "در حال بررسی لینک…",
            style = MaterialTheme.typography.bodyMedium,
            color = cs.onSurfaceVariant
        )
    }
}

@Composable
private fun FileInfoBlock(result: LinkDetectResult.DirectFile) {
    val cs = MaterialTheme.colorScheme
    val ext = result.fileName?.substringAfterLast('.', "")?.uppercase().orEmpty()
        .takeIf { it.isNotBlank() && it.length <= 6 }
    val typeLabel = when {
        ext == null -> "فایل"
        ext in listOf("MP4", "MKV", "WEBM", "MOV", "AVI", "M4V") -> "ویدیو"
        ext in listOf("MP3", "M4A", "AAC", "FLAC", "WAV", "OGG") -> "صوت"
        ext in listOf("ZIP", "RAR", "7Z", "TAR", "GZ") -> "آرشیو"
        ext in listOf("PDF", "DOC", "DOCX", "XLS", "XLSX", "PPT", "PPTX") -> "سند"
        ext in listOf("APK", "EXE", "MSI", "DMG") -> "برنامه"
        ext in listOf("JPG", "JPEG", "PNG", "GIF", "WEBP", "BMP") -> "تصویر"
        else -> "فایل"
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 12.dp),
        shape = RoundedCornerShape(18.dp),
        color = cs.surfaceVariant.copy(alpha = 0.45f)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(cs.primary.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Rounded.InsertDriveFile,
                        contentDescription = null,
                        tint = cs.primary,
                        modifier = Modifier.size(26.dp)
                    )
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        "اطلاعات فایل",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = cs.primary
                    )
                    Text(
                        typeLabel + (ext?.let { " · $it" } ?: ""),
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            HorizontalDivider(color = cs.outline.copy(alpha = 0.2f))
            Spacer(Modifier.height(10.dp))
            InfoRow("نام", result.fileName ?: "نامشخص")
            InfoRow(
                "حجم",
                if (result.totalBytes > 0) formatBytes(result.totalBytes) else "نامشخص"
            )
            if (ext != null) InfoRow("فرمت", ext)
            InfoRow(
                "قابلیت ادامه",
                if (result.acceptRanges) "بله — دانلود چندبخشی پشتیبانی می‌شود" else "خیر"
            )
            // خلاصه سریع حجم
            if (result.totalBytes > 0) {
                Spacer(Modifier.height(10.dp))
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(cs.primary.copy(alpha = 0.08f))
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.Storage, null, Modifier.size(18.dp), tint = cs.primary)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "حجم فایل: ${formatBytes(result.totalBytes)}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = cs.primary
                    )
                }
            }
        }
    }
}

@Composable
private fun VideoInfoSkeleton(
    result: LinkDetectResult.Video,
    selectedQuality: QualityOption?,
    onSelectQuality: (QualityOption) -> Unit,
    adultEnabled: Boolean
) {
    val cs = MaterialTheme.colorScheme
    val meta = result.meta
    val blocked = result.isAdult && !adultEnabled
    // لیست کیفیت: از qualities غنی، یا fallback به heights ساده
    val qualityList = remember(meta) {
        if (meta.qualities.isNotEmpty()) meta.qualities
        else meta.heights.map { QualityOption(height = it) }
    }

    Column(
        Modifier
            .padding(top = 12.dp)
            .heightIn(max = 360.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // کارت اصلی با thumbnail
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            color = cs.surfaceVariant.copy(alpha = 0.45f)
        ) {
            Column(Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.Top) {
                    if (!meta.thumbnail.isNullOrBlank()) {
                        AsyncImage(
                            model = meta.thumbnail,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(width = 120.dp, height = 68.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(cs.surfaceVariant)
                        )
                    } else {
                        Box(
                            Modifier
                                .size(width = 120.dp, height = 68.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(cs.primary.copy(alpha = 0.1f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Rounded.Movie,
                                contentDescription = null,
                                tint = cs.primary.copy(alpha = 0.6f),
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (result.isAdult) "ویدیوی خصوصی +۱۸" else "اطلاعات ویدیو",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = if (result.isAdult) ColorWarn else cs.primary
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            meta.title,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))
                HorizontalDivider(color = cs.outline.copy(alpha = 0.2f))
                Spacer(Modifier.height(10.dp))

                MetaChipRow(
                    items = buildList {
                        if (meta.uploader.isNotBlank()) add(Icons.Rounded.Movie to meta.uploader.take(32))
                        if (meta.durationSec > 0) {
                            val m = meta.durationSec / 60
                            val s = meta.durationSec % 60
                            add(
                                Icons.Rounded.Schedule to if (m > 0)
                                    "${fa(m)}:${fa(s.toString().padStart(2, '0'))} دقیقه"
                                else "${fa(s)} ثانیه"
                            )
                        }
                        if (meta.site.isNotBlank()) add(Icons.Rounded.InsertLink to meta.site)
                        if (qualityList.isNotEmpty()) {
                            add(Icons.Rounded.CheckCircle to "تا ${fa(qualityList.maxOf { it.height })}p · ${fa(qualityList.size)} کیفیت")
                        }
                    }
                )
            }
        }

        if (blocked) {
            Spacer(Modifier.height(12.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = ColorWarn.copy(alpha = 0.12f)
            ) {
                Text(
                    "برای ثبت و دانلود این محتوا، ابتدا گزینه «محتوای +۱۸» را در پوشهٔ خصوصی فعال کنید.",
                    modifier = Modifier.padding(14.dp),
                    style = MaterialTheme.typography.bodySmall,
                    color = ColorWarn
                )
            }
        } else {
            Spacer(Modifier.height(14.dp))
            Text(
                "انتخاب کیفیت",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(8.dp))
            if (qualityList.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    qualityList.forEach { q ->
                        val selected = selectedQuality?.height == q.height
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .clickable { onSelectQuality(q) }
                                .then(
                                    if (selected) Modifier.border(1.5.dp, cs.primary, RoundedCornerShape(14.dp))
                                    else Modifier
                                ),
                            shape = RoundedCornerShape(14.dp),
                            color = if (selected) cs.primary.copy(alpha = 0.14f) else cs.surfaceVariant.copy(alpha = 0.5f)
                        ) {
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        q.labelFa.replace(Regex("""\d+""")) { fa(it.value) },
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.SemiBold,
                                        color = if (selected) cs.primary else cs.onSurface
                                    )
                                    val sub = buildList {
                                        add(q.ext.uppercase().ifBlank { "MP4" })
                                        if (q.note.isNotBlank()) add(q.note)
                                        if (q.fps > 0) add("${fa(q.fps)}fps")
                                    }.joinToString(" · ")
                                    if (sub.isNotBlank()) {
                                        Text(
                                            sub,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = if (selected) cs.primary.copy(alpha = 0.85f) else cs.onSurfaceVariant
                                        )
                                    }
                                }
                                if (q.filesize > 0) {
                                    Text(
                                        formatBytes(q.filesize),
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Medium,
                                        color = if (selected) cs.primary else cs.onSurfaceVariant
                                    )
                                } else if (selected) {
                                    Icon(
                                        Icons.Rounded.CheckCircle,
                                        contentDescription = null,
                                        tint = cs.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = cs.surfaceVariant.copy(alpha = 0.5f)
                ) {
                    Text(
                        "کیفیت اصلی (بهترین موجود)",
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            if (result.isAdult) {
                Spacer(Modifier.height(12.dp))
                Text(
                    "این ویدیو فقط در فضای محافظت‌شده ذخیره می‌شود و در لیست عمومی ظاهر نمی‌شود.",
                    style = MaterialTheme.typography.bodySmall,
                    color = ColorWarn
                )
            }
        }
    }
}

@Composable
private fun MetaChipRow(items: List<Pair<ImageVector, String>>) {
    val cs = MaterialTheme.colorScheme
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        items.forEach { (icon, text) ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, Modifier.size(16.dp), tint = cs.onSurfaceVariant)
                Spacer(Modifier.width(6.dp))
                Text(
                    text,
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun WebPageBlock(result: LinkDetectResult.WebPage) {
    val cs = MaterialTheme.colorScheme
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 12.dp),
        shape = RoundedCornerShape(16.dp),
        color = cs.surfaceVariant.copy(alpha = 0.45f)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(
                "صفحه وب",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
                color = ColorWarn
            )
            Spacer(Modifier.height(6.dp))
            Text(
                result.note,
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun BatchBlock(result: LinkDetectResult.Batch) {
    val cs = MaterialTheme.colorScheme
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 12.dp),
        shape = RoundedCornerShape(16.dp),
        color = cs.surfaceVariant.copy(alpha = 0.45f)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(
                "${fa(result.urls.size)} لینک گروهی",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
                color = cs.primary
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "همه لینک‌ها به‌صورت فایل مستقیم به صف اضافه می‌شوند.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ErrorBlock(message: String) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 12.dp),
        shape = RoundedCornerShape(16.dp),
        color = ColorBad.copy(alpha = 0.12f)
    ) {
        Text(
            message,
            modifier = Modifier.padding(14.dp),
            style = MaterialTheme.typography.bodyMedium,
            color = ColorBad
        )
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(
            label,
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
            modifier = Modifier.width(90.dp)
        )
        Text(
            value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun TargetListPicker(
    prefs: com.fastget.app.core.Prefs,
    selectedId: String,
    forceVault: Boolean,
    onSelect: (String) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val lists = remember(prefs.customListsRaw) {
        buildList {
            add("main" to "لیست اصلی")
            add("vault" to "فضای قفل‌شده")
            prefs.customLists().forEach { add(it.id to it.title) }
        }
    }
    Column(Modifier.fillMaxWidth()) {
        Text(
            "ارسال به لیست",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold,
            color = cs.onSurfaceVariant
        )
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            lists.forEach { (id, title) ->
                val selected = selectedId == id
                val enabled = !forceVault || id == "vault"
                FilterChip(
                    selected = selected,
                    onClick = { if (enabled) onSelect(id) },
                    enabled = enabled,
                    label = { Text(title) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = cs.primary,
                        selectedLabelColor = cs.onPrimary
                    )
                )
            }
        }
        if (forceVault) {
            Spacer(Modifier.height(4.dp))
            Text(
                "محتوای محدود فقط در فضای قفل‌شده ذخیره می‌شود.",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ActionButtons(
    detect: LinkDetectResult,
    hasUrls: Boolean,
    adultBlocked: Boolean,
    onAddToList: () -> Unit,
    onDownload: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val enabled = hasUrls &&
        detect !is LinkDetectResult.Probing &&
        detect !is LinkDetectResult.Error &&
        !adultBlocked

    // متن دکمه‌ها بر اساس نوع
    val (addLabel, dlLabel) = when (detect) {
        is LinkDetectResult.Video -> {
            if (detect.isAdult) "افزودن به لیست محافظت‌شده" to "دانلود در فضای محافظت‌شده"
            else "افزودن به لیست" to "دانلود"
        }
        else -> "افزودن به لیست" to "دانلود"
    }

    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        OutlinedButton(
            onClick = onAddToList,
            enabled = enabled,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(14.dp)
        ) {
            Text(addLabel, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Button(
            onClick = onDownload,
            enabled = enabled,
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = cs.primary,
                contentColor = cs.onPrimary
            )
        ) {
            Text(dlLabel, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

// ───────────────────────────── ثبت نهایی با بررسی امنیتی ─────────────────────────────

/**
 * ثبت لینک در موتور دانلود با بررسی تکراری و +۱۸.
 * @return پیام فارسی برای Toast
 */
private suspend fun submitLink(
    vm: MainViewModel,
    detect: LinkDetectResult,
    selectedQuality: QualityOption?,
    autoStart: Boolean,
    targetListId: String = "main"
): String {
    val prefs = vm.prefs
    val manager = vm.manager

    fun statusLabel(auto: Boolean) =
        if (auto) "دانلود شروع شد" else "به لیست اضافه شد"

    when (detect) {
        is LinkDetectResult.Video -> {
            val adult = detect.isAdult || prefs.isAdultUrl(detect.url)
            if (adult && !prefs.extraSearchEnabled) {
                return "مسدود: ابتدا «محتوای +۱۸» را در پوشهٔ خصوصی فعال کنید"
            }
            val existing = manager.findExisting(detect.url)
            if (existing != null) {
                return "این لینک قبلاً ثبت شده است (${existing.fileName})"
            }
            val spec = selectedQuality?.spec ?: "v:best"
            val listId = if (adult) "vault" else targetListId
            manager.enqueueVideo(
                url = detect.url,
                title = detect.meta.title,
                thumb = detect.meta.thumbnail,
                spec = spec,
                private = adult || listId == "vault",
                autoStart = autoStart,
                targetListId = listId
            )
            return if (adult || listId == "vault") {
                if (autoStart) "دانلود در فضای قفل‌شده شروع شد"
                else "به فضای قفل‌شده اضافه شد"
            } else {
                statusLabel(autoStart)
            }
        }
        is LinkDetectResult.DirectFile -> {
            if (prefs.isAdultUrl(detect.url) && !prefs.extraSearchEnabled) {
                return "مسدود: ابتدا «محتوای +۱۸» را در پوشهٔ خصوصی فعال کنید"
            }
            val existing = manager.findExisting(detect.url)
            if (existing != null) {
                return "این لینک قبلاً ثبت شده است (${existing.fileName})"
            }
            manager.enqueue(listOf(detect.url), autoStart = autoStart, targetListId = targetListId)
            return statusLabel(autoStart)
        }
        is LinkDetectResult.Batch -> {
            val fresh = detect.urls.filter { manager.findExisting(it) == null }
            val skipped = detect.urls.size - fresh.size
            if (fresh.isEmpty()) {
                return "همه لینک‌ها قبلاً ثبت شده‌اند"
            }
            manager.enqueue(fresh, autoStart = autoStart, targetListId = targetListId)
            return buildString {
                append(statusLabel(autoStart))
                append(" · ${fa(fresh.size)} لینک")
                if (skipped > 0) append(" · ${fa(skipped)} تکراری رد شد")
            }
        }
        is LinkDetectResult.Error -> return "خطا: ${detect.message}"
        is LinkDetectResult.WebPage -> return "خطا: رسانه قابل دانلود شناسایی نشد"
        is LinkDetectResult.Probing -> return "خطا: هنوز در حال شناسایی است"
        is LinkDetectResult.Idle -> return "خطا: لینک معتبری وارد نشده"
    }
}

// ───────────────────────────── تشخیص هوشمند (مرحله ۲) ─────────────────────────────

private fun hostOf(url: String): String = try {
    java.net.URI(url).host?.lowercase()?.removePrefix("www.") ?: ""
} catch (_: Throwable) { "" }

private fun domainList(raw: String): List<String> =
    raw.lines()
        .map {
            it.trim().lowercase()
                .removePrefix("https://").removePrefix("http://").removePrefix("www.")
                .substringBefore('/').substringBefore('?')
        }
        .filter { it.isNotEmpty() }

private fun hostMatches(host: String, domains: List<String>): Boolean =
    domains.any { host == it || host.endsWith(".$it") }

private fun extensionOf(url: String): String {
    val path = try { java.net.URI(url).path ?: "" } catch (_: Throwable) { "" }
    val name = path.substringAfterLast('/')
    return name.substringAfterLast('.', "").lowercase().take(8)
}

private val VIDEO_EXTS = setOf("mp4", "mkv", "webm", "mov", "m4v", "avi", "flv", "ts", "m3u8")
private val AUDIO_EXTS = setOf("mp3", "m4a", "aac", "flac", "wav", "ogg", "opus", "wma")
private val ARCHIVE_EXTS = setOf("zip", "rar", "7z", "tar", "gz", "bz2", "xz")
private val DOC_EXTS = setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "rtf")
private val APP_EXTS = setOf("apk", "exe", "msi", "dmg", "ipa")
private val IMAGE_EXTS = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "svg", "heic")

private suspend fun probeLink(url: String, vm: MainViewModel): LinkDetectResult {
    // مگنت / تورنت
    if (url.startsWith("magnet:", ignoreCase = true) || url.endsWith(".torrent", ignoreCase = true)) {
        return LinkDetectResult.DirectFile(
            url = url,
            fileName = if (url.startsWith("magnet:")) "torrent (magnet)" else url.substringAfterLast('/'),
            totalBytes = -1,
            acceptRanges = false
        )
    }

    val host = hostOf(url)
    val prefs = vm.prefs
    val videoDomains = domainList(prefs.sitesVideo) + listOf(
        "youtube.com", "youtu.be", "aparat.com", "vimeo.com", "dailymotion.com", "twitch.tv"
    )
    val audioDomains = domainList(prefs.sitesAudio) + listOf("soundcloud.com")
    // فقط از لیست خصوصی sitesExtra — نه از وجود کلمه‌ای مثل adult در URL
    val isAdultDomain = prefs.isAdultUrl(url)
    val isVideoDomain = hostMatches(host, videoDomains) || looksLikeVideoPage(url)
    val isAudioDomain = hostMatches(host, audioDomains)

    // پسوند فایل مستقیم
    val ext = extensionOf(url)
    val looksDirectMedia = ext in VIDEO_EXTS || ext in AUDIO_EXTS
    val looksDirectFile = ext in ARCHIVE_EXTS || ext in DOC_EXTS || ext in APP_EXTS ||
        ext in IMAGE_EXTS || looksDirectMedia

    // اولویت ۱: دامنه +۱۸ یا صفحه ویدیویی شناخته‌شده → inspect با yt-dlp
    if (isAdultDomain || isVideoDomain || isAudioDomain) {
        return try {
            val meta = VideoEngine.inspect(url)
            LinkDetectResult.Video(url = url, meta = meta, isAdult = isAdultDomain)
        } catch (t: Throwable) {
            if (isAdultDomain) {
                LinkDetectResult.Error("شناسایی ویدیوی +۱۸ ناموفق بود: ${t.message ?: "خطای ناشناخته"}")
            } else if (looksDirectFile) {
                probeDirect(url, ext)
            } else {
                // تلاش برای فایل مستقیم، در غیر این صورت صفحه وب
                val direct = probeDirect(url, ext)
                if (direct is LinkDetectResult.DirectFile) direct
                else LinkDetectResult.Error("استخراج رسانه ناموفق بود: ${t.message ?: ""}")
            }
        }
    }

    // اولویت ۲: پسوند فایل شناخته‌شده یا HEAD برای فایل مستقیم
    if (looksDirectFile || ext.isNotEmpty()) {
        return probeDirect(url, ext)
    }

    // اولویت ۳: HEAD عمومی
    return probeDirect(url, ext)
}

private suspend fun probeDirect(url: String, extHint: String = ""): LinkDetectResult {
    val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()
    val probe = try {
        SegmentedDownloader(client).probe(url)
    } catch (t: Throwable) {
        val msg = t.message.orEmpty()
        return LinkDetectResult.Error(
            when {
                msg.contains("Unable to resolve host", true) ||
                    msg.contains("UnknownHost", true) ->
                    "اینترنت قطع است یا آدرس دامنه پیدا نشد"
                msg.contains("timeout", true) || msg.contains("timed out", true) ->
                    "پاسخ سرور طول کشید؛ دوباره تلاش کنید"
                msg.contains("SSL", true) || msg.contains("Certificate", true) ->
                    "اتصال امن برقرار نشد"
                msg.contains("404") -> "فایل روی سرور پیدا نشد (۴۰۴)"
                msg.contains("403") -> "دسترسی به فایل مجاز نیست (۴۰۳)"
                msg.contains("خطای سرور") -> msg
                else -> "سرور پاسخ نمی‌دهد یا لینک نامعتبر است"
            }
        )
    }

    val name = probe.fileName
        ?: url.substringAfterLast('/').substringBefore('?').takeIf { it.isNotBlank() && it.contains('.') }
    val total = probe.total
    val hasSize = total > 0
    val hasName = !name.isNullOrBlank()
    val ext = extHint.ifBlank {
        name?.substringAfterLast('.', "")?.lowercase() ?: extensionOf(url)
    }

    // اگر حجم یا نام فایل مشخص باشد → فایل مستقیم
    // صفحات HTML معمولاً نام فایل و Content-Range ندارند
    val isDirect = hasSize || hasName || ext in VIDEO_EXTS || ext in AUDIO_EXTS ||
        ext in ARCHIVE_EXTS || ext in DOC_EXTS || ext in APP_EXTS || ext in IMAGE_EXTS

    return if (isDirect) {
        LinkDetectResult.DirectFile(
            url = url,
            fileName = name ?: "file${if (ext.isNotEmpty()) ".$ext" else ""}",
            totalBytes = total,
            acceptRanges = probe.acceptRanges
        )
    } else {
        // صفحه وب — تلاش برای extract با yt-dlp
        try {
            val meta = VideoEngine.inspect(url)
            if (meta.title.isNotBlank() && meta.title != "بدون عنوان") {
                LinkDetectResult.Video(url = url, meta = meta, isAdult = false)
            } else {
                LinkDetectResult.WebPage(
                    url = url,
                    note = "صفحه وب شناسایی شد. رسانه قابل دانلود پیدا نشد."
                )
            }
        } catch (_: Throwable) {
            LinkDetectResult.WebPage(
                url = url,
                note = "صفحه وب شناسایی شد. استخراج رسانه ناموفق بود یا سایت پشتیبانی نمی‌شود."
            )
        }
    }
}

private fun looksLikeVideoPage(u: String): Boolean {
    val low = u.lowercase()
    return low.contains("youtube.com/watch") || low.contains("youtu.be/") ||
        low.contains("aparat.com/v/") || low.contains("vimeo.com/") ||
        low.contains("soundcloud.com/") || low.contains("/watch?") ||
        low.contains("dailymotion.com/") || low.contains("twitch.tv/") ||
        low.contains("/video/") || low.contains("/embed/")
}

package com.fastget.app.core

import android.app.Application
import android.content.Context
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.currentCoroutineContext
import org.json.JSONObject
import java.io.File
import java.io.IOException

sealed interface EngineState {
    data object Initializing : EngineState
    data object Ready : EngineState
    data class Failed(val message: String) : EngineState
}

/** Legacy source chips; new UI uses MediaType + Settings site lists. */
enum class SearchSource(val prefix: String, val label: String) {
    YOUTUBE("ytsearch", "یوتیوب"),
    SOUNDCLOUD("scsearch", "ساندکلود")
}

/**
 * Thin wrapper around the yt-dlp Android library (youtubedl-android).
 *
 * Every call into the third-party API is in THIS file. If a library update changes a
 * signature, this is the only place that needs fixing:
 *  - YoutubeDL.getInstance().init / execute / destroyProcessById / updateYoutubeDL
 *  - FFmpeg.getInstance().init
 *
 * Security notes: the only user-controlled values are the URL and the search text. URLs must
 * start with http(s)://, and search text is always glued to a "ytsearchN:" prefix, so neither
 * can ever be read by yt-dlp as a command-line option.
 */
object VideoEngine {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _state = MutableStateFlow<EngineState>(EngineState.Initializing)
    val state: StateFlow<EngineState> = _state

    private const val THREE_DAYS = 3L * 24 * 3600 * 1000

    fun initAsync(app: Application, prefs: Prefs) {
        scope.launch {
            try {
                YoutubeDL.getInstance().init(app)
                FFmpeg.getInstance().init(app)
                _state.value = EngineState.Ready
            } catch (t: Throwable) {
                _state.value = EngineState.Failed(t.message ?: "خطای ناشناخته")
                return@launch
            }
            // Sites change often; keeping yt-dlp fresh is what keeps downloads working.
            if (System.currentTimeMillis() - prefs.lastEngineUpdate > THREE_DAYS) {
                runCatching {
                    update(app)
                    prefs.markEngineUpdated()
                }
            }
        }
    }

    private suspend fun ready() {
        val s = _state.first { it !is EngineState.Initializing }
        if (s is EngineState.Failed) throw IOException("موتور ویدیو آماده نیست: ${s.message}")
    }

    private fun requireHttp(url: String) {
        if (!(url.startsWith("https://") || url.startsWith("http://"))) {
            throw IOException("فقط لینک http و https پذیرفته می‌شود")
        }
    }

    // ---------------- search ----------------

    suspend fun search(query: String, source: SearchSource, count: Int = 15): List<SearchItem> =
        withContext(Dispatchers.IO) {
            ready()
            val q = query.trim().replace('\n', ' ').replace('\r', ' ').take(120)
            if (q.isEmpty()) return@withContext emptyList()
            val n = count.coerceIn(5, 30)
            // ytsearchN:query / scsearchN:query — stable yt-dlp search form
            val req = YoutubeDLRequest("${source.prefix}$n:$q")
            req.addOption("--flat-playlist")
            req.addOption("-J")
            req.addOption("--no-warnings")
            req.addOption("--ignore-errors")
            req.addOption("--socket-timeout", "25")
            req.addOption("--playlist-end", n.toString())
            val out = try {
                YoutubeDL.getInstance().execute(req).out
            } catch (t: Throwable) {
                // One retry without playlist-end (older yt-dlp builds)
                val req2 = YoutubeDLRequest("${source.prefix}$n:$q")
                req2.addOption("--flat-playlist")
                req2.addOption("-J")
                req2.addOption("--no-warnings")
                req2.addOption("--ignore-errors")
                req2.addOption("--socket-timeout", "25")
                YoutubeDL.getInstance().execute(req2).out
            }
            val start = out.indexOf('{')
            if (start < 0) return@withContext emptyList()
            val root = JSONObject(out.substring(start))
            val arr = root.optJSONArray("entries") ?: return@withContext emptyList()

            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val id = o.optString("id").ifBlank { o.optString("url") }
                    var url = o.optString("webpage_url").ifBlank { o.optString("url") }
                    // Flat ytsearch often returns only the video id — build a real watch URL
                    if (!url.startsWith("http")) {
                        if (source == SearchSource.YOUTUBE && id.isNotBlank() && !id.startsWith("http")) {
                            url = "https://www.youtube.com/watch?v=$id"
                        } else {
                            continue
                        }
                    }
                    if (source == SearchSource.YOUTUBE &&
                        !url.contains("youtube.com") && !url.contains("youtu.be") &&
                        id.isNotBlank() && id.length == 11
                    ) {
                        url = "https://www.youtube.com/watch?v=$id"
                    }
                    val isYoutube = url.contains("youtube.com") || url.contains("youtu.be")
                    val thumb = when {
                        isYoutube && id.isNotBlank() && id.length >= 6 ->
                            "https://i.ytimg.com/vi/$id/mqdefault.jpg"
                        else -> o.optJSONArray("thumbnails")
                            ?.let { th -> th.optJSONObject(th.length() - 1)?.optString("url") }
                            ?.takeIf { it.startsWith("http") }
                            ?: o.optString("thumbnail").takeIf { it.startsWith("http") }
                    }
                    val media = when (source) {
                        SearchSource.SOUNDCLOUD -> MediaType.AUDIO
                        SearchSource.YOUTUBE -> MediaType.VIDEO
                    }
                    add(
                        SearchItem(
                            id = id.ifBlank { url.hashCode().toString() },
                            title = o.optString("title").ifBlank { "بدون عنوان" },
                            url = url,
                            uploader = o.optString("uploader").ifBlank { o.optString("channel") },
                            durationSec = o.optDouble("duration", 0.0).toLong(),
                            thumbnail = thumb,
                            mediaType = media,
                            sourceSite = when (source) {
                                SearchSource.YOUTUBE -> "youtube"
                                SearchSource.SOUNDCLOUD -> "soundcloud"
                            }
                        )
                    )
                }
            }
        }

    /**
     * Search by loading a site search URL as a flat playlist (used by SearchCoordinator
     * for pornhub / aparat / custom hosts from Settings).
     * Age-gate: injects a common cookie so many adult sites skip the interstitial.
     */
    suspend fun searchByUrl(searchUrl: String, count: Int = 15): List<SearchItem> =
        withContext(Dispatchers.IO) {
            ready()
            requireHttp(searchUrl)
            val req = YoutubeDLRequest(searchUrl)
            req.addOption("--flat-playlist")
            req.addOption("-J")
            req.addOption("--no-warnings")
            req.addOption("--ignore-errors")
            req.addOption("--socket-timeout", "25")
            req.addOption("--playlist-end", count.toString())
            // Age-gate bypass for major adult sites
            val adult = searchUrl.contains("pornhub", true) ||
                searchUrl.contains("xvideos", true) ||
                searchUrl.contains("xhamster", true) ||
                searchUrl.contains("xnxx", true)
            if (adult) {
                req.addOption(
                    "--add-header",
                    "Cookie:age_verified=1; platform=pc; accessAgeDisclaimerPH=1; age_gate=0; cookiesBanner=closed"
                )
                req.addOption("--add-header", "Accept-Language:en-US,en;q=0.9")
                req.addOption("--age-limit", "99")
            }
            val out = try {
                YoutubeDL.getInstance().execute(req).out
            } catch (_: Throwable) {
                val req2 = YoutubeDLRequest(searchUrl)
                req2.addOption("--flat-playlist")
                req2.addOption("-J")
                req2.addOption("--no-warnings")
                req2.addOption("--socket-timeout", "20")
                req2.addOption("--playlist-end", count.toString())
                if (adult) {
                    req2.addOption(
                        "--add-header",
                        "Cookie:age_verified=1; platform=pc; accessAgeDisclaimerPH=1; age_gate=0"
                    )
                }
                YoutubeDL.getInstance().execute(req2).out
            }
            val start = out.indexOf('{')
            if (start < 0) return@withContext emptyList()
            val root = JSONObject(out.substring(start))
            val arr = root.optJSONArray("entries")
            if (arr != null) {
                buildList {
                    for (i in 0 until arr.length()) {
                        val o = arr.optJSONObject(i) ?: continue
                        val id = o.optString("id").ifBlank { o.optString("url").hashCode().toString() }
                        var url = o.optString("webpage_url")
                            .ifBlank { o.optString("url") }
                            .ifBlank { o.optString("webpage_url_basename") }
                        // resolve relative paths against the search host
                        url = absoluteUrl(searchUrl, url)
                        if (!url.startsWith("http")) continue
                        // هرگز خودِ صفحهٔ جستجو را به‌عنوان ویدیو برنگردان
                        if (isSearchLikeUrl(url) || url == searchUrl) continue
                        // برای پورن‌هاب / xvideos فقط صفحات ویدیو
                        if (adult && !looksLikeAdultVideoUrl(url)) continue
                        add(
                            SearchItem(
                                id = id,
                                title = o.optString("title").ifBlank { "بدون عنوان" },
                                url = url,
                                uploader = o.optString("uploader").ifBlank { o.optString("channel") },
                                durationSec = o.optDouble("duration", 0.0).toLong(),
                                thumbnail = o.optString("thumbnail").takeIf { it.startsWith("http") },
                                mediaType = MediaType.VIDEO,
                                sourceSite = try {
                                    java.net.URI(url).host?.removePrefix("www.") ?: ""
                                } catch (_: Throwable) { "" }
                            )
                        )
                    }
                }
            } else {
                // فقط اگر واقعاً یک صفحهٔ تکی ویدیو باشد — نه صفحهٔ جستجو
                val url = absoluteUrl(
                    searchUrl,
                    root.optString("webpage_url").ifBlank { root.optString("url") }
                )
                if (url.isBlank() || isSearchLikeUrl(url) || isSearchLikeUrl(searchUrl)) {
                    emptyList()
                } else {
                    listOf(
                        SearchItem(
                            id = root.optString("id"),
                            title = root.optString("title").ifBlank { "بدون عنوان" },
                            url = url,
                            uploader = root.optString("uploader"),
                            durationSec = root.optDouble("duration", 0.0).toLong(),
                            thumbnail = root.optString("thumbnail").takeIf { it.startsWith("http") },
                            mediaType = MediaType.VIDEO,
                            sourceSite = try {
                                java.net.URI(url).host?.removePrefix("www.") ?: ""
                            } catch (_: Throwable) { "" }
                        )
                    )
                }
            }
        }

    private fun absoluteUrl(base: String, raw: String): String {
        val u = raw.trim()
        if (u.startsWith("http://") || u.startsWith("https://")) return u
        if (u.startsWith("//")) return "https:$u"
        return try {
            val b = java.net.URI(base)
            if (u.startsWith("/")) "${b.scheme}://${b.host}$u"
            else b.resolve(u).toString()
        } catch (_: Throwable) {
            u
        }
    }

    private fun isSearchLikeUrl(url: String): Boolean {
        val low = url.lowercase()
        return low.contains("/video/search") ||
            low.contains("/search?") ||
            low.contains("/search/") ||
            low.contains("?k=") ||
            low.contains("&k=") ||
            low.contains("?search=") ||
            low.contains("&search=") ||
            low.contains("?q=") ||
            (low.contains("xvideos.com") && (low.contains("?k=") || low.endsWith("xvideos.com/") || low.endsWith("xvideos.com")))
    }

    private fun looksLikeAdultVideoUrl(url: String): Boolean {
        val low = url.lowercase()
        return low.contains("view_video.php") ||
            low.contains("/video/") ||
            low.contains("/videos/") ||
            low.contains("xvideos.com/video") ||
            low.contains("xnxx.com/video") ||
            low.contains("xhamster.com/videos") ||
            Regex("""/(embed|watch)/""").containsMatchIn(low)
    }

    // ---------------- inspect a pasted link ----------------

    suspend fun inspect(url: String): VideoMeta = withContext(Dispatchers.IO) {
        ready()
        requireHttp(url)
        val req = YoutubeDLRequest(url)
        req.addOption("-J")
        req.addOption("--no-playlist")
        req.addOption("--no-warnings")
        req.addOption("--socket-timeout", "25")
        // Age-gate bypass for common adult hosts (same cookies as searchByUrl)
        val low = url.lowercase()
        val adult = low.contains("pornhub") || low.contains("xvideos") ||
            low.contains("xhamster") || low.contains("xnxx") ||
            low.contains("redtube") || low.contains("youporn")
        if (adult) {
            req.addOption(
                "--add-header",
                "Cookie:age_verified=1; platform=pc; accessAgeDisclaimerPH=1; age_gate=0; cookiesBanner=closed"
            )
            req.addOption("--add-header", "Accept-Language:en-US,en;q=0.9")
            req.addOption("--age-limit", "99")
        }
        val out = YoutubeDL.getInstance().execute(req).out
        val start = out.indexOf('{')
        if (start < 0) throw IOException("اطلاعاتی از این لینک گرفته نشد")
        val o = JSONObject(out.substring(start))

        // Group formats by height; keep the best candidate per height
        // Prefer: has video + audio, mp4/m4a, known filesize, higher tbr
        data class Cand(
            val height: Int,
            val formatId: String,
            val ext: String,
            val filesize: Long,
            val fps: Int,
            val vcodec: String,
            val acodec: String,
            val tbr: Double,
            val score: Int
        )
        val bestByHeight = mutableMapOf<Int, Cand>()

        o.optJSONArray("formats")?.let { arr ->
            for (i in 0 until arr.length()) {
                val f = arr.optJSONObject(i) ?: continue
                val h = f.optInt("height", 0)
                if (h <= 0) continue
                val vcodec = f.optString("vcodec").let { if (it == "none") "" else it }
                val acodec = f.optString("acodec").let { if (it == "none") "" else it }
                // Skip pure audio rows for video quality list
                if (vcodec.isEmpty()) continue
                val ext = f.optString("ext").ifBlank { "mp4" }
                val fps = f.optInt("fps", 0)
                val formatId = f.optString("format_id")
                val filesize = sequenceOf(
                    f.optLong("filesize", -1L),
                    f.optLong("filesize_approx", -1L)
                ).firstOrNull { it > 0 } ?: -1L
                val tbr = f.optDouble("tbr", 0.0)
                var score = 0
                if (acodec.isNotEmpty()) score += 40          // combined av preferred
                if (ext == "mp4" || ext == "m4v") score += 20
                if (filesize > 0) score += 10
                if (fps >= 50) score += 5
                score += (tbr / 100.0).toInt().coerceAtMost(15)

                val cand = Cand(h, formatId, ext, filesize, fps, vcodec, acodec, tbr, score)
                val prev = bestByHeight[h]
                if (prev == null || cand.score > prev.score ||
                    (cand.score == prev.score && cand.filesize > prev.filesize)
                ) {
                    bestByHeight[h] = cand
                }
            }
        }

        val qualities = bestByHeight.values.map { c ->
            QualityOption(
                height = c.height,
                formatId = c.formatId,
                ext = c.ext,
                filesize = c.filesize,
                fps = c.fps,
                vcodec = c.vcodec,
                acodec = c.acodec,
                note = buildString {
                    if (c.acodec.isNotEmpty()) append("ویدیو+صدا")
                    else append("ویدیو")
                    if (c.fps > 0) append(" · ${c.fps}fps")
                }
            )
        }.sortedByDescending { it.height }

        val heights = qualities.map { it.height }.distinct().sortedDescending()

        // Fallback thumbnail from thumbnails array
        var thumb = o.optString("thumbnail").takeIf { it.startsWith("http") }
        if (thumb == null) {
            o.optJSONArray("thumbnails")?.let { th ->
                for (i in th.length() - 1 downTo 0) {
                    val u = th.optJSONObject(i)?.optString("url") ?: continue
                    if (u.startsWith("http")) {
                        thumb = u
                        break
                    }
                }
            }
        }

        VideoMeta(
            title = o.optString("title").ifBlank { "بدون عنوان" },
            uploader = o.optString("uploader").ifBlank { o.optString("channel") },
            durationSec = o.optDouble("duration", 0.0).toLong(),
            thumbnail = thumb,
            heights = heights,
            site = o.optString("extractor_key").ifBlank { o.optString("extractor") },
            qualities = qualities
        )
    }

    // ---------------- download ----------------

    /**
     * spec: "a:mp3" | "a:m4a" | "v:<height>" | "v:best".
     * Output goes to [dir] using the video title; call [pickOutput] afterwards.
     * [onProgress] receives (percent 0..100, etaSeconds, bytesPerSec).
     */
    suspend fun download(
        url: String,
        spec: String,
        dir: File,
        processId: String,
        onProgress: (Float, Long, Long) -> Unit
    ) = withContext(Dispatchers.IO) {
        ready()
        requireHttp(url)
        val req = YoutubeDLRequest(url)
        req.addOption("--no-playlist")
        req.addOption("--newline")
        req.addOption("--no-mtime")
        req.addOption("--windows-filenames")
        req.addOption("--trim-filenames", "120")
        req.addOption("--retries", "10")
        req.addOption("--fragment-retries", "10")
        req.addOption("--socket-timeout", "20")
        // قطعات موازی بیشتر برای سرعت بهتر (یوتیوب و مشابه)
        req.addOption("-N", "8")
        req.addOption("--concurrent-fragments", "8")
        // Resume support: keep .part files and continue from where left off.
        // When a direct stream URL expires, yt-dlp re-extracts using the original page URL
        // and resumes if the format matches. Critical for YouTube and similar sites.
        req.addOption("--continue")
        req.addOption("--no-overwrites")          // never overwrite a finished file
        req.addOption("--part")                   // use .part extension for incomplete files
        req.addOption("-o", dir.absolutePath + "/%(title)s.%(ext)s")

        if (spec.startsWith("a:")) {
            val fmt = if (spec == "a:m4a") "m4a" else "mp3"
            req.addOption("-f", if (fmt == "m4a") "bestaudio[ext=m4a]/bestaudio" else "bestaudio/best")
            req.addOption("-x")
            req.addOption("--audio-format", fmt)
            req.addOption("--audio-quality", "0")
            req.addOption("--embed-metadata")
            // Cover art inside the file. If a site makes this fail, delete these two lines.
            req.addOption("--embed-thumbnail")
            req.addOption("--convert-thumbnails", "jpg")
        } else {
            val h = spec.removePrefix("v:").toIntOrNull()
            val selector = if (h == null) {
                "bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/bv*+ba/b"
            } else {
                "bv*[height<=$h][ext=mp4]+ba[ext=m4a]/b[height<=$h][ext=mp4]/" +
                    "bv*[height<=$h]+ba/b[height<=$h]/b"
            }
            req.addOption("-f", selector)
            req.addOption("--merge-output-format", "mp4")
            req.addOption("--embed-metadata")
        }

        YoutubeDL.getInstance().execute(
            request = req,
            processId = processId,
            callback = { progress, eta, line -> onProgress(progress, eta, parseSpeed(line)) }
        )
    }

    /**
     * Download with silent link re-extract on failure.
     * Same page URL + same formatSpec + --continue keeps partial data in [dir].
     * Retries up to [maxAttempts] times when the stream URL dies mid-download.
     */
    suspend fun downloadWithRefresh(
        url: String,
        spec: String,
        dir: File,
        processId: String,
        maxAttempts: Int = 4,
        onProgress: (Float, Long, Long) -> Unit
    ) = withContext(Dispatchers.IO) {
        ready()
        requireHttp(url)
        dir.mkdirs()
        var last: Throwable? = null
        val attempts = maxAttempts.coerceIn(1, 8)
        for (i in 1..attempts) {
            try {
                download(url, spec, dir, processId, onProgress)
                // Success only if we have a finished output (not only .part)
                if (pickOutput(dir) != null) return@withContext
                // No output yet — treat as soft failure and retry extract
                last = IOException("خروجی ناقص بود؛ رفرش لینک…")
            } catch (ce: kotlinx.coroutines.CancellationException) {
                throw ce
            } catch (t: Throwable) {
                last = t
                // Abort if process was cancelled from outside
                if (!currentCoroutineContext().isActive) throw t
            }
            if (i < attempts) {
                delay(1500L * i)
            }
        }
        throw (last ?: IOException("دانلود پس از رفرش لینک ناموفق بود"))
    }

    fun cancel(processId: String) {
        runCatching { YoutubeDL.getInstance().destroyProcessById(processId) }
    }

    /** Biggest finished file in [dir] (ignores partial and temp files). */
    fun pickOutput(dir: File): File? =
        dir.listFiles()
            ?.filter {
                it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") &&
                    !it.name.endsWith(".temp") && !it.name.contains(".part-Frag")
            }
            ?.maxByOrNull { it.length() }

    // ---------------- engine update ----------------

    suspend fun update(app: Context): String = withContext(Dispatchers.IO) {
        ready()
        // UpdateChannel / UpdateStatus are nested on YoutubeDL (0.16+).
        // Compare by toString/name so a minor library rename does not break the build.
        val st = YoutubeDL.getInstance().updateYoutubeDL(app, YoutubeDL.UpdateChannel.STABLE)
        val key = st?.toString().orEmpty()
        when {
            key.contains("DONE") && !key.contains("ALREADY") -> "موتور ویدیو به‌روزرسانی شد"
            key.contains("ALREADY_UP_TO_DATE") -> "موتور ویدیو از قبل به‌روز است"
            else -> "بررسی به‌روزرسانی انجام شد"
        }
    }

    // ---------------- helpers ----------------

    private val speedRe = Regex("""at\s+([\d.]+)\s*([KMG]?)i?B/s""")

    private fun parseSpeed(line: String): Long {
        val m = speedRe.find(line) ?: return 0
        val v = m.groupValues[1].toDoubleOrNull() ?: return 0
        val mult = when (m.groupValues[2]) {
            "K" -> 1024.0
            "M" -> 1024.0 * 1024
            "G" -> 1024.0 * 1024 * 1024
            else -> 1.0
        }
        return (v * mult).toLong()
    }

    /** Turns raw yt-dlp errors into short Persian messages. */
    fun friendlyError(t: Throwable): String {
        val raw = t.message.orEmpty()
        val low = raw.lowercase()
        return when {
            low.contains("unsupported url") -> "این لینک پشتیبانی نمی‌شود"
            low.contains("private video") || low.contains("video unavailable") ->
                "ویدیو در دسترس نیست یا خصوصی است"
            // فقط عبارات واقعی سن/ورود — نه زیررشتهٔ «age» داخل کلماتی مثل message/page
            low.contains("sign in to confirm your age") ||
                low.contains("age-restricted") ||
                low.contains("age restricted") ||
                low.contains("confirm your age") ||
                low.contains("age gate") ||
                (low.contains("sign in") && low.contains("age")) ->
                "این ویدیو نیاز به ورود یا تأیید سن دارد"
            low.contains("http error 429") || low.contains("too many requests") ->
                "سرور محدودیت زده؛ کمی بعد دوباره امتحان کنید"
            low.contains("403") || low.contains("forbidden") || low.contains("http error 403") ->
                "لینک منقضی شده یا دسترسی رد شد؛ دوباره امتحان کنید تا لینک تازه گرفته شود"
            low.contains("unable to extract") || low.contains("unable to download") ->
                "استخراج ناموفق بود؛ از تنظیمات، موتور ویدیو را به‌روزرسانی کنید"
            low.contains("unable to resolve host") || low.contains("timed out") ||
                low.contains("timeout") ->
                "اتصال اینترنت برقرار نیست"
            else -> raw.lines().lastOrNull { it.contains("ERROR", true) }?.take(160)
                ?: raw.take(160).ifBlank { "خطای ناشناخته" }
        }
    }
}

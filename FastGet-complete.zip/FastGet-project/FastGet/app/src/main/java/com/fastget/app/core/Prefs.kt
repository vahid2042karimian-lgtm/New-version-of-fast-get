package com.fastget.app.core

import android.content.Context
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf

/**
 * Settings backed by SharedPreferences, observable from Compose.
 *
 * Mutable settings use public `var` properties whose setters also persist to
 * SharedPreferences. From Kotlin, assign the property directly (e.g. `prefs.threads = 8`).
 *
 * `themeId` is read-only; mutation goes through `setTheme(...)` to match existing call sites.
 */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("fastget", Context.MODE_PRIVATE)

    private val themeIdState = mutableStateOf(sp.getString("theme", "midnight") ?: "midnight")
    val themeId: String get() = themeIdState.value

    fun setTheme(v: String) {
        themeIdState.value = v
        sp.edit().putString("theme", v).apply()
    }

    private val threadsState = mutableIntStateOf(sp.getInt("threads", 8))
    var threads: Int
        get() = threadsState.intValue
        set(v) {
            threadsState.intValue = v
            sp.edit().putInt("threads", v).apply()
        }

    private val maxParallelState = mutableIntStateOf(sp.getInt("parallel", 3))
    var maxParallel: Int
        get() = maxParallelState.intValue
        set(v) {
            maxParallelState.intValue = v
            sp.edit().putInt("parallel", v).apply()
        }

    /** KB/s, 0 = unlimited. Applied to downloads started after the change. */
    private val speedLimitKbState = mutableLongStateOf(sp.getLong("limit_kb", 0L))
    var speedLimitKb: Long
        get() = speedLimitKbState.longValue
        set(v) {
            speedLimitKbState.longValue = v
            sp.edit().putLong("limit_kb", v).apply()
        }

    private val wifiOnlyState = mutableStateOf(sp.getBoolean("wifi_only", false))
    var wifiOnly: Boolean
        get() = wifiOnlyState.value
        set(v) {
            wifiOnlyState.value = v
            sp.edit().putBoolean("wifi_only", v).apply()
        }

    private val clipboardWatchState = mutableStateOf(sp.getBoolean("clipboard", true))
    var clipboardWatch: Boolean
        get() = clipboardWatchState.value
        set(v) {
            clipboardWatchState.value = v
            sp.edit().putBoolean("clipboard", v).apply()
        }

    private val publishToDownloadsState = mutableStateOf(sp.getBoolean("publish", true))
    var publishToDownloads: Boolean
        get() = publishToDownloadsState.value
        set(v) {
            publishToDownloadsState.value = v
            sp.edit().putBoolean("publish", v).apply()
        }

    private val appLockState = mutableStateOf(sp.getBoolean("app_lock", false))
    var appLock: Boolean
        get() = appLockState.value
        set(v) {
            appLockState.value = v
            sp.edit().putBoolean("app_lock", v).apply()
        }

    /**
     * روش قفل: none | pin | bio (اثرانگشت + رمز پشتیبان)
     * پیش‌فرض none — همه‌چیز باز تا کاربر انتخاب کند.
     */
    private val appLockModeState = mutableStateOf(sp.getString("app_lock_mode", "none") ?: "none")
    var appLockMode: String
        get() = appLockModeState.value
        set(v) {
            val m = when (v) {
                "pin", "bio" -> v
                else -> "none"
            }
            appLockModeState.value = m
            appLock = m != "none"
            sp.edit().putString("app_lock_mode", m).apply()
        }

    private val vaultLockModeState = mutableStateOf(sp.getString("vault_lock_mode", "none") ?: "none")
    var vaultLockMode: String
        get() = vaultLockModeState.value
        set(v) {
            val m = when (v) {
                "pin", "bio" -> v
                else -> "none"
            }
            vaultLockModeState.value = m
            sp.edit().putString("vault_lock_mode", m).apply()
        }

    private val secureScreenState = mutableStateOf(sp.getBoolean("secure_screen", false))
    var secureScreen: Boolean
        get() = secureScreenState.value
        set(v) {
            secureScreenState.value = v
            sp.edit().putBoolean("secure_screen", v).apply()
        }

    /** لیست‌های سفارشی: هر خط «id|نام نمایشی» */
    private val customListsState = mutableStateOf(sp.getString("custom_lists", "") ?: "")
    var customListsRaw: String
        get() = customListsState.value
        set(v) {
            customListsState.value = v
            sp.edit().putString("custom_lists", v).apply()
        }

    data class DownloadListDef(val id: String, val title: String)

    fun customLists(): List<DownloadListDef> =
        customListsRaw.lines().mapNotNull { line ->
            val t = line.trim()
            if (t.isEmpty()) return@mapNotNull null
            val parts = t.split("|", limit = 2)
            if (parts.size == 2) DownloadListDef(parts[0].trim(), parts[1].trim())
            else DownloadListDef(t, t)
        }.filter { it.id.isNotEmpty() && it.id != "main" && it.id != "vault" }

    fun addCustomList(title: String): DownloadListDef {
        val id = "list_${System.currentTimeMillis()}"
        val name = title.trim().ifBlank { "لیست" }
        val def = DownloadListDef(id, name)
        val cur = customLists()
        customListsRaw = (cur + def).joinToString("\n") { "${it.id}|${it.title}" }
        return def
    }

    fun removeCustomList(id: String) {
        customListsRaw = customLists().filter { it.id != id }
            .joinToString("\n") { "${it.id}|${it.title}" }
    }

    fun allListDefs(): List<DownloadListDef> = buildList {
        add(DownloadListDef("main", "لیست اصلی"))
        add(DownloadListDef("vault", "محافظت‌شده"))
        addAll(customLists())
    }

    /** Plain http links are refused unless this is on. */
    private val allowHttpState = mutableStateOf(sp.getBoolean("allow_http", false))
    var allowHttp: Boolean
        get() = allowHttpState.value
        set(v) {
            allowHttpState.value = v
            sp.edit().putBoolean("allow_http", v).apply()
        }

    private val videoTermsAcceptedState = mutableStateOf(sp.getBoolean("video_terms", false))
    var videoTermsAccepted: Boolean
        get() = videoTermsAcceptedState.value
        private set(v) {
            videoTermsAcceptedState.value = v
            sp.edit().putBoolean("video_terms", v).apply()
        }

    /**
     * App language: "fa" or "en". Empty means not chosen yet (first-run prompt).
     * Actual locale switching will be applied in a later step.
     */
    private val languageState = mutableStateOf(sp.getString("language", "") ?: "")
    var language: String
        get() = languageState.value
        set(v) {
            languageState.value = v
            sp.edit().putString("language", v).apply()
        }

    /**
     * Custom download folder absolute path. Empty = use app default
     * (Android/data/.../Download or internal downloads).
     * Full folder picker (SAF) will be wired in a later step.
     */
    private val customDownloadDirState = mutableStateOf(sp.getString("custom_dl_dir", "") ?: "")
    var customDownloadDir: String
        get() = customDownloadDirState.value
        set(v) {
            customDownloadDirState.value = v
            sp.edit().putString("custom_dl_dir", v).apply()
        }

    /** SAF tree URI from system folder picker (content://...). */
    private val customDownloadTreeUriState = mutableStateOf(sp.getString("custom_dl_tree", "") ?: "")
    var customDownloadTreeUri: String
        get() = customDownloadTreeUriState.value
        set(v) {
            customDownloadTreeUriState.value = v
            sp.edit().putString("custom_dl_tree", v).apply()
        }

    /**
     * Legacy single list (kept for browser shortcuts). Prefer the four category lists below.
     */
    private val customSitesState = mutableStateOf(
        sp.getString("custom_sites", "youtube.com\nsoundcloud.com\ninstagram.com") ?: ""
    )
    var customSites: String
        get() = customSitesState.value
        set(v) {
            customSitesState.value = v
            sp.edit().putString("custom_sites", v).apply()
        }

    fun customSitesList(): List<String> =
        customSites.lines().map { it.trim() }.filter { it.isNotEmpty() }.distinct()

    // ---- Public site lists (Settings): video / audio / file / torrent only ----

    private val sitesVideoState = mutableStateOf(
        sp.getString("sites_video", "youtube.com\naparat.com\nvimeo.com") ?: ""
    )
    var sitesVideo: String
        get() = sitesVideoState.value
        set(v) {
            sitesVideoState.value = v
            sp.edit().putString("sites_video", v).apply()
        }

    private val sitesAudioState = mutableStateOf(
        sp.getString("sites_audio", "soundcloud.com") ?: ""
    )
    var sitesAudio: String
        get() = sitesAudioState.value
        set(v) {
            sitesAudioState.value = v
            sp.edit().putString("sites_audio", v).apply()
        }

    private val sitesFileState = mutableStateOf(
        sp.getString("sites_file", "") ?: ""
    )
    var sitesFile: String
        get() = sitesFileState.value
        set(v) {
            sitesFileState.value = v
            sp.edit().putString("sites_file", v).apply()
        }

    private val sitesTorrentState = mutableStateOf(
        sp.getString("sites_torrent", "1337x.to\nnyaa.si") ?: ""
    )
    var sitesTorrent: String
        get() = sitesTorrentState.value
        set(v) {
            sitesTorrentState.value = v
            sp.edit().putString("sites_torrent", v).apply()
        }

    /**
     * Private extra site list — edited ONLY inside Vault.
     * Reuses legacy key sites_porn for migration; never shown in Settings UI.
     */
    private val sitesExtraState = mutableStateOf(
        sp.getString("sites_extra", sp.getString("sites_porn", "") ?: "") ?: ""
    )
    var sitesExtra: String
        get() = sitesExtraState.value
        set(v) {
            sitesExtraState.value = v
            sp.edit().putString("sites_extra", v).apply()
        }

    /**
     * When true (toggled inside Vault), search bar shows the Extra type
     * and engines may use [sitesExtra]. Default off — no extra option in search.
     */
    private val extraSearchEnabledState = mutableStateOf(sp.getBoolean("extra_search_on", false))
    var extraSearchEnabled: Boolean
        get() = extraSearchEnabledState.value
        set(v) {
            extraSearchEnabledState.value = v
            sp.edit().putBoolean("extra_search_on", v).apply()
        }

    fun sitesFor(category: SiteCategory): List<String> {
        val raw = when (category) {
            SiteCategory.VIDEO -> sitesVideo
            SiteCategory.AUDIO -> sitesAudio
            SiteCategory.FILE -> sitesFile
            SiteCategory.TORRENT -> sitesTorrent
            SiteCategory.EXTRA -> sitesExtra
        }
        return raw.lines().map { it.trim().lowercase().removePrefix("https://").removePrefix("http://").removePrefix("www.") }
            .filter { it.isNotEmpty() }.distinct()
    }

    /**
     * آیا این URL متعلق به دامنهٔ +۱۸ ثبت‌شده در پوشهٔ خصوصی است؟
     * زیردامنه‌ها هم بررسی می‌شوند (مثلاً m.example.com برای example.com).
     */
    fun isAdultUrl(url: String): Boolean {
        val host = try {
            java.net.URI(url).host?.lowercase()?.removePrefix("www.") ?: return false
        } catch (_: Throwable) {
            return false
        }
        if (host.isBlank()) return false
        return sitesFor(SiteCategory.EXTRA).any { d -> host == d || host.endsWith(".$d") }
    }

    /**
     * آیا مجاز به ثبت/دانلود محتوای +۱۸ هستیم؟
     * هم تیک «محتوای +۱۸» باید روشن باشد و هم دامنه در لیست خصوصی باشد.
     */
    fun canUseAdultContent(url: String): Boolean =
        extraSearchEnabled && isAdultUrl(url)

    fun siteEntries(category: SiteCategory): List<SiteEntry> {
        return sitesFor(category).map { host ->
            SiteEntry(
                host = host,
                category = category,
                needsAgeGate = category == SiteCategory.EXTRA
            )
        }
    }

    /** When true, GoogleEngine runs in parallel with site engines. */
    private val googleSearchEnabledState = mutableStateOf(sp.getBoolean("google_search", true))
    var googleSearchEnabled: Boolean
        get() = googleSearchEnabledState.value
        set(v) {
            googleSearchEnabledState.value = v
            sp.edit().putBoolean("google_search", v).apply()
        }

    private val homeGridState = mutableStateOf(sp.getBoolean("home_grid", false))
    var homeGridLayout: Boolean
        get() = homeGridState.value
        set(v) {
            homeGridState.value = v
            sp.edit().putBoolean("home_grid", v).apply()
        }

    private val lastBrowserUrlState = mutableStateOf(sp.getString("last_browser_url", "") ?: "")
    var lastBrowserUrl: String
        get() = lastBrowserUrlState.value
        set(v) {
            lastBrowserUrlState.value = v
            sp.edit().putString("last_browser_url", v).apply()
        }

    private val browserTabsState = mutableStateOf(sp.getString("browser_tabs", "") ?: "")
    var browserTabs: String
        get() = browserTabsState.value
        set(v) {
            browserTabsState.value = v
            sp.edit().putString("browser_tabs", v).apply()
        }

    /** When true, new downloads only start between scheduleStartHour and scheduleEndHour. */
    private val scheduleEnabledState = mutableStateOf(sp.getBoolean("schedule_on", false))
    var scheduleEnabled: Boolean
        get() = scheduleEnabledState.value
        set(v) {
            scheduleEnabledState.value = v
            sp.edit().putBoolean("schedule_on", v).apply()
        }

    private val scheduleStartHourState = mutableIntStateOf(sp.getInt("schedule_start", 0))
    var scheduleStartHour: Int
        get() = scheduleStartHourState.intValue
        set(v) {
            scheduleStartHourState.intValue = v.coerceIn(0, 23)
            sp.edit().putInt("schedule_start", scheduleStartHourState.intValue).apply()
        }

    private val scheduleEndHourState = mutableIntStateOf(sp.getInt("schedule_end", 23))
    var scheduleEndHour: Int
        get() = scheduleEndHourState.intValue
        set(v) {
            scheduleEndHourState.intValue = v.coerceIn(0, 23)
            sp.edit().putInt("schedule_end", scheduleEndHourState.intValue).apply()
        }

    /** زمان‌بندی جدا برای لیست محافظت‌شده (نیاز به تأیید هویت برای فعال‌سازی). */
    private val scheduleVaultEnabledState = mutableStateOf(sp.getBoolean("schedule_vault_on", false))
    var scheduleVaultEnabled: Boolean
        get() = scheduleVaultEnabledState.value
        set(v) {
            scheduleVaultEnabledState.value = v
            sp.edit().putBoolean("schedule_vault_on", v).apply()
        }

    /**
     * لیست‌هایی که زمان‌بندی عمومی روی آن‌ها اعمال می‌شود.
     * مقادیر: all | main | vault | customId — چندتایی با کاما.
     */
    private val scheduleTargetListsState = mutableStateOf(
        sp.getString("schedule_targets", "all") ?: "all"
    )
    var scheduleTargetLists: String
        get() = scheduleTargetListsState.value
        set(v) {
            scheduleTargetListsState.value = v
            sp.edit().putString("schedule_targets", v).apply()
        }

    fun scheduleTargetsSet(): Set<String> =
        scheduleTargetLists.split(',').map { it.trim() }.filter { it.isNotEmpty() }.toSet()
            .ifEmpty { setOf("all") }

    /** آیا این listId الان اجازهٔ شروع دانلود دارد؟ */
    fun isWithinScheduleFor(listId: String): Boolean {
        val isVault = listId == "vault"
        if (isVault) {
            if (!scheduleVaultEnabled && !scheduleEnabled) return true
            if (scheduleVaultEnabled) return withinHours(scheduleStartHour, scheduleEndHour)
            // زمان‌بندی عمومی فقط اگر vault در targets باشد
            if (!scheduleEnabled) return true
            val targets = scheduleTargetsSet()
            if ("all" in targets || "vault" in targets) return withinHours(scheduleStartHour, scheduleEndHour)
            return true
        }
        if (!scheduleEnabled) return true
        val targets = scheduleTargetsSet()
        if ("all" in targets || listId in targets) return withinHours(scheduleStartHour, scheduleEndHour)
        return true
    }

    /** سازگاری با کد قبلی — زمان‌بندی عمومی (لیست اصلی). */
    fun isWithinSchedule(): Boolean = isWithinScheduleFor("main")

    private fun withinHours(start: Int, end: Int): Boolean {
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        return if (start <= end) hour in start until end
        else hour >= start || hour < end
    }


    /** آموزش اولیه یک‌بار دیده شده */
    private val tutorialDoneState = mutableStateOf(sp.getBoolean("tutorial_done", false))
    var tutorialDone: Boolean
        get() = tutorialDoneState.value
        set(v) {
            tutorialDoneState.value = v
            sp.edit().putBoolean("tutorial_done", v).apply()
        }

    val lastEngineUpdate: Long get() = sp.getLong("engine_update", 0L)

    fun acceptVideoTerms() {
        videoTermsAccepted = true
    }

    fun markEngineUpdated() {
        sp.edit().putLong("engine_update", System.currentTimeMillis()).apply()
    }
}

package com.fastget.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface DownloadDao {
    @Query("SELECT * FROM downloads ORDER BY id DESC")
    fun observeAll(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE id = :id")
    suspend fun get(id: Long): DownloadEntity?

    /** Exact URL match (for duplicate detection). */
    @Query("SELECT * FROM downloads WHERE url = :url ORDER BY id DESC LIMIT 1")
    suspend fun findByUrl(url: String): DownloadEntity?

    @Query("SELECT COUNT(*) FROM downloads WHERE url = :url")
    suspend fun countByUrl(url: String): Int

    /** Higher priority first, then older items (FIFO within same priority). */
    @Query("SELECT * FROM downloads WHERE status = :status ORDER BY priority DESC, id ASC")
    suspend fun byStatus(status: String): List<DownloadEntity>

    @Insert
    suspend fun insert(e: DownloadEntity): Long

    @Update
    suspend fun update(e: DownloadEntity)

    @Query("DELETE FROM downloads WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("UPDATE downloads SET status = :to WHERE status = :from")
    suspend fun moveStatus(from: String, to: String)

    @Query("UPDATE downloads SET status = :status, error = :error WHERE id = :id")
    suspend fun setStatus(id: Long, status: String, error: String?)

    @Query("UPDATE downloads SET downloadedBytes = :downloaded, segments = :segments WHERE id = :id")
    suspend fun setProgress(id: Long, downloaded: Long, segments: String)
}

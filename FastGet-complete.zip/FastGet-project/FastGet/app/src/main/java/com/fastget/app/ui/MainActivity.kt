package com.fastget.app.ui

import android.Manifest
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.view.WindowManager
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Modifier
import androidx.fragment.app.FragmentActivity
import com.fastget.app.core.Security
import com.fastget.app.core.extractUrls
import com.fastget.app.ui.theme.FastGetTheme
import com.fastget.app.ui.theme.paletteOf

// FragmentActivity (not plain ComponentActivity) because BiometricPrompt needs it.
class MainActivity : FragmentActivity() {

    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleIntent(intent)

        setContent {
            val palette = paletteOf(vm.prefs.themeId)
            SideEffect {
                val transparent = android.graphics.Color.TRANSPARENT
                val style = if (palette.dark) SystemBarStyle.dark(transparent)
                else SystemBarStyle.light(transparent, transparent)
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)

                // Blocks screenshots, screen recording and the recent-apps thumbnail.
                val secure = vm.prefs.secureScreen || vm.locked || vm.screen == Screen.VAULT
                if (secure) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
            }
            // language خوانده می‌شود تا با تغییر زبان، جهت و متن‌ها بازسازی شوند
            val lang = vm.prefs.language.ifBlank { "fa" }
            FastGetTheme(palette, language = lang) {
                val permission = rememberLauncherForActivityResult(
                    ActivityResultContracts.RequestPermission()
                ) { }
                LaunchedEffect(Unit) {
                    if (Build.VERSION.SDK_INT >= 33 &&
                        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED
                    ) permission.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    App(vm, auth = { title, ok -> Security.prompt(this@MainActivity, title, ok) })
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        // Re-lock if the app was away for more than 30 seconds.
        if (vm.prefs.appLock && vm.backgroundedAt > 0 &&
            SystemClock.elapsedRealtime() - vm.backgroundedAt > 30_000 &&
            Security.available(this)
        ) vm.locked = true
    }

    override fun onStop() {
        super.onStop()
        vm.backgroundedAt = SystemClock.elapsedRealtime()
        // The vault never stays open in the background.
        vm.vaultUnlocked = false
        if (vm.screen == Screen.VAULT) vm.screen = Screen.HOME
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        i ?: return
        val text = when (i.action) {
            Intent.ACTION_SEND -> i.getStringExtra(Intent.EXTRA_TEXT)
            Intent.ACTION_VIEW -> i.dataString
            else -> null
        } ?: return
        val urls = extractUrls(text)
        if (urls.isNotEmpty()) {
            vm.lastClip = urls.first()
            vm.openAdd(urls.joinToString("\n"))
        }
    }

    // Clipboard can only be read while the window has focus (Android 10+).
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus || vm.locked || !vm.prefs.clipboardWatch || vm.showAdd) return
        val cm = getSystemService(ClipboardManager::class.java)
        val text = cm.primaryClip?.takeIf { it.itemCount > 0 }
            ?.getItemAt(0)?.text?.toString()?.trim() ?: return
        if (text != vm.lastClip && Regex("""^https?://\S+$""").matches(text)) {
            vm.lastClip = text
            vm.openAdd(text)
        }
    }
}

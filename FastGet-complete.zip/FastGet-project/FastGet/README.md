# FastGet 2.3.0

Android download manager (Compose) with multi-engine search, in-app browser, torrents, and private vault.

## Features
- Search: YouTube, SoundCloud, custom sites (Settings), web (DuckDuckGo/Bing), torrents
- Type selector: Video / Audio / File / Torrent / All (+ Extra from Vault toggle only)
- Link refresh + resume for yt-dlp downloads (`downloadWithRefresh`)
- Auto save under `Download/FastGet/{Video,Audio,Documents,...}`
- Settings: hierarchical menu + accordion detail pages
- Browser: tabs (persisted), desktop/mobile UA, video detect banner, queue without auto-start
- Home: ADM-style slim cards, multi-select, completed section, FAB add with probe

## Build
- Android Studio / Gradle
- ABI: **arm64-v8a** (libtorrent4j-android-arm64)
- JDK 17

```bash
./gradlew assembleRelease
```

## Notes
- Extra (adult) site list is only editable inside the locked Vault; no public labels in Settings.
- First launch initializes yt-dlp (may take a few seconds).
